﻿using BMS.Model;
using BMS.Utils;
using DevExpress.Utils;
using DevExpress.XtraPrinting;
using DevExpress.XtraPrintingLinks;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace BMS
{
	public partial class frmKpiSyntheticYears : _Forms
	{
		private int txt;

		public frmKpiSyntheticYears()
		{
			InitializeComponent();
		}

		private void frmKpiSyntheticYears_Load(object sender, EventArgs e)
		{
			txtYears.Value = DateTime.Now.Year;

            LoadDepartment();
			LoadEmployee();
			LoadData();
		}

		void LoadDepartment()
		{
			var list = SQLHelper<DepartmentModel>.FindAll().ToList();
			cboDepartMent.Properties.ValueMember = "ID";
			cboDepartMent.Properties.DisplayMember = "Name";
			cboDepartMent.Properties.DataSource = list;

			cboDepartMent.EditValue = Global.DepartmentID;
		}

		void LoadEmployee()
		{
			var list = SQLHelper<EmployeeModel>.FindAll().ToList();
			cboEmployee.Properties.ValueMember = "ID";
			cboEmployee.Properties.DisplayMember = "FullName";
			cboEmployee.Properties.DataSource = list;

			cboEmployee.EditValue = Global.EmployeeID;
		}

		private void btnSearch_Click(object sender, EventArgs e)
		{
			LoadData();
		}

		private void LoadData()
		{
			string keyword = txtKeywords.Text.Trim();
			int year = TextUtils.ToInt(txtYears.Value);
			int emID = TextUtils.ToInt(cboEmployee.EditValue);
			int deID = TextUtils.ToInt(cboDepartMent.EditValue);

			DataTable dt = TextUtils.LoadDataFromSP("spGetSyntheticKPI", "A", 
				new string[] { "@Year", "@DepartmentID", "@EmployeeID", "@Keyword" }, 
				new object[] { year , deID , emID , keyword });
			grdMain.DataSource = dt;

		}

		private void btnExportExcel_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
		{
			DateTime dti = DateTime.Now;
			SaveFileDialog f = new SaveFileDialog();
			f.Filter = "Excel Files|*.xlsx";
			f.FileName = $"TongHopKPINam_{dti.Day}{dti.Month}{dti.Year}.xlsx";
			if (f.ShowDialog() == DialogResult.OK)
			{
				string filepath = f.FileName;

				XlsxExportOptionsEx optionsEx = new XlsxExportOptionsEx();
				PrintingSystem printingSystem = new PrintingSystem();

				PrintableComponentLink printableComponentLink1 = new PrintableComponentLink(printingSystem);
				printableComponentLink1.Component = grdMain;

				try
				{
					using (WaitDialogForm fWait = new WaitDialogForm("Vui lòng chờ trong giây lát...", "Đang tạo phiếu..."))
					{
						CompositeLink compositeLink = new CompositeLink(printingSystem);
						compositeLink.Links.Add(printableComponentLink1);

						compositeLink.CreatePageForEachLink();
						optionsEx.ExportMode = XlsxExportMode.SingleFilePageByPage;

						compositeLink.PrintingSystem.SaveDocument(filepath);
						compositeLink.ExportToXlsx(filepath, optionsEx);
						Process.Start(filepath);
					}


				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message);
				}
			}
		}
	}

}
