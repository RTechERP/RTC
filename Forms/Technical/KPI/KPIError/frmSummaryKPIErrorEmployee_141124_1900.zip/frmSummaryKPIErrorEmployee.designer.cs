﻿
namespace BMS
{
    partial class frmSummaryKPIErrorEmployee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            DevExpress.XtraEditors.Controls.EditorButtonImageOptions editorButtonImageOptions1 = new DevExpress.XtraEditors.Controls.EditorButtonImageOptions();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject1 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject2 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject3 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject4 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.XtraCharts.XYDiagram xyDiagram1 = new DevExpress.XtraCharts.XYDiagram();
            DevExpress.XtraCharts.Series series1 = new DevExpress.XtraCharts.Series();
            DevExpress.XtraCharts.StackedBarSeriesLabel stackedBarSeriesLabel1 = new DevExpress.XtraCharts.StackedBarSeriesLabel();
            DevExpress.XtraCharts.StackedBarSeriesView stackedBarSeriesView1 = new DevExpress.XtraCharts.StackedBarSeriesView();
            DevExpress.XtraCharts.Series series2 = new DevExpress.XtraCharts.Series();
            DevExpress.XtraCharts.StackedBarSeriesLabel stackedBarSeriesLabel2 = new DevExpress.XtraCharts.StackedBarSeriesLabel();
            DevExpress.XtraCharts.StackedBarSeriesView stackedBarSeriesView2 = new DevExpress.XtraCharts.StackedBarSeriesView();
            DevExpress.XtraCharts.Series series3 = new DevExpress.XtraCharts.Series();
            DevExpress.XtraCharts.StackedBarSeriesLabel stackedBarSeriesLabel3 = new DevExpress.XtraCharts.StackedBarSeriesLabel();
            DevExpress.XtraCharts.StackedBarSeriesView stackedBarSeriesView3 = new DevExpress.XtraCharts.StackedBarSeriesView();
            DevExpress.XtraCharts.Series series4 = new DevExpress.XtraCharts.Series();
            DevExpress.XtraCharts.StackedBarSeriesLabel stackedBarSeriesLabel4 = new DevExpress.XtraCharts.StackedBarSeriesLabel();
            DevExpress.XtraCharts.StackedBarSeriesView stackedBarSeriesView4 = new DevExpress.XtraCharts.StackedBarSeriesView();
            DevExpress.XtraCharts.Series series5 = new DevExpress.XtraCharts.Series();
            DevExpress.XtraCharts.StackedBarSeriesLabel stackedBarSeriesLabel5 = new DevExpress.XtraCharts.StackedBarSeriesLabel();
            DevExpress.XtraCharts.StackedBarSeriesView stackedBarSeriesView5 = new DevExpress.XtraCharts.StackedBarSeriesView();
            DevExpress.XtraCharts.Series series6 = new DevExpress.XtraCharts.Series();
            DevExpress.XtraCharts.StackedBarSeriesLabel stackedBarSeriesLabel6 = new DevExpress.XtraCharts.StackedBarSeriesLabel();
            DevExpress.XtraCharts.StackedBarSeriesView stackedBarSeriesView6 = new DevExpress.XtraCharts.StackedBarSeriesView();
            DevExpress.XtraCharts.ChartTitle chartTitle1 = new DevExpress.XtraCharts.ChartTitle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSummaryKPIErrorEmployee));
            this.repositoryItemMemoEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit();
            this.repositoryItemMemoEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit();
            this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
            this.xtraTabControl1 = new DevExpress.XtraTab.XtraTabControl();
            this.ttTongHop = new DevExpress.XtraTab.XtraTabPage();
            this.splitContainerControl2 = new DevExpress.XtraEditors.SplitContainerControl();
            this.grdData = new DevExpress.XtraGrid.GridControl();
            this.grvData = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colID = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colSTT = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colCode = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colTypeName_TH = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colContent = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colEmployeeCode = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colEmployeeName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colDepartmentName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colErrorDate = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colErrorNumber = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colCoefficient = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colMonney = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colNote = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colEmployee = new DevExpress.XtraGrid.Columns.GridColumn();
            this.panelControl2 = new DevExpress.XtraEditors.PanelControl();
            this.stackPanel6 = new DevExpress.Utils.Layout.StackPanel();
            this.label7 = new System.Windows.Forms.Label();
            this.txtYearError = new System.Windows.Forms.NumericUpDown();
            this.label8 = new System.Windows.Forms.Label();
            this.txtMonthError = new System.Windows.Forms.NumericUpDown();
            this.label11 = new System.Windows.Forms.Label();
            this.cboKPIError = new DevExpress.XtraEditors.SearchLookUpEdit();
            this.searchLookUpEdit1View = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn20 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemMemoEdit4 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit();
            this.gridColumn4 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn6 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn5 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.col = new DevExpress.XtraGrid.Columns.GridColumn();
            this.label2 = new System.Windows.Forms.Label();
            this.cboEmployee = new DevExpress.XtraEditors.SearchLookUpEdit();
            this.gridView8 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn23 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn24 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn25 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.label19 = new System.Windows.Forms.Label();
            this.txtKeyword = new System.Windows.Forms.TextBox();
            this.btnFind = new System.Windows.Forms.Button();
            this.btnExportExcel = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.stackPanel5 = new DevExpress.Utils.Layout.StackPanel();
            this.label14 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.splitContainerControl1 = new DevExpress.XtraEditors.SplitContainerControl();
            this.grdDataFile = new DevExpress.XtraGrid.GridControl();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.btnShowImage = new System.Windows.Forms.ToolStripMenuItem();
            this.grvDataFile = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colFileID = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colFileName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemMemoEdit6 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit();
            this.colErrorDateFile = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colEmployeeFile = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colErrorNameFile = new DevExpress.XtraGrid.Columns.GridColumn();
            this.btnDownloadFile = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.pictureBox = new System.Windows.Forms.PictureBox();
            this.stackPanel1 = new DevExpress.Utils.Layout.StackPanel();
            this.ttThongKe = new DevExpress.XtraTab.XtraTabPage();
            this.grdData_TK = new DevExpress.XtraGrid.GridControl();
            this.grvData_TK = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colKPIErrorID = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colKPIErrorCode = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemMemoEdit5 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit();
            this.colTypeName_TK = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colKPIErrorContent = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colQuantity = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colUnit = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colKPIErrorMonney = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colErrorNote = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colWeek1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colWeek2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colWeek3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colWeek4 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colWeek5 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colWeek6 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colMonth = new DevExpress.XtraGrid.Columns.GridColumn();
            this.panelControl3 = new DevExpress.XtraEditors.PanelControl();
            this.stackPanel3 = new DevExpress.Utils.Layout.StackPanel();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.stackPanel4 = new DevExpress.Utils.Layout.StackPanel();
            this.label6 = new System.Windows.Forms.Label();
            this.txtYear = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.txtMonth = new System.Windows.Forms.NumericUpDown();
            this.label15 = new System.Windows.Forms.Label();
            this.txtKeyword_TK = new System.Windows.Forms.TextBox();
            this.btnFind_TK = new System.Windows.Forms.Button();
            this.btnExportExcel_TK = new System.Windows.Forms.Button();
            this.ttBieuDo = new DevExpress.XtraTab.XtraTabPage();
            this.splitContainerControl3 = new DevExpress.XtraEditors.SplitContainerControl();
            this.chartKPIErrorInMonth = new DevExpress.XtraCharts.ChartControl();
            this.stackPanel7 = new DevExpress.Utils.Layout.StackPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.txtYearChart = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.txtMonthChart = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btnFindChart = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.grdDataEmployee = new DevExpress.XtraGrid.GridControl();
            this.grvDataEmployee = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn7 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemMemoEdit3 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit();
            this.gridColumn8 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colErrorNumberEmployee = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn9 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn14 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.mnuMenu = new System.Windows.Forms.ToolStrip();
            this.btnExcel = new System.Windows.Forms.ToolStripButton();
            this.stackPanel2 = new DevExpress.Utils.Layout.StackPanel();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
            this.panelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl1)).BeginInit();
            this.xtraTabControl1.SuspendLayout();
            this.ttTongHop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl2.Panel1)).BeginInit();
            this.splitContainerControl2.Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl2.Panel2)).BeginInit();
            this.splitContainerControl2.Panel2.SuspendLayout();
            this.splitContainerControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl2)).BeginInit();
            this.panelControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.stackPanel6)).BeginInit();
            this.stackPanel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtYearError)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMonthError)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboKPIError.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.searchLookUpEdit1View)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboEmployee.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView8)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.stackPanel5)).BeginInit();
            this.stackPanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1.Panel1)).BeginInit();
            this.splitContainerControl1.Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1.Panel2)).BeginInit();
            this.splitContainerControl1.Panel2.SuspendLayout();
            this.splitContainerControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdDataFile)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grvDataFile)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDownloadFile)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stackPanel1)).BeginInit();
            this.ttThongKe.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdData_TK)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvData_TK)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl3)).BeginInit();
            this.panelControl3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.stackPanel3)).BeginInit();
            this.stackPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.stackPanel4)).BeginInit();
            this.stackPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtYear)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMonth)).BeginInit();
            this.ttBieuDo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl3.Panel1)).BeginInit();
            this.splitContainerControl3.Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl3.Panel2)).BeginInit();
            this.splitContainerControl3.Panel2.SuspendLayout();
            this.splitContainerControl3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartKPIErrorInMonth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(xyDiagram1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(series1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(stackedBarSeriesLabel1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(stackedBarSeriesView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(series2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(stackedBarSeriesLabel2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(stackedBarSeriesView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(series3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(stackedBarSeriesLabel3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(stackedBarSeriesView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(series4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(stackedBarSeriesLabel4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(stackedBarSeriesView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(series5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(stackedBarSeriesLabel5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(stackedBarSeriesView5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(series6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(stackedBarSeriesLabel6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(stackedBarSeriesView6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stackPanel7)).BeginInit();
            this.stackPanel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtYearChart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMonthChart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdDataEmployee)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvDataEmployee)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit3)).BeginInit();
            this.mnuMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.stackPanel2)).BeginInit();
            this.SuspendLayout();
            // 
            // repositoryItemMemoEdit2
            // 
            this.repositoryItemMemoEdit2.Name = "repositoryItemMemoEdit2";
            // 
            // repositoryItemMemoEdit1
            // 
            this.repositoryItemMemoEdit1.Name = "repositoryItemMemoEdit1";
            // 
            // panelControl1
            // 
            this.panelControl1.Controls.Add(this.xtraTabControl1);
            this.panelControl1.Controls.Add(this.mnuMenu);
            this.panelControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelControl1.Location = new System.Drawing.Point(0, 0);
            this.panelControl1.Name = "panelControl1";
            this.panelControl1.Size = new System.Drawing.Size(1924, 661);
            this.panelControl1.TabIndex = 30;
            // 
            // xtraTabControl1
            // 
            this.xtraTabControl1.AppearancePage.Header.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xtraTabControl1.AppearancePage.Header.Options.UseFont = true;
            this.xtraTabControl1.AppearancePage.HeaderActive.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xtraTabControl1.AppearancePage.HeaderActive.ForeColor = System.Drawing.Color.Black;
            this.xtraTabControl1.AppearancePage.HeaderActive.Options.UseFont = true;
            this.xtraTabControl1.AppearancePage.HeaderActive.Options.UseForeColor = true;
            this.xtraTabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraTabControl1.Location = new System.Drawing.Point(2, 38);
            this.xtraTabControl1.Name = "xtraTabControl1";
            this.xtraTabControl1.SelectedTabPage = this.ttTongHop;
            this.xtraTabControl1.Size = new System.Drawing.Size(1920, 621);
            this.xtraTabControl1.TabIndex = 1;
            this.xtraTabControl1.TabPages.AddRange(new DevExpress.XtraTab.XtraTabPage[] {
            this.ttTongHop,
            this.ttThongKe,
            this.ttBieuDo});
            this.xtraTabControl1.Click += new System.EventHandler(this.xtraTabControl1_Click);
            // 
            // ttTongHop
            // 
            this.ttTongHop.Appearance.Header.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ttTongHop.Appearance.Header.Options.UseFont = true;
            this.ttTongHop.Appearance.HeaderActive.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ttTongHop.Appearance.HeaderActive.ForeColor = System.Drawing.Color.Black;
            this.ttTongHop.Appearance.HeaderActive.Options.UseFont = true;
            this.ttTongHop.Appearance.HeaderActive.Options.UseForeColor = true;
            this.ttTongHop.Controls.Add(this.splitContainerControl2);
            this.ttTongHop.Controls.Add(this.stackPanel1);
            this.ttTongHop.Name = "ttTongHop";
            this.ttTongHop.Size = new System.Drawing.Size(1918, 593);
            this.ttTongHop.Text = "TỔNG HỢP LỖI CỦA NHÂN VIÊN";
            // 
            // splitContainerControl2
            // 
            this.splitContainerControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainerControl2.FixedPanel = DevExpress.XtraEditors.SplitFixedPanel.None;
            this.splitContainerControl2.Location = new System.Drawing.Point(0, 0);
            this.splitContainerControl2.Name = "splitContainerControl2";
            // 
            // splitContainerControl2.Panel1
            // 
            this.splitContainerControl2.Panel1.Controls.Add(this.grdData);
            this.splitContainerControl2.Panel1.Controls.Add(this.panelControl2);
            this.splitContainerControl2.Panel1.Controls.Add(this.groupBox1);
            this.splitContainerControl2.Panel1.Text = "Panel1";
            // 
            // splitContainerControl2.Panel2
            // 
            this.splitContainerControl2.Panel2.Controls.Add(this.splitContainerControl1);
            this.splitContainerControl2.Panel2.Text = "Panel2";
            this.splitContainerControl2.Size = new System.Drawing.Size(1918, 593);
            this.splitContainerControl2.SplitterPosition = 1392;
            this.splitContainerControl2.TabIndex = 57;
            // 
            // grdData
            // 
            this.grdData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdData.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(36, 39, 36, 39);
            this.grdData.Location = new System.Drawing.Point(0, 120);
            this.grdData.MainView = this.grvData;
            this.grdData.Margin = new System.Windows.Forms.Padding(36, 39, 36, 39);
            this.grdData.Name = "grdData";
            this.grdData.Size = new System.Drawing.Size(1392, 473);
            this.grdData.TabIndex = 29;
            this.grdData.Tag = "";
            this.grdData.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.grvData});
            // 
            // grvData
            // 
            this.grvData.Appearance.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.grvData.Appearance.HeaderPanel.Options.UseFont = true;
            this.grvData.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.grvData.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.grvData.Appearance.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.grvData.Appearance.HeaderPanel.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.grvData.Appearance.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.grvData.Appearance.Row.Font = new System.Drawing.Font("Tahoma", 9.75F);
            this.grvData.Appearance.Row.Options.UseFont = true;
            this.grvData.Appearance.Row.Options.UseTextOptions = true;
            this.grvData.Appearance.Row.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.grvData.Appearance.Row.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.grvData.ColumnPanelRowHeight = 50;
            this.grvData.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colID,
            this.colSTT,
            this.colCode,
            this.colTypeName_TH,
            this.colContent,
            this.colEmployeeCode,
            this.colEmployeeName,
            this.colDepartmentName,
            this.colErrorDate,
            this.colErrorNumber,
            this.colCoefficient,
            this.colMonney,
            this.colNote,
            this.colEmployee});
            this.grvData.DetailHeight = 4125;
            this.grvData.GridControl = this.grdData;
            this.grvData.GroupCount = 2;
            this.grvData.GroupSummary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "ErrorNumber", null, "({0})")});
            this.grvData.Name = "grvData";
            this.grvData.OptionsBehavior.AutoExpandAllGroups = true;
            this.grvData.OptionsBehavior.Editable = false;
            this.grvData.OptionsPrint.AutoWidth = false;
            this.grvData.OptionsSelection.CheckBoxSelectorColumnWidth = 30;
            this.grvData.OptionsSelection.MultiSelect = true;
            this.grvData.OptionsSelection.ShowCheckBoxSelectorInPrintExport = DevExpress.Utils.DefaultBoolean.False;
            this.grvData.OptionsView.RowAutoHeight = true;
            this.grvData.OptionsView.ShowAutoFilterRow = true;
            this.grvData.OptionsView.ShowFooter = true;
            this.grvData.OptionsView.ShowGroupPanel = false;
            this.grvData.SortInfo.AddRange(new DevExpress.XtraGrid.Columns.GridColumnSortInfo[] {
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.colEmployee, DevExpress.Data.ColumnSortOrder.Descending),
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.colTypeName_TH, DevExpress.Data.ColumnSortOrder.Descending)});
            this.grvData.Tag = "";
            this.grvData.CustomDrawCell += new DevExpress.XtraGrid.Views.Base.RowCellCustomDrawEventHandler(this.grvData_CustomDrawCell);
            this.grvData.FocusedRowChanged += new DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventHandler(this.grvData_FocusedRowChanged);
            // 
            // colID
            // 
            this.colID.Caption = "ID";
            this.colID.FieldName = "ID";
            this.colID.MinWidth = 217;
            this.colID.Name = "colID";
            this.colID.OptionsColumn.AllowEdit = false;
            this.colID.Width = 217;
            // 
            // colSTT
            // 
            this.colSTT.Caption = "STT";
            this.colSTT.FieldName = "STT";
            this.colSTT.Name = "colSTT";
            this.colSTT.Width = 65;
            // 
            // colCode
            // 
            this.colCode.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colCode.AppearanceCell.Options.UseFont = true;
            this.colCode.AppearanceCell.Options.UseTextOptions = true;
            this.colCode.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colCode.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colCode.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colCode.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.colCode.AppearanceHeader.Options.UseFont = true;
            this.colCode.AppearanceHeader.Options.UseForeColor = true;
            this.colCode.AppearanceHeader.Options.UseTextOptions = true;
            this.colCode.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colCode.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colCode.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colCode.Caption = "Mã lỗi vi phạm";
            this.colCode.ColumnEdit = this.repositoryItemMemoEdit1;
            this.colCode.FieldName = "Code";
            this.colCode.Name = "colCode";
            this.colCode.Visible = true;
            this.colCode.VisibleIndex = 0;
            this.colCode.Width = 100;
            // 
            // colTypeName_TH
            // 
            this.colTypeName_TH.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colTypeName_TH.AppearanceCell.Options.UseFont = true;
            this.colTypeName_TH.AppearanceCell.Options.UseTextOptions = true;
            this.colTypeName_TH.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colTypeName_TH.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colTypeName_TH.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colTypeName_TH.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.colTypeName_TH.AppearanceHeader.Options.UseFont = true;
            this.colTypeName_TH.AppearanceHeader.Options.UseForeColor = true;
            this.colTypeName_TH.AppearanceHeader.Options.UseTextOptions = true;
            this.colTypeName_TH.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colTypeName_TH.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colTypeName_TH.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colTypeName_TH.Caption = "Loại lỗi vi phạm";
            this.colTypeName_TH.ColumnEdit = this.repositoryItemMemoEdit1;
            this.colTypeName_TH.FieldName = "TypeName";
            this.colTypeName_TH.FieldNameSortGroup = "ErrorDate";
            this.colTypeName_TH.Name = "colTypeName_TH";
            this.colTypeName_TH.Visible = true;
            this.colTypeName_TH.VisibleIndex = 1;
            this.colTypeName_TH.Width = 120;
            // 
            // colContent
            // 
            this.colContent.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colContent.AppearanceCell.Options.UseFont = true;
            this.colContent.AppearanceCell.Options.UseTextOptions = true;
            this.colContent.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colContent.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colContent.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colContent.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.colContent.AppearanceHeader.Options.UseFont = true;
            this.colContent.AppearanceHeader.Options.UseForeColor = true;
            this.colContent.AppearanceHeader.Options.UseTextOptions = true;
            this.colContent.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colContent.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colContent.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colContent.Caption = "Nội dung lỗi vi phạm";
            this.colContent.ColumnEdit = this.repositoryItemMemoEdit1;
            this.colContent.FieldName = "Content";
            this.colContent.Name = "colContent";
            this.colContent.Visible = true;
            this.colContent.VisibleIndex = 1;
            this.colContent.Width = 300;
            // 
            // colEmployeeCode
            // 
            this.colEmployeeCode.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colEmployeeCode.AppearanceCell.Options.UseFont = true;
            this.colEmployeeCode.AppearanceCell.Options.UseTextOptions = true;
            this.colEmployeeCode.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colEmployeeCode.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colEmployeeCode.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colEmployeeCode.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.colEmployeeCode.AppearanceHeader.Options.UseFont = true;
            this.colEmployeeCode.AppearanceHeader.Options.UseForeColor = true;
            this.colEmployeeCode.AppearanceHeader.Options.UseTextOptions = true;
            this.colEmployeeCode.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colEmployeeCode.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colEmployeeCode.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colEmployeeCode.Caption = "Mã nhân viên";
            this.colEmployeeCode.ColumnEdit = this.repositoryItemMemoEdit1;
            this.colEmployeeCode.FieldName = "EmployeeCode";
            this.colEmployeeCode.Name = "colEmployeeCode";
            this.colEmployeeCode.Width = 82;
            // 
            // colEmployeeName
            // 
            this.colEmployeeName.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colEmployeeName.AppearanceCell.Options.UseFont = true;
            this.colEmployeeName.AppearanceCell.Options.UseTextOptions = true;
            this.colEmployeeName.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colEmployeeName.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colEmployeeName.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colEmployeeName.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.colEmployeeName.AppearanceHeader.Options.UseFont = true;
            this.colEmployeeName.AppearanceHeader.Options.UseForeColor = true;
            this.colEmployeeName.AppearanceHeader.Options.UseTextOptions = true;
            this.colEmployeeName.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colEmployeeName.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colEmployeeName.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colEmployeeName.Caption = "Tên nhân viên";
            this.colEmployeeName.ColumnEdit = this.repositoryItemMemoEdit1;
            this.colEmployeeName.FieldName = "EmployeeName";
            this.colEmployeeName.Name = "colEmployeeName";
            this.colEmployeeName.Width = 82;
            // 
            // colDepartmentName
            // 
            this.colDepartmentName.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colDepartmentName.AppearanceCell.Options.UseFont = true;
            this.colDepartmentName.AppearanceCell.Options.UseTextOptions = true;
            this.colDepartmentName.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colDepartmentName.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colDepartmentName.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colDepartmentName.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.colDepartmentName.AppearanceHeader.Options.UseFont = true;
            this.colDepartmentName.AppearanceHeader.Options.UseForeColor = true;
            this.colDepartmentName.AppearanceHeader.Options.UseTextOptions = true;
            this.colDepartmentName.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colDepartmentName.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colDepartmentName.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colDepartmentName.Caption = "Phòng ban";
            this.colDepartmentName.ColumnEdit = this.repositoryItemMemoEdit1;
            this.colDepartmentName.FieldName = "DepartmentName";
            this.colDepartmentName.Name = "colDepartmentName";
            this.colDepartmentName.Visible = true;
            this.colDepartmentName.VisibleIndex = 2;
            this.colDepartmentName.Width = 100;
            // 
            // colErrorDate
            // 
            this.colErrorDate.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colErrorDate.AppearanceCell.Options.UseFont = true;
            this.colErrorDate.AppearanceCell.Options.UseTextOptions = true;
            this.colErrorDate.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colErrorDate.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colErrorDate.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colErrorDate.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colErrorDate.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.colErrorDate.AppearanceHeader.Options.UseFont = true;
            this.colErrorDate.AppearanceHeader.Options.UseForeColor = true;
            this.colErrorDate.AppearanceHeader.Options.UseTextOptions = true;
            this.colErrorDate.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colErrorDate.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colErrorDate.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colErrorDate.Caption = "Ngày vi phạm";
            this.colErrorDate.ColumnEdit = this.repositoryItemMemoEdit1;
            this.colErrorDate.FieldName = "ErrorDate";
            this.colErrorDate.Name = "colErrorDate";
            this.colErrorDate.OptionsColumn.AllowEdit = false;
            this.colErrorDate.Visible = true;
            this.colErrorDate.VisibleIndex = 3;
            this.colErrorDate.Width = 100;
            // 
            // colErrorNumber
            // 
            this.colErrorNumber.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colErrorNumber.AppearanceCell.Options.UseFont = true;
            this.colErrorNumber.AppearanceCell.Options.UseTextOptions = true;
            this.colErrorNumber.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colErrorNumber.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colErrorNumber.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colErrorNumber.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.colErrorNumber.AppearanceHeader.Options.UseFont = true;
            this.colErrorNumber.AppearanceHeader.Options.UseForeColor = true;
            this.colErrorNumber.AppearanceHeader.Options.UseTextOptions = true;
            this.colErrorNumber.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colErrorNumber.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colErrorNumber.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colErrorNumber.Caption = "Số lần vi phạm";
            this.colErrorNumber.ColumnEdit = this.repositoryItemMemoEdit1;
            this.colErrorNumber.FieldName = "ErrorNumber";
            this.colErrorNumber.Name = "colErrorNumber";
            this.colErrorNumber.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "ErrorNumber", "{0:0.##}")});
            this.colErrorNumber.Visible = true;
            this.colErrorNumber.VisibleIndex = 4;
            this.colErrorNumber.Width = 60;
            // 
            // colCoefficient
            // 
            this.colCoefficient.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colCoefficient.AppearanceCell.Options.UseFont = true;
            this.colCoefficient.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colCoefficient.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.colCoefficient.AppearanceHeader.Options.UseFont = true;
            this.colCoefficient.AppearanceHeader.Options.UseForeColor = true;
            this.colCoefficient.Caption = "Hệ số";
            this.colCoefficient.FieldName = "Coefficient";
            this.colCoefficient.Name = "colCoefficient";
            this.colCoefficient.Visible = true;
            this.colCoefficient.VisibleIndex = 5;
            this.colCoefficient.Width = 60;
            // 
            // colMonney
            // 
            this.colMonney.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colMonney.AppearanceCell.Options.UseFont = true;
            this.colMonney.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colMonney.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.colMonney.AppearanceHeader.Options.UseFont = true;
            this.colMonney.AppearanceHeader.Options.UseForeColor = true;
            this.colMonney.Caption = "Tiền phạt";
            this.colMonney.DisplayFormat.FormatString = "#,000";
            this.colMonney.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.colMonney.FieldName = "Monney";
            this.colMonney.Name = "colMonney";
            this.colMonney.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "Monney", "{0:#,000}")});
            this.colMonney.Visible = true;
            this.colMonney.VisibleIndex = 6;
            this.colMonney.Width = 80;
            // 
            // colNote
            // 
            this.colNote.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colNote.AppearanceCell.Options.UseFont = true;
            this.colNote.AppearanceCell.Options.UseTextOptions = true;
            this.colNote.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colNote.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colNote.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colNote.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.colNote.AppearanceHeader.Options.UseFont = true;
            this.colNote.AppearanceHeader.Options.UseForeColor = true;
            this.colNote.AppearanceHeader.Options.UseTextOptions = true;
            this.colNote.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colNote.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colNote.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colNote.Caption = "Ghi chú";
            this.colNote.ColumnEdit = this.repositoryItemMemoEdit1;
            this.colNote.FieldName = "Note";
            this.colNote.Name = "colNote";
            this.colNote.Visible = true;
            this.colNote.VisibleIndex = 7;
            this.colNote.Width = 183;
            // 
            // colEmployee
            // 
            this.colEmployee.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colEmployee.AppearanceCell.Options.UseFont = true;
            this.colEmployee.AppearanceCell.Options.UseTextOptions = true;
            this.colEmployee.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colEmployee.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colEmployee.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colEmployee.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.colEmployee.AppearanceHeader.Options.UseFont = true;
            this.colEmployee.AppearanceHeader.Options.UseForeColor = true;
            this.colEmployee.AppearanceHeader.Options.UseTextOptions = true;
            this.colEmployee.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colEmployee.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colEmployee.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colEmployee.Caption = "Nhân viên";
            this.colEmployee.ColumnEdit = this.repositoryItemMemoEdit1;
            this.colEmployee.FieldName = "Employee";
            this.colEmployee.FieldNameSortGroup = "ErrorDate";
            this.colEmployee.Name = "colEmployee";
            this.colEmployee.Visible = true;
            this.colEmployee.VisibleIndex = 11;
            // 
            // panelControl2
            // 
            this.panelControl2.Controls.Add(this.stackPanel6);
            this.panelControl2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelControl2.Location = new System.Drawing.Point(0, 82);
            this.panelControl2.Name = "panelControl2";
            this.panelControl2.Size = new System.Drawing.Size(1392, 38);
            this.panelControl2.TabIndex = 36;
            // 
            // stackPanel6
            // 
            this.stackPanel6.AutoSize = true;
            this.stackPanel6.Controls.Add(this.label7);
            this.stackPanel6.Controls.Add(this.txtYearError);
            this.stackPanel6.Controls.Add(this.label8);
            this.stackPanel6.Controls.Add(this.txtMonthError);
            this.stackPanel6.Controls.Add(this.label11);
            this.stackPanel6.Controls.Add(this.cboKPIError);
            this.stackPanel6.Controls.Add(this.label2);
            this.stackPanel6.Controls.Add(this.cboEmployee);
            this.stackPanel6.Controls.Add(this.label19);
            this.stackPanel6.Controls.Add(this.txtKeyword);
            this.stackPanel6.Controls.Add(this.btnFind);
            this.stackPanel6.Controls.Add(this.btnExportExcel);
            this.stackPanel6.Dock = System.Windows.Forms.DockStyle.Left;
            this.stackPanel6.Location = new System.Drawing.Point(2, 2);
            this.stackPanel6.Name = "stackPanel6";
            this.stackPanel6.Size = new System.Drawing.Size(1269, 34);
            this.stackPanel6.TabIndex = 32;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(3, 9);
            this.label7.Name = "label7";
            this.label7.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label7.Size = new System.Drawing.Size(37, 16);
            this.label7.TabIndex = 270;
            this.label7.Text = "Năm";
            // 
            // txtYearError
            // 
            this.txtYearError.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtYearError.Location = new System.Drawing.Point(46, 5);
            this.txtYearError.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.txtYearError.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.txtYearError.Name = "txtYearError";
            this.txtYearError.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtYearError.Size = new System.Drawing.Size(60, 23);
            this.txtYearError.TabIndex = 273;
            this.txtYearError.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(112, 9);
            this.label8.Name = "label8";
            this.label8.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label8.Size = new System.Drawing.Size(47, 16);
            this.label8.TabIndex = 271;
            this.label8.Text = "Tháng";
            // 
            // txtMonthError
            // 
            this.txtMonthError.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMonthError.Location = new System.Drawing.Point(165, 5);
            this.txtMonthError.Maximum = new decimal(new int[] {
            12,
            0,
            0,
            0});
            this.txtMonthError.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.txtMonthError.Name = "txtMonthError";
            this.txtMonthError.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtMonthError.Size = new System.Drawing.Size(50, 23);
            this.txtMonthError.TabIndex = 272;
            this.txtMonthError.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.txtMonthError.ValueChanged += new System.EventHandler(this.txtMonthError_ValueChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(221, 9);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(76, 16);
            this.label11.TabIndex = 265;
            this.label11.Text = "Lỗi vi phạm";
            // 
            // cboKPIError
            // 
            this.cboKPIError.EditValue = "";
            this.cboKPIError.Location = new System.Drawing.Point(303, 6);
            this.cboKPIError.Name = "cboKPIError";
            this.cboKPIError.Properties.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboKPIError.Properties.Appearance.Options.UseFont = true;
            this.cboKPIError.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboKPIError.Properties.NullText = "";
            this.cboKPIError.Properties.PopupFormSize = new System.Drawing.Size(750, 500);
            this.cboKPIError.Properties.PopupView = this.searchLookUpEdit1View;
            this.cboKPIError.Properties.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemMemoEdit4});
            this.cboKPIError.Size = new System.Drawing.Size(200, 22);
            this.cboKPIError.TabIndex = 268;
            this.cboKPIError.EditValueChanged += new System.EventHandler(this.cboKPIError_EditValueChanged);
            // 
            // searchLookUpEdit1View
            // 
            this.searchLookUpEdit1View.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.searchLookUpEdit1View.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.searchLookUpEdit1View.ColumnPanelRowHeight = 30;
            this.searchLookUpEdit1View.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn20,
            this.gridColumn4,
            this.gridColumn1,
            this.gridColumn3,
            this.gridColumn6,
            this.gridColumn5,
            this.col});
            this.searchLookUpEdit1View.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.searchLookUpEdit1View.GroupCount = 1;
            this.searchLookUpEdit1View.Name = "searchLookUpEdit1View";
            this.searchLookUpEdit1View.OptionsBehavior.AutoExpandAllGroups = true;
            this.searchLookUpEdit1View.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.searchLookUpEdit1View.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.searchLookUpEdit1View.OptionsView.RowAutoHeight = true;
            this.searchLookUpEdit1View.OptionsView.ShowGroupPanel = false;
            this.searchLookUpEdit1View.SortInfo.AddRange(new DevExpress.XtraGrid.Columns.GridColumnSortInfo[] {
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.col, DevExpress.Data.ColumnSortOrder.Ascending)});
            // 
            // gridColumn20
            // 
            this.gridColumn20.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn20.AppearanceCell.Options.UseFont = true;
            this.gridColumn20.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn20.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridColumn20.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridColumn20.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn20.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.gridColumn20.AppearanceHeader.Options.UseFont = true;
            this.gridColumn20.AppearanceHeader.Options.UseForeColor = true;
            this.gridColumn20.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn20.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn20.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridColumn20.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridColumn20.Caption = "Mã lỗi vi phạm";
            this.gridColumn20.ColumnEdit = this.repositoryItemMemoEdit4;
            this.gridColumn20.FieldName = "Code";
            this.gridColumn20.Name = "gridColumn20";
            this.gridColumn20.Visible = true;
            this.gridColumn20.VisibleIndex = 0;
            this.gridColumn20.Width = 100;
            // 
            // repositoryItemMemoEdit4
            // 
            this.repositoryItemMemoEdit4.Name = "repositoryItemMemoEdit4";
            // 
            // gridColumn4
            // 
            this.gridColumn4.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn4.AppearanceCell.Options.UseFont = true;
            this.gridColumn4.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn4.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridColumn4.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridColumn4.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn4.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.gridColumn4.AppearanceHeader.Options.UseFont = true;
            this.gridColumn4.AppearanceHeader.Options.UseForeColor = true;
            this.gridColumn4.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn4.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn4.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridColumn4.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridColumn4.Caption = "Tên lỗi vi phạm";
            this.gridColumn4.ColumnEdit = this.repositoryItemMemoEdit4;
            this.gridColumn4.FieldName = "Name";
            this.gridColumn4.Name = "gridColumn4";
            this.gridColumn4.Width = 200;
            // 
            // gridColumn1
            // 
            this.gridColumn1.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn1.AppearanceCell.Options.UseFont = true;
            this.gridColumn1.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn1.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridColumn1.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridColumn1.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn1.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.gridColumn1.AppearanceHeader.Options.UseFont = true;
            this.gridColumn1.AppearanceHeader.Options.UseForeColor = true;
            this.gridColumn1.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn1.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn1.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridColumn1.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridColumn1.Caption = "Nội dung";
            this.gridColumn1.ColumnEdit = this.repositoryItemMemoEdit4;
            this.gridColumn1.FieldName = "Content";
            this.gridColumn1.Name = "gridColumn1";
            this.gridColumn1.Visible = true;
            this.gridColumn1.VisibleIndex = 1;
            this.gridColumn1.Width = 200;
            // 
            // gridColumn3
            // 
            this.gridColumn3.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn3.AppearanceCell.Options.UseFont = true;
            this.gridColumn3.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn3.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridColumn3.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridColumn3.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn3.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.gridColumn3.AppearanceHeader.Options.UseFont = true;
            this.gridColumn3.AppearanceHeader.Options.UseForeColor = true;
            this.gridColumn3.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn3.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn3.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridColumn3.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridColumn3.Caption = "Số vi phạm";
            this.gridColumn3.ColumnEdit = this.repositoryItemMemoEdit4;
            this.gridColumn3.FieldName = "Quantity";
            this.gridColumn3.Name = "gridColumn3";
            this.gridColumn3.Visible = true;
            this.gridColumn3.VisibleIndex = 2;
            this.gridColumn3.Width = 60;
            // 
            // gridColumn6
            // 
            this.gridColumn6.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn6.AppearanceCell.Options.UseFont = true;
            this.gridColumn6.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn6.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridColumn6.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridColumn6.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn6.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.gridColumn6.AppearanceHeader.Options.UseFont = true;
            this.gridColumn6.AppearanceHeader.Options.UseForeColor = true;
            this.gridColumn6.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn6.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn6.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridColumn6.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridColumn6.Caption = "Đơn vị";
            this.gridColumn6.ColumnEdit = this.repositoryItemMemoEdit4;
            this.gridColumn6.FieldName = "UnitText";
            this.gridColumn6.Name = "gridColumn6";
            this.gridColumn6.Visible = true;
            this.gridColumn6.VisibleIndex = 3;
            this.gridColumn6.Width = 60;
            // 
            // gridColumn5
            // 
            this.gridColumn5.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn5.AppearanceCell.Options.UseFont = true;
            this.gridColumn5.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn5.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridColumn5.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridColumn5.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn5.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.gridColumn5.AppearanceHeader.Options.UseFont = true;
            this.gridColumn5.AppearanceHeader.Options.UseForeColor = true;
            this.gridColumn5.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn5.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn5.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridColumn5.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridColumn5.Caption = "Tiền phạt";
            this.gridColumn5.ColumnEdit = this.repositoryItemMemoEdit4;
            this.gridColumn5.DisplayFormat.FormatString = "#,000";
            this.gridColumn5.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn5.FieldName = "Monney";
            this.gridColumn5.Name = "gridColumn5";
            this.gridColumn5.Visible = true;
            this.gridColumn5.VisibleIndex = 4;
            this.gridColumn5.Width = 80;
            // 
            // col
            // 
            this.col.Caption = "Loại lỗi vi phạm";
            this.col.FieldName = "TypeName";
            this.col.Name = "col";
            this.col.Visible = true;
            this.col.VisibleIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(509, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 16);
            this.label2.TabIndex = 266;
            this.label2.Text = "Nhân viên";
            // 
            // cboEmployee
            // 
            this.cboEmployee.Location = new System.Drawing.Point(583, 6);
            this.cboEmployee.Name = "cboEmployee";
            this.cboEmployee.Properties.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboEmployee.Properties.Appearance.Options.UseFont = true;
            this.cboEmployee.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboEmployee.Properties.NullText = "";
            this.cboEmployee.Properties.PopupView = this.gridView8;
            this.cboEmployee.Size = new System.Drawing.Size(200, 22);
            this.cboEmployee.TabIndex = 267;
            this.cboEmployee.EditValueChanged += new System.EventHandler(this.cboEmployee_EditValueChanged);
            // 
            // gridView8
            // 
            this.gridView8.Appearance.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.gridView8.Appearance.HeaderPanel.Options.UseFont = true;
            this.gridView8.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridView8.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.gridView8.Appearance.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridView8.Appearance.HeaderPanel.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridView8.Appearance.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridView8.Appearance.Row.Font = new System.Drawing.Font("Tahoma", 9.75F);
            this.gridView8.Appearance.Row.Options.UseFont = true;
            this.gridView8.Appearance.Row.Options.UseTextOptions = true;
            this.gridView8.Appearance.Row.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridView8.Appearance.Row.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridView8.ColumnPanelRowHeight = 40;
            this.gridView8.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn23,
            this.gridColumn24,
            this.gridColumn25});
            this.gridView8.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.gridView8.GroupCount = 1;
            this.gridView8.Name = "gridView8";
            this.gridView8.OptionsBehavior.AutoExpandAllGroups = true;
            this.gridView8.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridView8.OptionsView.RowAutoHeight = true;
            this.gridView8.OptionsView.ShowGroupPanel = false;
            this.gridView8.SortInfo.AddRange(new DevExpress.XtraGrid.Columns.GridColumnSortInfo[] {
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.gridColumn25, DevExpress.Data.ColumnSortOrder.Ascending)});
            // 
            // gridColumn23
            // 
            this.gridColumn23.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn23.AppearanceCell.Options.UseFont = true;
            this.gridColumn23.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn23.AppearanceHeader.Options.UseFont = true;
            this.gridColumn23.Caption = "Mã nhân viên";
            this.gridColumn23.FieldName = "Code";
            this.gridColumn23.Name = "gridColumn23";
            this.gridColumn23.Visible = true;
            this.gridColumn23.VisibleIndex = 0;
            this.gridColumn23.Width = 379;
            // 
            // gridColumn24
            // 
            this.gridColumn24.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn24.AppearanceCell.Options.UseFont = true;
            this.gridColumn24.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn24.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.gridColumn24.AppearanceHeader.Options.UseFont = true;
            this.gridColumn24.AppearanceHeader.Options.UseForeColor = true;
            this.gridColumn24.Caption = "Tên nhân viên";
            this.gridColumn24.FieldName = "FullName";
            this.gridColumn24.Name = "gridColumn24";
            this.gridColumn24.Visible = true;
            this.gridColumn24.VisibleIndex = 1;
            this.gridColumn24.Width = 659;
            // 
            // gridColumn25
            // 
            this.gridColumn25.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn25.AppearanceCell.Options.UseFont = true;
            this.gridColumn25.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn25.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.gridColumn25.AppearanceHeader.Options.UseFont = true;
            this.gridColumn25.AppearanceHeader.Options.UseForeColor = true;
            this.gridColumn25.Caption = "Phòng ban";
            this.gridColumn25.FieldName = "DepartmentName";
            this.gridColumn25.Name = "gridColumn25";
            this.gridColumn25.Visible = true;
            this.gridColumn25.VisibleIndex = 2;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(789, 9);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(57, 16);
            this.label19.TabIndex = 0;
            this.label19.Text = "Từ khoá";
            // 
            // txtKeyword
            // 
            this.txtKeyword.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtKeyword.Location = new System.Drawing.Point(851, 6);
            this.txtKeyword.Margin = new System.Windows.Forms.Padding(2);
            this.txtKeyword.Name = "txtKeyword";
            this.txtKeyword.Size = new System.Drawing.Size(250, 22);
            this.txtKeyword.TabIndex = 263;
            this.txtKeyword.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtKeyword_KeyDown);
            // 
            // btnFind
            // 
            this.btnFind.AutoSize = true;
            this.btnFind.FlatAppearance.BorderColor = System.Drawing.Color.Green;
            this.btnFind.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFind.Location = new System.Drawing.Point(1105, 4);
            this.btnFind.Margin = new System.Windows.Forms.Padding(2);
            this.btnFind.Name = "btnFind";
            this.btnFind.Size = new System.Drawing.Size(73, 26);
            this.btnFind.TabIndex = 264;
            this.btnFind.Text = "Tìm kiếm";
            this.btnFind.UseVisualStyleBackColor = true;
            this.btnFind.Click += new System.EventHandler(this.btnFind_Click);
            // 
            // btnExportExcel
            // 
            this.btnExportExcel.AutoSize = true;
            this.btnExportExcel.FlatAppearance.BorderColor = System.Drawing.Color.Green;
            this.btnExportExcel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExportExcel.Location = new System.Drawing.Point(1182, 4);
            this.btnExportExcel.Margin = new System.Windows.Forms.Padding(2);
            this.btnExportExcel.Name = "btnExportExcel";
            this.btnExportExcel.Size = new System.Drawing.Size(85, 26);
            this.btnExportExcel.TabIndex = 269;
            this.btnExportExcel.Text = "Xuất Excel";
            this.btnExportExcel.UseVisualStyleBackColor = true;
            this.btnExportExcel.Visible = false;
            this.btnExportExcel.Click += new System.EventHandler(this.btnExportExcel_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.stackPanel5);
            this.groupBox1.Controls.Add(this.labelControl3);
            this.groupBox1.Controls.Add(this.labelControl2);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.Red;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1392, 82);
            this.groupBox1.TabIndex = 38;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Chú ý";
            // 
            // stackPanel5
            // 
            this.stackPanel5.AutoSize = true;
            this.stackPanel5.Controls.Add(this.label14);
            this.stackPanel5.Controls.Add(this.label16);
            this.stackPanel5.Controls.Add(this.label17);
            this.stackPanel5.Controls.Add(this.label18);
            this.stackPanel5.Location = new System.Drawing.Point(1088, 23);
            this.stackPanel5.Name = "stackPanel5";
            this.stackPanel5.Size = new System.Drawing.Size(298, 28);
            this.stackPanel5.TabIndex = 34;
            // 
            // label14
            // 
            this.label14.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(74)))));
            this.label14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label14.Location = new System.Drawing.Point(3, 6);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(35, 15);
            this.label14.TabIndex = 23;
            // 
            // label16
            // 
            this.label16.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(44, 7);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(93, 13);
            this.label16.TabIndex = 24;
            this.label16.Text = "Vi phạm trên 2 lần";
            // 
            // label17
            // 
            this.label17.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label17.BackColor = System.Drawing.Color.Orange;
            this.label17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label17.Location = new System.Drawing.Point(143, 6);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(35, 15);
            this.label17.TabIndex = 32;
            // 
            // label18
            // 
            this.label18.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(184, 7);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(111, 13);
            this.label18.TabIndex = 33;
            this.label18.Text = "X2 lần hệ số tiền phạt";
            // 
            // labelControl3
            // 
            this.labelControl3.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl3.Appearance.ForeColor = System.Drawing.Color.Red;
            this.labelControl3.Appearance.Options.UseFont = true;
            this.labelControl3.Appearance.Options.UseForeColor = true;
            this.labelControl3.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.Horizontal;
            this.labelControl3.Dock = System.Windows.Forms.DockStyle.Top;
            this.labelControl3.Location = new System.Drawing.Point(3, 51);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Padding = new System.Windows.Forms.Padding(5);
            this.labelControl3.Size = new System.Drawing.Size(652, 28);
            this.labelControl3.TabIndex = 39;
            this.labelControl3.Text = "- 3 lần \"báo cáo công việc muộn\" sẽ tính là 1 lần bị phạt và hệ số tiền phạt mặc " +
    "định X1.";
            // 
            // labelControl2
            // 
            this.labelControl2.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl2.Appearance.ForeColor = System.Drawing.Color.Red;
            this.labelControl2.Appearance.Options.UseFont = true;
            this.labelControl2.Appearance.Options.UseForeColor = true;
            this.labelControl2.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.Horizontal;
            this.labelControl2.Dock = System.Windows.Forms.DockStyle.Top;
            this.labelControl2.Location = new System.Drawing.Point(3, 23);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Padding = new System.Windows.Forms.Padding(5);
            this.labelControl2.Size = new System.Drawing.Size(658, 28);
            this.labelControl2.TabIndex = 38;
            this.labelControl2.Text = "- Hệ số tiền phạt sẽ X2 lần nếu nhân viên vi phạm lại lỗi của 2 tuần đầu tiên tro" +
    "ng tháng.";
            // 
            // splitContainerControl1
            // 
            this.splitContainerControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainerControl1.Horizontal = false;
            this.splitContainerControl1.Location = new System.Drawing.Point(0, 0);
            this.splitContainerControl1.Name = "splitContainerControl1";
            // 
            // splitContainerControl1.Panel1
            // 
            this.splitContainerControl1.Panel1.Controls.Add(this.grdDataFile);
            this.splitContainerControl1.Panel1.Text = "Panel1";
            // 
            // splitContainerControl1.Panel2
            // 
            this.splitContainerControl1.Panel2.Controls.Add(this.pictureBox);
            this.splitContainerControl1.Panel2.Text = "Panel2";
            this.splitContainerControl1.Size = new System.Drawing.Size(516, 593);
            this.splitContainerControl1.SplitterPosition = 377;
            this.splitContainerControl1.TabIndex = 1;
            // 
            // grdDataFile
            // 
            this.grdDataFile.ContextMenuStrip = this.contextMenuStrip1;
            this.grdDataFile.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdDataFile.Location = new System.Drawing.Point(0, 0);
            this.grdDataFile.MainView = this.grvDataFile;
            this.grdDataFile.Name = "grdDataFile";
            this.grdDataFile.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemMemoEdit6,
            this.btnDownloadFile});
            this.grdDataFile.Size = new System.Drawing.Size(516, 377);
            this.grdDataFile.TabIndex = 1;
            this.grdDataFile.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.grvDataFile});
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnShowImage});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(122, 26);
            // 
            // btnShowImage
            // 
            this.btnShowImage.Name = "btnShowImage";
            this.btnShowImage.Size = new System.Drawing.Size(121, 22);
            this.btnShowImage.Text = "Xem ảnh";
            this.btnShowImage.Click += new System.EventHandler(this.btnShowImage_Click);
            // 
            // grvDataFile
            // 
            this.grvDataFile.Appearance.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grvDataFile.Appearance.HeaderPanel.Options.UseFont = true;
            this.grvDataFile.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.grvDataFile.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.grvDataFile.Appearance.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.grvDataFile.Appearance.HeaderPanel.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.grvDataFile.Appearance.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.grvDataFile.Appearance.Row.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grvDataFile.Appearance.Row.Options.UseFont = true;
            this.grvDataFile.Appearance.Row.Options.UseTextOptions = true;
            this.grvDataFile.Appearance.Row.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.grvDataFile.Appearance.Row.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.grvDataFile.ColumnPanelRowHeight = 40;
            this.grvDataFile.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colFileID,
            this.colFileName,
            this.colErrorDateFile,
            this.colEmployeeFile,
            this.colErrorNameFile});
            this.grvDataFile.GridControl = this.grdDataFile;
            this.grvDataFile.GroupCount = 2;
            this.grvDataFile.Name = "grvDataFile";
            this.grvDataFile.OptionsBehavior.AutoExpandAllGroups = true;
            this.grvDataFile.OptionsClipboard.CopyColumnHeaders = DevExpress.Utils.DefaultBoolean.False;
            this.grvDataFile.OptionsSelection.CheckBoxSelectorColumnWidth = 30;
            this.grvDataFile.OptionsSelection.MultiSelect = true;
            this.grvDataFile.OptionsSelection.MultiSelectMode = DevExpress.XtraGrid.Views.Grid.GridMultiSelectMode.CheckBoxRowSelect;
            this.grvDataFile.OptionsSelection.ShowCheckBoxSelectorInGroupRow = DevExpress.Utils.DefaultBoolean.True;
            this.grvDataFile.OptionsView.RowAutoHeight = true;
            this.grvDataFile.OptionsView.ShowGroupPanel = false;
            this.grvDataFile.SortInfo.AddRange(new DevExpress.XtraGrid.Columns.GridColumnSortInfo[] {
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.colEmployeeFile, DevExpress.Data.ColumnSortOrder.Ascending),
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.colErrorNameFile, DevExpress.Data.ColumnSortOrder.Ascending)});
            this.grvDataFile.FocusedRowChanged += new DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventHandler(this.grvDataFile_FocusedRowChanged);
            // 
            // colFileID
            // 
            this.colFileID.FieldName = "ID";
            this.colFileID.Name = "colFileID";
            this.colFileID.Width = 37;
            // 
            // colFileName
            // 
            this.colFileName.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colFileName.AppearanceCell.Options.UseFont = true;
            this.colFileName.AppearanceCell.Options.UseTextOptions = true;
            this.colFileName.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colFileName.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colFileName.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colFileName.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.colFileName.AppearanceHeader.Options.UseFont = true;
            this.colFileName.AppearanceHeader.Options.UseForeColor = true;
            this.colFileName.AppearanceHeader.Options.UseTextOptions = true;
            this.colFileName.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colFileName.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colFileName.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colFileName.Caption = "File ảnh đính kèm";
            this.colFileName.ColumnEdit = this.repositoryItemMemoEdit6;
            this.colFileName.FieldName = "FileName";
            this.colFileName.Name = "colFileName";
            this.colFileName.OptionsColumn.AllowEdit = false;
            this.colFileName.OptionsColumn.ReadOnly = true;
            this.colFileName.Visible = true;
            this.colFileName.VisibleIndex = 1;
            this.colFileName.Width = 325;
            // 
            // repositoryItemMemoEdit6
            // 
            this.repositoryItemMemoEdit6.Name = "repositoryItemMemoEdit6";
            // 
            // colErrorDateFile
            // 
            this.colErrorDateFile.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colErrorDateFile.AppearanceCell.Options.UseFont = true;
            this.colErrorDateFile.AppearanceCell.Options.UseTextOptions = true;
            this.colErrorDateFile.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colErrorDateFile.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colErrorDateFile.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colErrorDateFile.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colErrorDateFile.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.colErrorDateFile.AppearanceHeader.Options.UseFont = true;
            this.colErrorDateFile.AppearanceHeader.Options.UseForeColor = true;
            this.colErrorDateFile.AppearanceHeader.Options.UseTextOptions = true;
            this.colErrorDateFile.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colErrorDateFile.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colErrorDateFile.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colErrorDateFile.Caption = "Ngày vi phạm";
            this.colErrorDateFile.ColumnEdit = this.repositoryItemMemoEdit6;
            this.colErrorDateFile.DisplayFormat.FormatString = "dd";
            this.colErrorDateFile.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.colErrorDateFile.FieldName = "ErrorDate";
            this.colErrorDateFile.Name = "colErrorDateFile";
            this.colErrorDateFile.OptionsColumn.AllowEdit = false;
            this.colErrorDateFile.Visible = true;
            this.colErrorDateFile.VisibleIndex = 2;
            this.colErrorDateFile.Width = 115;
            // 
            // colEmployeeFile
            // 
            this.colEmployeeFile.Caption = "Nhân viên";
            this.colEmployeeFile.FieldName = "Employee";
            this.colEmployeeFile.Name = "colEmployeeFile";
            // 
            // colErrorNameFile
            // 
            this.colErrorNameFile.Caption = "Tên lỗi";
            this.colErrorNameFile.FieldName = "ErrorName";
            this.colErrorNameFile.Name = "colErrorNameFile";
            // 
            // btnDownloadFile
            // 
            this.btnDownloadFile.AutoHeight = false;
            editorButtonImageOptions1.Image = global::Forms.Properties.Resources.download_16x16;
            this.btnDownloadFile.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Glyph, "", -1, true, true, false, editorButtonImageOptions1, new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject1, serializableAppearanceObject2, serializableAppearanceObject3, serializableAppearanceObject4, "", null, null, DevExpress.Utils.ToolTipAnchor.Default)});
            this.btnDownloadFile.Name = "btnDownloadFile";
            this.btnDownloadFile.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            // 
            // pictureBox
            // 
            this.pictureBox.BackColor = System.Drawing.Color.White;
            this.pictureBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox.Location = new System.Drawing.Point(0, 0);
            this.pictureBox.Name = "pictureBox";
            this.pictureBox.Size = new System.Drawing.Size(516, 206);
            this.pictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox.TabIndex = 0;
            this.pictureBox.TabStop = false;
            // 
            // stackPanel1
            // 
            this.stackPanel1.AutoSize = true;
            this.stackPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.stackPanel1.Location = new System.Drawing.Point(0, 0);
            this.stackPanel1.Margin = new System.Windows.Forms.Padding(2);
            this.stackPanel1.Name = "stackPanel1";
            this.stackPanel1.Size = new System.Drawing.Size(1918, 0);
            this.stackPanel1.TabIndex = 28;
            // 
            // ttThongKe
            // 
            this.ttThongKe.Controls.Add(this.grdData_TK);
            this.ttThongKe.Controls.Add(this.panelControl3);
            this.ttThongKe.Name = "ttThongKe";
            this.ttThongKe.Size = new System.Drawing.Size(1918, 593);
            this.ttThongKe.Text = "THỐNG KÊ LỖI VI PHẠM";
            // 
            // grdData_TK
            // 
            this.grdData_TK.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdData_TK.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(36, 39, 36, 39);
            this.grdData_TK.Location = new System.Drawing.Point(0, 33);
            this.grdData_TK.MainView = this.grvData_TK;
            this.grdData_TK.Margin = new System.Windows.Forms.Padding(36, 39, 36, 39);
            this.grdData_TK.Name = "grdData_TK";
            this.grdData_TK.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemMemoEdit5});
            this.grdData_TK.Size = new System.Drawing.Size(1918, 560);
            this.grdData_TK.TabIndex = 29;
            this.grdData_TK.Tag = "";
            this.grdData_TK.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.grvData_TK});
            // 
            // grvData_TK
            // 
            this.grvData_TK.Appearance.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.grvData_TK.Appearance.HeaderPanel.Options.UseFont = true;
            this.grvData_TK.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.grvData_TK.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.grvData_TK.Appearance.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.grvData_TK.Appearance.HeaderPanel.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.grvData_TK.Appearance.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.grvData_TK.Appearance.Row.Font = new System.Drawing.Font("Tahoma", 9.75F);
            this.grvData_TK.Appearance.Row.Options.UseFont = true;
            this.grvData_TK.Appearance.Row.Options.UseTextOptions = true;
            this.grvData_TK.Appearance.Row.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.grvData_TK.Appearance.Row.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.grvData_TK.ColumnPanelRowHeight = 50;
            this.grvData_TK.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colKPIErrorID,
            this.colKPIErrorCode,
            this.colTypeName_TK,
            this.colKPIErrorContent,
            this.colQuantity,
            this.colUnit,
            this.colKPIErrorMonney,
            this.colErrorNote,
            this.colWeek1,
            this.colWeek2,
            this.colWeek3,
            this.colWeek4,
            this.colWeek5,
            this.colWeek6,
            this.colMonth});
            this.grvData_TK.DetailHeight = 4125;
            this.grvData_TK.GridControl = this.grdData_TK;
            this.grvData_TK.GroupCount = 1;
            this.grvData_TK.Name = "grvData_TK";
            this.grvData_TK.OptionsBehavior.AutoExpandAllGroups = true;
            this.grvData_TK.OptionsBehavior.Editable = false;
            this.grvData_TK.OptionsPrint.AutoWidth = false;
            this.grvData_TK.OptionsSelection.CheckBoxSelectorColumnWidth = 30;
            this.grvData_TK.OptionsSelection.MultiSelect = true;
            this.grvData_TK.OptionsSelection.ShowCheckBoxSelectorInPrintExport = DevExpress.Utils.DefaultBoolean.False;
            this.grvData_TK.OptionsView.RowAutoHeight = true;
            this.grvData_TK.OptionsView.ShowAutoFilterRow = true;
            this.grvData_TK.OptionsView.ShowFooter = true;
            this.grvData_TK.OptionsView.ShowGroupPanel = false;
            this.grvData_TK.SortInfo.AddRange(new DevExpress.XtraGrid.Columns.GridColumnSortInfo[] {
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.colTypeName_TK, DevExpress.Data.ColumnSortOrder.Ascending)});
            this.grvData_TK.Tag = "";
            this.grvData_TK.CustomDrawCell += new DevExpress.XtraGrid.Views.Base.RowCellCustomDrawEventHandler(this.grvData_TK_CustomDrawCell);
            // 
            // colKPIErrorID
            // 
            this.colKPIErrorID.Caption = "ID";
            this.colKPIErrorID.FieldName = "ID";
            this.colKPIErrorID.MinWidth = 217;
            this.colKPIErrorID.Name = "colKPIErrorID";
            this.colKPIErrorID.OptionsColumn.AllowEdit = false;
            this.colKPIErrorID.Width = 217;
            // 
            // colKPIErrorCode
            // 
            this.colKPIErrorCode.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colKPIErrorCode.AppearanceCell.Options.UseFont = true;
            this.colKPIErrorCode.AppearanceCell.Options.UseTextOptions = true;
            this.colKPIErrorCode.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colKPIErrorCode.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colKPIErrorCode.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colKPIErrorCode.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.colKPIErrorCode.AppearanceHeader.Options.UseFont = true;
            this.colKPIErrorCode.AppearanceHeader.Options.UseForeColor = true;
            this.colKPIErrorCode.AppearanceHeader.Options.UseTextOptions = true;
            this.colKPIErrorCode.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colKPIErrorCode.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colKPIErrorCode.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colKPIErrorCode.Caption = "Mã lỗi vi phạm";
            this.colKPIErrorCode.ColumnEdit = this.repositoryItemMemoEdit5;
            this.colKPIErrorCode.FieldName = "Code";
            this.colKPIErrorCode.Name = "colKPIErrorCode";
            this.colKPIErrorCode.Visible = true;
            this.colKPIErrorCode.VisibleIndex = 0;
            this.colKPIErrorCode.Width = 134;
            // 
            // repositoryItemMemoEdit5
            // 
            this.repositoryItemMemoEdit5.Name = "repositoryItemMemoEdit5";
            // 
            // colTypeName_TK
            // 
            this.colTypeName_TK.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colTypeName_TK.AppearanceCell.Options.UseFont = true;
            this.colTypeName_TK.AppearanceCell.Options.UseTextOptions = true;
            this.colTypeName_TK.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colTypeName_TK.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colTypeName_TK.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colTypeName_TK.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.colTypeName_TK.AppearanceHeader.Options.UseFont = true;
            this.colTypeName_TK.AppearanceHeader.Options.UseForeColor = true;
            this.colTypeName_TK.AppearanceHeader.Options.UseTextOptions = true;
            this.colTypeName_TK.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colTypeName_TK.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colTypeName_TK.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colTypeName_TK.Caption = "Loại lỗi vi phạm";
            this.colTypeName_TK.ColumnEdit = this.repositoryItemMemoEdit5;
            this.colTypeName_TK.FieldName = "TypeName";
            this.colTypeName_TK.Name = "colTypeName_TK";
            this.colTypeName_TK.Visible = true;
            this.colTypeName_TK.VisibleIndex = 1;
            this.colTypeName_TK.Width = 211;
            // 
            // colKPIErrorContent
            // 
            this.colKPIErrorContent.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colKPIErrorContent.AppearanceCell.Options.UseFont = true;
            this.colKPIErrorContent.AppearanceCell.Options.UseTextOptions = true;
            this.colKPIErrorContent.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colKPIErrorContent.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colKPIErrorContent.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colKPIErrorContent.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.colKPIErrorContent.AppearanceHeader.Options.UseFont = true;
            this.colKPIErrorContent.AppearanceHeader.Options.UseForeColor = true;
            this.colKPIErrorContent.AppearanceHeader.Options.UseTextOptions = true;
            this.colKPIErrorContent.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colKPIErrorContent.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colKPIErrorContent.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colKPIErrorContent.Caption = "Nội dung lỗi vi phạm";
            this.colKPIErrorContent.ColumnEdit = this.repositoryItemMemoEdit5;
            this.colKPIErrorContent.FieldName = "Content";
            this.colKPIErrorContent.Name = "colKPIErrorContent";
            this.colKPIErrorContent.Visible = true;
            this.colKPIErrorContent.VisibleIndex = 1;
            this.colKPIErrorContent.Width = 288;
            // 
            // colQuantity
            // 
            this.colQuantity.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colQuantity.AppearanceCell.Options.UseFont = true;
            this.colQuantity.AppearanceCell.Options.UseTextOptions = true;
            this.colQuantity.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colQuantity.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colQuantity.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colQuantity.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.colQuantity.AppearanceHeader.Options.UseFont = true;
            this.colQuantity.AppearanceHeader.Options.UseForeColor = true;
            this.colQuantity.AppearanceHeader.Options.UseTextOptions = true;
            this.colQuantity.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colQuantity.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colQuantity.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colQuantity.Caption = "Số vi phạm";
            this.colQuantity.ColumnEdit = this.repositoryItemMemoEdit5;
            this.colQuantity.FieldName = "Quantity";
            this.colQuantity.Name = "colQuantity";
            this.colQuantity.Visible = true;
            this.colQuantity.VisibleIndex = 2;
            this.colQuantity.Width = 67;
            // 
            // colUnit
            // 
            this.colUnit.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colUnit.AppearanceCell.Options.UseFont = true;
            this.colUnit.AppearanceCell.Options.UseTextOptions = true;
            this.colUnit.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colUnit.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colUnit.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colUnit.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.colUnit.AppearanceHeader.Options.UseFont = true;
            this.colUnit.AppearanceHeader.Options.UseForeColor = true;
            this.colUnit.AppearanceHeader.Options.UseTextOptions = true;
            this.colUnit.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colUnit.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colUnit.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colUnit.Caption = "Đơn vị";
            this.colUnit.ColumnEdit = this.repositoryItemMemoEdit5;
            this.colUnit.FieldName = "UnitText";
            this.colUnit.Name = "colUnit";
            this.colUnit.Visible = true;
            this.colUnit.VisibleIndex = 3;
            this.colUnit.Width = 48;
            // 
            // colKPIErrorMonney
            // 
            this.colKPIErrorMonney.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colKPIErrorMonney.AppearanceCell.Options.UseFont = true;
            this.colKPIErrorMonney.AppearanceCell.Options.UseTextOptions = true;
            this.colKPIErrorMonney.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colKPIErrorMonney.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colKPIErrorMonney.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colKPIErrorMonney.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.colKPIErrorMonney.AppearanceHeader.Options.UseFont = true;
            this.colKPIErrorMonney.AppearanceHeader.Options.UseForeColor = true;
            this.colKPIErrorMonney.AppearanceHeader.Options.UseTextOptions = true;
            this.colKPIErrorMonney.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colKPIErrorMonney.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colKPIErrorMonney.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colKPIErrorMonney.Caption = "Tiền phạt";
            this.colKPIErrorMonney.ColumnEdit = this.repositoryItemMemoEdit5;
            this.colKPIErrorMonney.DisplayFormat.FormatString = "#,000";
            this.colKPIErrorMonney.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Custom;
            this.colKPIErrorMonney.FieldName = "Monney";
            this.colKPIErrorMonney.Name = "colKPIErrorMonney";
            this.colKPIErrorMonney.Visible = true;
            this.colKPIErrorMonney.VisibleIndex = 4;
            this.colKPIErrorMonney.Width = 76;
            // 
            // colErrorNote
            // 
            this.colErrorNote.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colErrorNote.AppearanceCell.Options.UseFont = true;
            this.colErrorNote.AppearanceCell.Options.UseTextOptions = true;
            this.colErrorNote.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colErrorNote.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colErrorNote.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colErrorNote.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.colErrorNote.AppearanceHeader.Options.UseFont = true;
            this.colErrorNote.AppearanceHeader.Options.UseForeColor = true;
            this.colErrorNote.AppearanceHeader.Options.UseTextOptions = true;
            this.colErrorNote.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colErrorNote.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colErrorNote.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colErrorNote.Caption = "Ghi chú";
            this.colErrorNote.ColumnEdit = this.repositoryItemMemoEdit5;
            this.colErrorNote.FieldName = "Note";
            this.colErrorNote.Name = "colErrorNote";
            this.colErrorNote.Visible = true;
            this.colErrorNote.VisibleIndex = 5;
            this.colErrorNote.Width = 192;
            // 
            // colWeek1
            // 
            this.colWeek1.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colWeek1.AppearanceCell.Options.UseFont = true;
            this.colWeek1.AppearanceCell.Options.UseTextOptions = true;
            this.colWeek1.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colWeek1.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colWeek1.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colWeek1.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.colWeek1.AppearanceHeader.Options.UseFont = true;
            this.colWeek1.AppearanceHeader.Options.UseForeColor = true;
            this.colWeek1.AppearanceHeader.Options.UseTextOptions = true;
            this.colWeek1.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colWeek1.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colWeek1.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colWeek1.Caption = "Tuần 1 (1 - 7)";
            this.colWeek1.ColumnEdit = this.repositoryItemMemoEdit5;
            this.colWeek1.FieldName = "Week1";
            this.colWeek1.Name = "colWeek1";
            this.colWeek1.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "Week1", "{0:0.##}")});
            this.colWeek1.Visible = true;
            this.colWeek1.VisibleIndex = 6;
            this.colWeek1.Width = 125;
            // 
            // colWeek2
            // 
            this.colWeek2.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colWeek2.AppearanceCell.Options.UseFont = true;
            this.colWeek2.AppearanceCell.Options.UseTextOptions = true;
            this.colWeek2.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colWeek2.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colWeek2.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colWeek2.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.colWeek2.AppearanceHeader.Options.UseFont = true;
            this.colWeek2.AppearanceHeader.Options.UseForeColor = true;
            this.colWeek2.AppearanceHeader.Options.UseTextOptions = true;
            this.colWeek2.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colWeek2.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colWeek2.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colWeek2.Caption = "Tuần 2 (8 - 14)";
            this.colWeek2.ColumnEdit = this.repositoryItemMemoEdit5;
            this.colWeek2.FieldName = "Week2";
            this.colWeek2.Name = "colWeek2";
            this.colWeek2.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "Week2", "{0:0.##}")});
            this.colWeek2.Visible = true;
            this.colWeek2.VisibleIndex = 7;
            this.colWeek2.Width = 125;
            // 
            // colWeek3
            // 
            this.colWeek3.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colWeek3.AppearanceCell.Options.UseFont = true;
            this.colWeek3.AppearanceCell.Options.UseTextOptions = true;
            this.colWeek3.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colWeek3.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colWeek3.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colWeek3.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.colWeek3.AppearanceHeader.Options.UseFont = true;
            this.colWeek3.AppearanceHeader.Options.UseForeColor = true;
            this.colWeek3.AppearanceHeader.Options.UseTextOptions = true;
            this.colWeek3.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colWeek3.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colWeek3.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colWeek3.Caption = "Tuần 3 (15 - 21)";
            this.colWeek3.ColumnEdit = this.repositoryItemMemoEdit5;
            this.colWeek3.FieldName = "Week3";
            this.colWeek3.Name = "colWeek3";
            this.colWeek3.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "Week3", "{0:0.##}")});
            this.colWeek3.Visible = true;
            this.colWeek3.VisibleIndex = 8;
            this.colWeek3.Width = 125;
            // 
            // colWeek4
            // 
            this.colWeek4.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colWeek4.AppearanceCell.Options.UseFont = true;
            this.colWeek4.AppearanceCell.Options.UseTextOptions = true;
            this.colWeek4.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colWeek4.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colWeek4.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colWeek4.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.colWeek4.AppearanceHeader.Options.UseFont = true;
            this.colWeek4.AppearanceHeader.Options.UseForeColor = true;
            this.colWeek4.AppearanceHeader.Options.UseTextOptions = true;
            this.colWeek4.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colWeek4.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colWeek4.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colWeek4.Caption = "Tuần 4 (22 - 28)";
            this.colWeek4.ColumnEdit = this.repositoryItemMemoEdit5;
            this.colWeek4.FieldName = "Week4";
            this.colWeek4.Name = "colWeek4";
            this.colWeek4.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "Week4", "{0:0.##}")});
            this.colWeek4.Visible = true;
            this.colWeek4.VisibleIndex = 9;
            this.colWeek4.Width = 125;
            // 
            // colWeek5
            // 
            this.colWeek5.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colWeek5.AppearanceCell.Options.UseFont = true;
            this.colWeek5.AppearanceCell.Options.UseTextOptions = true;
            this.colWeek5.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colWeek5.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colWeek5.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colWeek5.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.colWeek5.AppearanceHeader.Options.UseFont = true;
            this.colWeek5.AppearanceHeader.Options.UseForeColor = true;
            this.colWeek5.AppearanceHeader.Options.UseTextOptions = true;
            this.colWeek5.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colWeek5.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colWeek5.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colWeek5.Caption = "Tuần 5 (29 - 31)";
            this.colWeek5.ColumnEdit = this.repositoryItemMemoEdit5;
            this.colWeek5.FieldName = "Week5";
            this.colWeek5.Name = "colWeek5";
            this.colWeek5.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "Week5", "{0:0.##}")});
            this.colWeek5.Visible = true;
            this.colWeek5.VisibleIndex = 10;
            this.colWeek5.Width = 125;
            // 
            // colWeek6
            // 
            this.colWeek6.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colWeek6.AppearanceCell.Options.UseFont = true;
            this.colWeek6.AppearanceCell.Options.UseTextOptions = true;
            this.colWeek6.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colWeek6.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colWeek6.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colWeek6.AppearanceHeader.Options.UseFont = true;
            this.colWeek6.AppearanceHeader.Options.UseTextOptions = true;
            this.colWeek6.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colWeek6.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colWeek6.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colWeek6.Caption = "Tuần 6 (0 - 0)";
            this.colWeek6.ColumnEdit = this.repositoryItemMemoEdit5;
            this.colWeek6.FieldName = "Week6";
            this.colWeek6.Name = "colWeek6";
            this.colWeek6.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "Week6", "{0:0.##}")});
            this.colWeek6.Visible = true;
            this.colWeek6.VisibleIndex = 11;
            this.colWeek6.Width = 125;
            // 
            // colMonth
            // 
            this.colMonth.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colMonth.AppearanceCell.Options.UseFont = true;
            this.colMonth.AppearanceCell.Options.UseTextOptions = true;
            this.colMonth.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colMonth.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colMonth.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colMonth.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.colMonth.AppearanceHeader.Options.UseFont = true;
            this.colMonth.AppearanceHeader.Options.UseForeColor = true;
            this.colMonth.AppearanceHeader.Options.UseTextOptions = true;
            this.colMonth.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colMonth.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colMonth.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colMonth.Caption = "Tháng";
            this.colMonth.ColumnEdit = this.repositoryItemMemoEdit5;
            this.colMonth.FieldName = "Month";
            this.colMonth.Name = "colMonth";
            this.colMonth.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "Month", "{0:0.##}")});
            this.colMonth.Visible = true;
            this.colMonth.VisibleIndex = 12;
            this.colMonth.Width = 127;
            // 
            // panelControl3
            // 
            this.panelControl3.Controls.Add(this.stackPanel3);
            this.panelControl3.Controls.Add(this.stackPanel4);
            this.panelControl3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelControl3.Location = new System.Drawing.Point(0, 0);
            this.panelControl3.Name = "panelControl3";
            this.panelControl3.Size = new System.Drawing.Size(1918, 33);
            this.panelControl3.TabIndex = 35;
            // 
            // stackPanel3
            // 
            this.stackPanel3.AutoSize = true;
            this.stackPanel3.Controls.Add(this.label9);
            this.stackPanel3.Controls.Add(this.label10);
            this.stackPanel3.Controls.Add(this.label12);
            this.stackPanel3.Controls.Add(this.label13);
            this.stackPanel3.Dock = System.Windows.Forms.DockStyle.Right;
            this.stackPanel3.Location = new System.Drawing.Point(1916, 2);
            this.stackPanel3.Name = "stackPanel3";
            this.stackPanel3.Size = new System.Drawing.Size(0, 29);
            this.stackPanel3.TabIndex = 34;
            // 
            // label9
            // 
            this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(74)))));
            this.label9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label9.Location = new System.Drawing.Point(3, 7);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(35, 15);
            this.label9.TabIndex = 23;
            // 
            // label10
            // 
            this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(44, 8);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(91, 13);
            this.label10.TabIndex = 24;
            this.label10.Text = "Trên 5 lỗi vi phạm";
            // 
            // label12
            // 
            this.label12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(31)))), ((int)(((byte)(62)))));
            this.label12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label12.Location = new System.Drawing.Point(141, 7);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(35, 15);
            this.label12.TabIndex = 32;
            // 
            // label13
            // 
            this.label13.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(182, 8);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(97, 13);
            this.label13.TabIndex = 33;
            this.label13.Text = "Trên 10 lỗi vi phạm";
            // 
            // stackPanel4
            // 
            this.stackPanel4.AutoSize = true;
            this.stackPanel4.Controls.Add(this.label6);
            this.stackPanel4.Controls.Add(this.txtYear);
            this.stackPanel4.Controls.Add(this.label5);
            this.stackPanel4.Controls.Add(this.txtMonth);
            this.stackPanel4.Controls.Add(this.label15);
            this.stackPanel4.Controls.Add(this.txtKeyword_TK);
            this.stackPanel4.Controls.Add(this.btnFind_TK);
            this.stackPanel4.Controls.Add(this.btnExportExcel_TK);
            this.stackPanel4.Dock = System.Windows.Forms.DockStyle.Left;
            this.stackPanel4.Location = new System.Drawing.Point(2, 2);
            this.stackPanel4.Name = "stackPanel4";
            this.stackPanel4.Size = new System.Drawing.Size(0, 29);
            this.stackPanel4.TabIndex = 32;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(3, 6);
            this.label6.Name = "label6";
            this.label6.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label6.Size = new System.Drawing.Size(37, 16);
            this.label6.TabIndex = 163;
            this.label6.Text = "Năm";
            // 
            // txtYear
            // 
            this.txtYear.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtYear.Location = new System.Drawing.Point(46, 3);
            this.txtYear.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.txtYear.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.txtYear.Name = "txtYear";
            this.txtYear.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtYear.Size = new System.Drawing.Size(60, 23);
            this.txtYear.TabIndex = 167;
            this.txtYear.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.txtYear.ValueChanged += new System.EventHandler(this.txtYear_ValueChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(112, 6);
            this.label5.Name = "label5";
            this.label5.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label5.Size = new System.Drawing.Size(47, 16);
            this.label5.TabIndex = 164;
            this.label5.Text = "Tháng";
            // 
            // txtMonth
            // 
            this.txtMonth.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMonth.Location = new System.Drawing.Point(165, 3);
            this.txtMonth.Maximum = new decimal(new int[] {
            12,
            0,
            0,
            0});
            this.txtMonth.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.txtMonth.Name = "txtMonth";
            this.txtMonth.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtMonth.Size = new System.Drawing.Size(38, 23);
            this.txtMonth.TabIndex = 166;
            this.txtMonth.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.txtMonth.ValueChanged += new System.EventHandler(this.txtMonth_ValueChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(209, 6);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(57, 16);
            this.label15.TabIndex = 0;
            this.label15.Text = "Từ khoá";
            // 
            // txtKeyword_TK
            // 
            this.txtKeyword_TK.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtKeyword_TK.Location = new System.Drawing.Point(272, 3);
            this.txtKeyword_TK.Name = "txtKeyword_TK";
            this.txtKeyword_TK.Size = new System.Drawing.Size(222, 22);
            this.txtKeyword_TK.TabIndex = 1;
            this.txtKeyword_TK.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtKeyword_TK_KeyDown);
            // 
            // btnFind_TK
            // 
            this.btnFind_TK.AutoSize = true;
            this.btnFind_TK.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFind_TK.Location = new System.Drawing.Point(500, 1);
            this.btnFind_TK.Name = "btnFind_TK";
            this.btnFind_TK.Size = new System.Drawing.Size(75, 26);
            this.btnFind_TK.TabIndex = 30;
            this.btnFind_TK.Text = "Tìm kiếm";
            this.btnFind_TK.UseVisualStyleBackColor = true;
            this.btnFind_TK.Click += new System.EventHandler(this.btnFind_TK_Click);
            // 
            // btnExportExcel_TK
            // 
            this.btnExportExcel_TK.AutoSize = true;
            this.btnExportExcel_TK.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExportExcel_TK.Location = new System.Drawing.Point(581, 1);
            this.btnExportExcel_TK.Name = "btnExportExcel_TK";
            this.btnExportExcel_TK.Size = new System.Drawing.Size(80, 26);
            this.btnExportExcel_TK.TabIndex = 31;
            this.btnExportExcel_TK.Text = "Xuất Excel";
            this.btnExportExcel_TK.Visible = false;
            this.btnExportExcel_TK.Click += new System.EventHandler(this.btnExportExcel_TK_Click);
            // 
            // ttBieuDo
            // 
            this.ttBieuDo.Controls.Add(this.splitContainerControl3);
            this.ttBieuDo.Name = "ttBieuDo";
            this.ttBieuDo.Size = new System.Drawing.Size(1918, 593);
            this.ttBieuDo.Text = "BIỂU ĐỒ THỐNG KÊ";
            // 
            // splitContainerControl3
            // 
            this.splitContainerControl3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainerControl3.Location = new System.Drawing.Point(0, 0);
            this.splitContainerControl3.Name = "splitContainerControl3";
            // 
            // splitContainerControl3.Panel1
            // 
            this.splitContainerControl3.Panel1.Controls.Add(this.chartKPIErrorInMonth);
            this.splitContainerControl3.Panel1.Controls.Add(this.stackPanel7);
            this.splitContainerControl3.Panel1.Text = "Panel1";
            // 
            // splitContainerControl3.Panel2
            // 
            this.splitContainerControl3.Panel2.Controls.Add(this.grdDataEmployee);
            this.splitContainerControl3.Panel2.Text = "Panel2";
            this.splitContainerControl3.Size = new System.Drawing.Size(1918, 593);
            this.splitContainerControl3.SplitterPosition = 1405;
            this.splitContainerControl3.TabIndex = 1;
            // 
            // chartKPIErrorInMonth
            // 
            xyDiagram1.AxisX.Label.MaxWidth = 250;
            xyDiagram1.AxisX.NumericScaleOptions.AutoGrid = false;
            xyDiagram1.AxisX.VisibleInPanesSerializable = "-1";
            xyDiagram1.AxisY.NumericScaleOptions.AutoGrid = false;
            xyDiagram1.AxisY.VisibleInPanesSerializable = "-1";
            xyDiagram1.Rotated = true;
            this.chartKPIErrorInMonth.Diagram = xyDiagram1;
            this.chartKPIErrorInMonth.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chartKPIErrorInMonth.Legend.Name = "Default Legend";
            this.chartKPIErrorInMonth.Location = new System.Drawing.Point(0, 0);
            this.chartKPIErrorInMonth.Name = "chartKPIErrorInMonth";
            this.chartKPIErrorInMonth.RuntimeHitTesting = true;
            series1.ArgumentDataMember = "Content";
            stackedBarSeriesLabel1.TextPattern = "{V}";
            series1.Label = stackedBarSeriesLabel1;
            series1.LabelsVisibility = DevExpress.Utils.DefaultBoolean.True;
            series1.Name = "Tuần 1";
            series1.Tag = "1";
            series1.ValueDataMembersSerializable = "Week1";
            series1.View = stackedBarSeriesView1;
            series2.ArgumentDataMember = "Content";
            stackedBarSeriesLabel2.TextPattern = "{V}";
            series2.Label = stackedBarSeriesLabel2;
            series2.LabelsVisibility = DevExpress.Utils.DefaultBoolean.True;
            series2.Name = "Tuần 2";
            series2.Tag = "2";
            series2.ValueDataMembersSerializable = "Week2";
            series2.View = stackedBarSeriesView2;
            series3.ArgumentDataMember = "Content";
            stackedBarSeriesLabel3.TextPattern = "{V}";
            series3.Label = stackedBarSeriesLabel3;
            series3.LabelsVisibility = DevExpress.Utils.DefaultBoolean.True;
            series3.Name = "Tuần 3";
            series3.Tag = "3";
            series3.ValueDataMembersSerializable = "Week3";
            series3.View = stackedBarSeriesView3;
            series4.ArgumentDataMember = "Content";
            stackedBarSeriesLabel4.TextPattern = "{V}";
            series4.Label = stackedBarSeriesLabel4;
            series4.LabelsVisibility = DevExpress.Utils.DefaultBoolean.True;
            series4.Name = "Tuần 4";
            series4.Tag = "4";
            series4.ValueDataMembersSerializable = "Week4";
            series4.View = stackedBarSeriesView4;
            series5.ArgumentDataMember = "Content";
            stackedBarSeriesLabel5.TextPattern = "{V}";
            series5.Label = stackedBarSeriesLabel5;
            series5.LabelsVisibility = DevExpress.Utils.DefaultBoolean.True;
            series5.Name = "Tuần 5";
            series5.Tag = "5";
            series5.ValueDataMembersSerializable = "Week5";
            series5.View = stackedBarSeriesView5;
            series6.ArgumentDataMember = "Content";
            stackedBarSeriesLabel6.TextPattern = "{V}";
            series6.Label = stackedBarSeriesLabel6;
            series6.LabelsVisibility = DevExpress.Utils.DefaultBoolean.True;
            series6.Name = "Tuần 6";
            series6.Tag = "6";
            series6.ValueDataMembersSerializable = "Week6";
            series6.View = stackedBarSeriesView6;
            this.chartKPIErrorInMonth.SeriesSerializable = new DevExpress.XtraCharts.Series[] {
        series1,
        series2,
        series3,
        series4,
        series5,
        series6};
            this.chartKPIErrorInMonth.Size = new System.Drawing.Size(1405, 593);
            this.chartKPIErrorInMonth.TabIndex = 3;
            chartTitle1.Font = new System.Drawing.Font("Tahoma", 18F, System.Drawing.FontStyle.Bold);
            chartTitle1.Text = "THỐNG KÊ LỖI VI PHẠM";
            this.chartKPIErrorInMonth.Titles.AddRange(new DevExpress.XtraCharts.ChartTitle[] {
            chartTitle1});
            this.chartKPIErrorInMonth.MouseClick += new System.Windows.Forms.MouseEventHandler(this.chartKPIErrorInMonth_MouseClick);
            // 
            // stackPanel7
            // 
            this.stackPanel7.AutoSize = true;
            this.stackPanel7.Controls.Add(this.label1);
            this.stackPanel7.Controls.Add(this.txtYearChart);
            this.stackPanel7.Controls.Add(this.label3);
            this.stackPanel7.Controls.Add(this.txtMonthChart);
            this.stackPanel7.Controls.Add(this.label4);
            this.stackPanel7.Controls.Add(this.textBox1);
            this.stackPanel7.Controls.Add(this.btnFindChart);
            this.stackPanel7.Controls.Add(this.button2);
            this.stackPanel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.stackPanel7.Location = new System.Drawing.Point(0, 0);
            this.stackPanel7.Name = "stackPanel7";
            this.stackPanel7.Size = new System.Drawing.Size(1405, 0);
            this.stackPanel7.TabIndex = 33;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, -8);
            this.label1.Name = "label1";
            this.label1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label1.Size = new System.Drawing.Size(37, 16);
            this.label1.TabIndex = 163;
            this.label1.Text = "Năm";
            // 
            // txtYearChart
            // 
            this.txtYearChart.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtYearChart.Location = new System.Drawing.Point(46, -11);
            this.txtYearChart.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.txtYearChart.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.txtYearChart.Name = "txtYearChart";
            this.txtYearChart.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtYearChart.Size = new System.Drawing.Size(60, 23);
            this.txtYearChart.TabIndex = 167;
            this.txtYearChart.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(112, -8);
            this.label3.Name = "label3";
            this.label3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label3.Size = new System.Drawing.Size(47, 16);
            this.label3.TabIndex = 164;
            this.label3.Text = "Tháng";
            // 
            // txtMonthChart
            // 
            this.txtMonthChart.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMonthChart.Location = new System.Drawing.Point(165, -11);
            this.txtMonthChart.Maximum = new decimal(new int[] {
            12,
            0,
            0,
            0});
            this.txtMonthChart.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.txtMonthChart.Name = "txtMonthChart";
            this.txtMonthChart.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtMonthChart.Size = new System.Drawing.Size(38, 23);
            this.txtMonthChart.TabIndex = 166;
            this.txtMonthChart.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(209, -8);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 16);
            this.label4.TabIndex = 0;
            this.label4.Text = "Từ khoá";
            this.label4.Visible = false;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(272, -11);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(222, 22);
            this.textBox1.TabIndex = 1;
            this.textBox1.Visible = false;
            // 
            // btnFindChart
            // 
            this.btnFindChart.AutoSize = true;
            this.btnFindChart.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFindChart.Location = new System.Drawing.Point(500, -13);
            this.btnFindChart.Name = "btnFindChart";
            this.btnFindChart.Size = new System.Drawing.Size(75, 26);
            this.btnFindChart.TabIndex = 30;
            this.btnFindChart.Text = "Tìm kiếm";
            this.btnFindChart.UseVisualStyleBackColor = true;
            this.btnFindChart.Click += new System.EventHandler(this.btnFindChart_Click);
            // 
            // button2
            // 
            this.button2.AutoSize = true;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(581, -13);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(80, 26);
            this.button2.TabIndex = 31;
            this.button2.Text = "Xuất Excel";
            this.button2.Visible = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // grdDataEmployee
            // 
            this.grdDataEmployee.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdDataEmployee.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(36, 39, 36, 39);
            this.grdDataEmployee.Location = new System.Drawing.Point(0, 0);
            this.grdDataEmployee.MainView = this.grvDataEmployee;
            this.grdDataEmployee.Margin = new System.Windows.Forms.Padding(36, 39, 36, 39);
            this.grdDataEmployee.Name = "grdDataEmployee";
            this.grdDataEmployee.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemMemoEdit3});
            this.grdDataEmployee.Size = new System.Drawing.Size(503, 593);
            this.grdDataEmployee.TabIndex = 30;
            this.grdDataEmployee.Tag = "";
            this.grdDataEmployee.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.grvDataEmployee});
            // 
            // grvDataEmployee
            // 
            this.grvDataEmployee.Appearance.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.grvDataEmployee.Appearance.HeaderPanel.Options.UseFont = true;
            this.grvDataEmployee.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.grvDataEmployee.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.grvDataEmployee.Appearance.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.grvDataEmployee.Appearance.HeaderPanel.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.grvDataEmployee.Appearance.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.grvDataEmployee.Appearance.Row.Font = new System.Drawing.Font("Tahoma", 9.75F);
            this.grvDataEmployee.Appearance.Row.Options.UseFont = true;
            this.grvDataEmployee.Appearance.Row.Options.UseTextOptions = true;
            this.grvDataEmployee.Appearance.Row.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.grvDataEmployee.Appearance.Row.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.grvDataEmployee.ColumnPanelRowHeight = 50;
            this.grvDataEmployee.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn7,
            this.gridColumn8,
            this.colErrorNumberEmployee,
            this.gridColumn2,
            this.gridColumn9,
            this.gridColumn14});
            this.grvDataEmployee.DetailHeight = 4125;
            this.grvDataEmployee.GridControl = this.grdDataEmployee;
            this.grvDataEmployee.GroupCount = 2;
            this.grvDataEmployee.Name = "grvDataEmployee";
            this.grvDataEmployee.OptionsBehavior.AutoExpandAllGroups = true;
            this.grvDataEmployee.OptionsBehavior.Editable = false;
            this.grvDataEmployee.OptionsSelection.CheckBoxSelectorColumnWidth = 30;
            this.grvDataEmployee.OptionsSelection.MultiSelect = true;
            this.grvDataEmployee.OptionsSelection.ShowCheckBoxSelectorInPrintExport = DevExpress.Utils.DefaultBoolean.False;
            this.grvDataEmployee.OptionsView.RowAutoHeight = true;
            this.grvDataEmployee.OptionsView.ShowAutoFilterRow = true;
            this.grvDataEmployee.OptionsView.ShowFooter = true;
            this.grvDataEmployee.OptionsView.ShowGroupPanel = false;
            this.grvDataEmployee.SortInfo.AddRange(new DevExpress.XtraGrid.Columns.GridColumnSortInfo[] {
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.gridColumn9, DevExpress.Data.ColumnSortOrder.Ascending),
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.gridColumn14, DevExpress.Data.ColumnSortOrder.Ascending)});
            this.grvDataEmployee.Tag = "";
            this.grvDataEmployee.CustomDrawCell += new DevExpress.XtraGrid.Views.Base.RowCellCustomDrawEventHandler(this.grvDataEmployee_CustomDrawCell);
            // 
            // gridColumn7
            // 
            this.gridColumn7.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn7.AppearanceCell.Options.UseFont = true;
            this.gridColumn7.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn7.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridColumn7.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridColumn7.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn7.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.gridColumn7.AppearanceHeader.Options.UseFont = true;
            this.gridColumn7.AppearanceHeader.Options.UseForeColor = true;
            this.gridColumn7.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn7.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn7.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridColumn7.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridColumn7.Caption = "Mã nhân viên";
            this.gridColumn7.ColumnEdit = this.repositoryItemMemoEdit3;
            this.gridColumn7.FieldName = "Code";
            this.gridColumn7.Name = "gridColumn7";
            this.gridColumn7.Visible = true;
            this.gridColumn7.VisibleIndex = 0;
            this.gridColumn7.Width = 103;
            // 
            // repositoryItemMemoEdit3
            // 
            this.repositoryItemMemoEdit3.Name = "repositoryItemMemoEdit3";
            // 
            // gridColumn8
            // 
            this.gridColumn8.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn8.AppearanceCell.Options.UseFont = true;
            this.gridColumn8.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn8.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridColumn8.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridColumn8.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn8.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.gridColumn8.AppearanceHeader.Options.UseFont = true;
            this.gridColumn8.AppearanceHeader.Options.UseForeColor = true;
            this.gridColumn8.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn8.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn8.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridColumn8.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridColumn8.Caption = "Tên nhân viên";
            this.gridColumn8.ColumnEdit = this.repositoryItemMemoEdit3;
            this.gridColumn8.FieldName = "FullName";
            this.gridColumn8.Name = "gridColumn8";
            this.gridColumn8.Visible = true;
            this.gridColumn8.VisibleIndex = 1;
            this.gridColumn8.Width = 148;
            // 
            // colErrorNumberEmployee
            // 
            this.colErrorNumberEmployee.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colErrorNumberEmployee.AppearanceCell.Options.UseFont = true;
            this.colErrorNumberEmployee.AppearanceCell.Options.UseTextOptions = true;
            this.colErrorNumberEmployee.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colErrorNumberEmployee.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colErrorNumberEmployee.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colErrorNumberEmployee.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.colErrorNumberEmployee.AppearanceHeader.Options.UseFont = true;
            this.colErrorNumberEmployee.AppearanceHeader.Options.UseForeColor = true;
            this.colErrorNumberEmployee.AppearanceHeader.Options.UseTextOptions = true;
            this.colErrorNumberEmployee.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colErrorNumberEmployee.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colErrorNumberEmployee.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colErrorNumberEmployee.Caption = "Số lần vi phạm";
            this.colErrorNumberEmployee.ColumnEdit = this.repositoryItemMemoEdit3;
            this.colErrorNumberEmployee.FieldName = "ErrorNumber";
            this.colErrorNumberEmployee.Name = "colErrorNumberEmployee";
            this.colErrorNumberEmployee.Visible = true;
            this.colErrorNumberEmployee.VisibleIndex = 2;
            this.colErrorNumberEmployee.Width = 66;
            // 
            // gridColumn2
            // 
            this.gridColumn2.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn2.AppearanceCell.Options.UseFont = true;
            this.gridColumn2.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn2.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn2.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridColumn2.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridColumn2.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn2.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.gridColumn2.AppearanceHeader.Options.UseFont = true;
            this.gridColumn2.AppearanceHeader.Options.UseForeColor = true;
            this.gridColumn2.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn2.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn2.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridColumn2.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridColumn2.Caption = "Ngày vi phạm";
            this.gridColumn2.ColumnEdit = this.repositoryItemMemoEdit3;
            this.gridColumn2.DisplayFormat.FormatString = "dd";
            this.gridColumn2.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridColumn2.FieldName = "ErrorDate";
            this.gridColumn2.Name = "gridColumn2";
            this.gridColumn2.Visible = true;
            this.gridColumn2.VisibleIndex = 3;
            this.gridColumn2.Width = 99;
            // 
            // gridColumn9
            // 
            this.gridColumn9.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn9.AppearanceCell.Options.UseFont = true;
            this.gridColumn9.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn9.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridColumn9.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridColumn9.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn9.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.gridColumn9.AppearanceHeader.Options.UseFont = true;
            this.gridColumn9.AppearanceHeader.Options.UseForeColor = true;
            this.gridColumn9.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn9.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn9.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridColumn9.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridColumn9.Caption = "Tên lỗi";
            this.gridColumn9.ColumnEdit = this.repositoryItemMemoEdit3;
            this.gridColumn9.FieldName = "ErrorName";
            this.gridColumn9.Name = "gridColumn9";
            this.gridColumn9.Width = 350;
            // 
            // gridColumn14
            // 
            this.gridColumn14.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn14.AppearanceCell.Options.UseFont = true;
            this.gridColumn14.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn14.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridColumn14.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridColumn14.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn14.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.gridColumn14.AppearanceHeader.Options.UseFont = true;
            this.gridColumn14.AppearanceHeader.Options.UseForeColor = true;
            this.gridColumn14.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn14.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn14.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridColumn14.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridColumn14.Caption = "Tuần";
            this.gridColumn14.ColumnEdit = this.repositoryItemMemoEdit3;
            this.gridColumn14.FieldName = "Week";
            this.gridColumn14.Name = "gridColumn14";
            this.gridColumn14.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "Week", "{0:0.##}")});
            this.gridColumn14.Width = 65;
            // 
            // mnuMenu
            // 
            this.mnuMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(234)))), ((int)(((byte)(234)))));
            this.mnuMenu.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mnuMenu.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.mnuMenu.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.mnuMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnExcel});
            this.mnuMenu.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Flow;
            this.mnuMenu.Location = new System.Drawing.Point(2, 2);
            this.mnuMenu.Name = "mnuMenu";
            this.mnuMenu.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.mnuMenu.Size = new System.Drawing.Size(1920, 36);
            this.mnuMenu.TabIndex = 50;
            this.mnuMenu.Text = "toolStrip2";
            // 
            // btnExcel
            // 
            this.btnExcel.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExcel.Image = ((System.Drawing.Image)(resources.GetObject("btnExcel.Image")));
            this.btnExcel.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnExcel.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnExcel.Name = "btnExcel";
            this.btnExcel.Size = new System.Drawing.Size(69, 33);
            this.btnExcel.Tag = "";
            this.btnExcel.Text = "Xuất Excel";
            this.btnExcel.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnExcel.Click += new System.EventHandler(this.btnExcel_Click);
            // 
            // stackPanel2
            // 
            this.stackPanel2.AutoSize = true;
            this.stackPanel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.stackPanel2.Location = new System.Drawing.Point(0, 0);
            this.stackPanel2.Margin = new System.Windows.Forms.Padding(2);
            this.stackPanel2.Name = "stackPanel2";
            this.stackPanel2.Size = new System.Drawing.Size(1924, 0);
            this.stackPanel2.TabIndex = 29;
            // 
            // frmSummaryKPIErrorEmployee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1924, 661);
            this.Controls.Add(this.panelControl1);
            this.Controls.Add(this.stackPanel2);
            this.Name = "frmSummaryKPIErrorEmployee";
            this.Text = "TỔNG HỢP VI PHẠM LỖI";
            this.Load += new System.EventHandler(this.frmSummaryKPIErrorEmployee_Load);
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
            this.panelControl1.ResumeLayout(false);
            this.panelControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl1)).EndInit();
            this.xtraTabControl1.ResumeLayout(false);
            this.ttTongHop.ResumeLayout(false);
            this.ttTongHop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl2.Panel1)).EndInit();
            this.splitContainerControl2.Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl2.Panel2)).EndInit();
            this.splitContainerControl2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl2)).EndInit();
            this.splitContainerControl2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl2)).EndInit();
            this.panelControl2.ResumeLayout(false);
            this.panelControl2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.stackPanel6)).EndInit();
            this.stackPanel6.ResumeLayout(false);
            this.stackPanel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtYearError)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMonthError)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboKPIError.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.searchLookUpEdit1View)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboEmployee.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView8)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.stackPanel5)).EndInit();
            this.stackPanel5.ResumeLayout(false);
            this.stackPanel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1.Panel1)).EndInit();
            this.splitContainerControl1.Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1.Panel2)).EndInit();
            this.splitContainerControl1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1)).EndInit();
            this.splitContainerControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdDataFile)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grvDataFile)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDownloadFile)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stackPanel1)).EndInit();
            this.ttThongKe.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdData_TK)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvData_TK)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl3)).EndInit();
            this.panelControl3.ResumeLayout(false);
            this.panelControl3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.stackPanel3)).EndInit();
            this.stackPanel3.ResumeLayout(false);
            this.stackPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.stackPanel4)).EndInit();
            this.stackPanel4.ResumeLayout(false);
            this.stackPanel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtYear)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMonth)).EndInit();
            this.ttBieuDo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl3.Panel1)).EndInit();
            this.splitContainerControl3.Panel1.ResumeLayout(false);
            this.splitContainerControl3.Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl3.Panel2)).EndInit();
            this.splitContainerControl3.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl3)).EndInit();
            this.splitContainerControl3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(xyDiagram1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(stackedBarSeriesLabel1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(stackedBarSeriesView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(series1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(stackedBarSeriesLabel2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(stackedBarSeriesView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(series2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(stackedBarSeriesLabel3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(stackedBarSeriesView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(series3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(stackedBarSeriesLabel4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(stackedBarSeriesView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(series4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(stackedBarSeriesLabel5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(stackedBarSeriesView5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(series5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(stackedBarSeriesLabel6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(stackedBarSeriesView6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(series6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartKPIErrorInMonth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stackPanel7)).EndInit();
            this.stackPanel7.ResumeLayout(false);
            this.stackPanel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtYearChart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMonthChart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdDataEmployee)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvDataEmployee)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit3)).EndInit();
            this.mnuMenu.ResumeLayout(false);
            this.mnuMenu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.stackPanel2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraEditors.PanelControl panelControl1;
        private DevExpress.XtraTab.XtraTabControl xtraTabControl1;
        private DevExpress.XtraTab.XtraTabPage ttTongHop;
        private DevExpress.XtraTab.XtraTabPage ttThongKe;
        private DevExpress.XtraTab.XtraTabPage ttBieuDo;
        private System.Windows.Forms.NumericUpDown txtYear;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown txtMonth;
        private System.Windows.Forms.Label label5;
        private DevExpress.Utils.Layout.StackPanel stackPanel2;
        private DevExpress.XtraEditors.SplitContainerControl splitContainerControl2;
        private DevExpress.XtraGrid.GridControl grdData;
        private DevExpress.XtraGrid.Views.Grid.GridView grvData;
        private DevExpress.XtraGrid.Columns.GridColumn colID;
        private DevExpress.XtraGrid.Columns.GridColumn colSTT;
        private DevExpress.XtraGrid.Columns.GridColumn colCode;
        private DevExpress.XtraGrid.Columns.GridColumn colTypeName_TH;
        private DevExpress.XtraGrid.Columns.GridColumn colContent;
        private DevExpress.XtraGrid.Columns.GridColumn colEmployeeCode;
        private DevExpress.XtraGrid.Columns.GridColumn colEmployeeName;
        private DevExpress.XtraGrid.Columns.GridColumn colDepartmentName;
        private DevExpress.XtraGrid.Columns.GridColumn colErrorDate;
        private DevExpress.XtraGrid.Columns.GridColumn colErrorNumber;
        private DevExpress.XtraGrid.Columns.GridColumn colMonney;
        private DevExpress.XtraGrid.Columns.GridColumn colNote;
        private DevExpress.XtraGrid.Columns.GridColumn colEmployee;
        private DevExpress.XtraEditors.SplitContainerControl splitContainerControl1;
        private DevExpress.XtraGrid.GridControl grdDataFile;
        private DevExpress.XtraGrid.Views.Grid.GridView grvDataFile;
        private DevExpress.XtraGrid.Columns.GridColumn colFileName;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit repositoryItemMemoEdit6;
        private DevExpress.XtraGrid.Columns.GridColumn colFileID;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit btnDownloadFile;
        private System.Windows.Forms.PictureBox pictureBox;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit repositoryItemMemoEdit1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem btnShowImage;
        private DevExpress.XtraGrid.Columns.GridColumn colCoefficient;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit repositoryItemMemoEdit2;
        private DevExpress.XtraEditors.PanelControl panelControl3;
        private DevExpress.Utils.Layout.StackPanel stackPanel3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private DevExpress.Utils.Layout.StackPanel stackPanel4;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtKeyword_TK;
        private System.Windows.Forms.Button btnFind_TK;
        private DevExpress.XtraGrid.GridControl grdData_TK;
        private DevExpress.XtraGrid.Views.Grid.GridView grvData_TK;
        private DevExpress.XtraGrid.Columns.GridColumn colKPIErrorID;
        private DevExpress.XtraGrid.Columns.GridColumn colKPIErrorCode;
        private DevExpress.XtraGrid.Columns.GridColumn colTypeName_TK;
        private DevExpress.XtraGrid.Columns.GridColumn colKPIErrorContent;
        private DevExpress.XtraGrid.Columns.GridColumn colQuantity;
        private DevExpress.XtraGrid.Columns.GridColumn colUnit;
        private DevExpress.XtraGrid.Columns.GridColumn colKPIErrorMonney;
        private DevExpress.XtraGrid.Columns.GridColumn colErrorNote;
        private DevExpress.XtraGrid.Columns.GridColumn colWeek1;
        private DevExpress.XtraGrid.Columns.GridColumn colWeek2;
        private DevExpress.XtraGrid.Columns.GridColumn colWeek3;
        private DevExpress.XtraGrid.Columns.GridColumn colWeek4;
        private DevExpress.XtraGrid.Columns.GridColumn colWeek5;
        private DevExpress.XtraGrid.Columns.GridColumn colMonth;
        private DevExpress.XtraEditors.SplitContainerControl splitContainerControl3;
        private DevExpress.XtraGrid.GridControl grdDataEmployee;
        private DevExpress.XtraGrid.Views.Grid.GridView grvDataEmployee;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn7;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn8;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn10;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn9;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn14;
        private DevExpress.XtraCharts.ChartControl chartKPIErrorInMonth;
        private DevExpress.XtraGrid.Columns.GridColumn colErrorNumberEmployee;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit repositoryItemMemoEdit3;
        private System.Windows.Forms.Button btnExportExcel_TK;
        private DevExpress.XtraGrid.Columns.GridColumn colErrorDateFile;
        private DevExpress.XtraGrid.Columns.GridColumn colEmployeeFile;
        private DevExpress.XtraGrid.Columns.GridColumn colErrorNameFile;
        private DevExpress.XtraEditors.PanelControl panelControl2;
        private DevExpress.Utils.Layout.StackPanel stackPanel5;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private DevExpress.Utils.Layout.StackPanel stackPanel6;
        private System.Windows.Forms.Label label11;
        private DevExpress.XtraEditors.SearchLookUpEdit cboKPIError;
        private DevExpress.XtraGrid.Views.Grid.GridView searchLookUpEdit1View;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn20;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit repositoryItemMemoEdit4;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn4;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn3;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn6;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn5;
        private System.Windows.Forms.Label label2;
        private DevExpress.XtraEditors.SearchLookUpEdit cboEmployee;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView8;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn23;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn24;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn25;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtKeyword;
        private System.Windows.Forms.Button btnFind;
        private System.Windows.Forms.Button btnExportExcel;
        private DevExpress.Utils.Layout.StackPanel stackPanel1;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit repositoryItemMemoEdit5;
        private DevExpress.XtraGrid.Columns.GridColumn colWeek6;
        private System.Windows.Forms.GroupBox groupBox1;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.Utils.Layout.StackPanel stackPanel7;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown txtYearChart;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown txtMonthChart;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button btnFindChart;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ToolStrip mnuMenu;
        private System.Windows.Forms.ToolStripButton btnExcel;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown txtYearError;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.NumericUpDown txtMonthError;
        private DevExpress.XtraGrid.Columns.GridColumn col;
    }
}