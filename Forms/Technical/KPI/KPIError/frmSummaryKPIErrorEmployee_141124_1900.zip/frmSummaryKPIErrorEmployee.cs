﻿using BMS.Model;
using DevExpress.Utils;
using DevExpress.XtraCharts;
using DevExpress.XtraEditors;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraPrinting;
using DevExpress.XtraPrintingLinks;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BMS
{
    public partial class frmSummaryKPIErrorEmployee : _Forms
    {
        public frmSummaryKPIErrorEmployee()
        {
            InitializeComponent();
        }

        private void frmSummaryKPIErrorEmployee_Load(object sender, EventArgs e)
        {
            txtYear.Value = txtYearChart.Value = txtYearError.Value = DateTime.Now.Year;
            txtMonth.Value = txtMonthChart.Value = txtMonthError.Value = DateTime.Now.Month;

            //LoadData();
        }
        void LoadData()
        {
            //Load tab tổng hợp lỗi của nhân viên
            LoadKPIError();
            LoadEmployee();
            LoadData_TH();
            LoadDataFile();
            //Load tab thống kê lỗi vi phạm
            LoadData_TK();
            //Load tab biểu đồ lỗi vi phạm
            LoadData_BD();
        }
        private void txtYear_ValueChanged(object sender, EventArgs e)
        {
            grdDataEmployee.DataSource = null;
            LoadData();
        }
        private void txtMonth_ValueChanged(object sender, EventArgs e)
        {
            colMonth.Caption = $"Tháng {txtMonth.Value}";
            grdDataEmployee.DataSource = null;
            LoadData();
        }
        private void xtraTabControl1_Click(object sender, EventArgs e)
        {
            LoadData();
        }
        #region TỔNG HỢP LỖI CỦA NHÂN VIÊN
        void LoadKPIError()
        {
            DataTable dt = TextUtils.LoadDataFromSP("spGetKPIError", "A", new string[] { }, new object[] { });
            cboKPIError.Properties.DisplayMember = "Code";
            cboKPIError.Properties.ValueMember = "ID";
            cboKPIError.Properties.DataSource = dt;
        }
        void LoadEmployee()
        {
            //DataTable dt = TextUtils.LoadDataFromSP("spGetEmployeeForKPIError", "A", new string[] { }, new object[] { });
            DataTable dt = TextUtils.LoadDataFromSP("spGetEmployee", "A", new string[] { "@Status" }, new object[] { 0 });
            cboEmployee.Properties.DisplayMember = "FullName";
            cboEmployee.Properties.ValueMember = "ID";
            cboEmployee.Properties.DataSource = dt;
        }
        void LoadData_TH()
        {
            int year = (int)txtYearError.Value;
            int month = (int)txtMonthError.Value;
            int kpiErrorID = TextUtils.ToInt(cboKPIError.EditValue);
            int employeeID = TextUtils.ToInt(cboEmployee.EditValue);
            DataSet ds = TextUtils.LoadDataSetFromSP("spGetSummaryKPIErrorEmployee",
                                        new string[] { "@Month", "@Year", "@KPIErrorID", "@EmployeeID", "@Keyword" },
                                        new object[] { month, year, kpiErrorID, employeeID, txtKeyword.Text.Trim() });
            grdData.DataSource = ds.Tables[0];
        }

        private void cboKPIError_EditValueChanged(object sender, EventArgs e)
        {
            LoadData_TH();
            LoadDataFile();
        }

        private void cboEmployee_EditValueChanged(object sender, EventArgs e)
        {
            LoadData_TH();
            LoadDataFile();
        }

        private void btnFind_Click(object sender, EventArgs e)
        {
            LoadData_TH();
            LoadDataFile();
        }

        void LoadDataFile()
        {
            DataSet ds = TextUtils.LoadDataSetFromSP("spGetSummaryKPIErrorEmployee", 
                new string[] { "@Month", "@Year", "@KPIErrorID", "@EmployeeID", "@Keyword" }, 
                new object[] { txtMonth.Value, txtYear.Value, TextUtils.ToInt(cboKPIError.EditValue), TextUtils.ToInt(cboEmployee.EditValue), txtKeyword.Text.Trim() });
            grdDataFile.DataSource = ds.Tables[1];
            //LoadImage();
        }
        private void btnShowImage_Click(object sender, EventArgs e)
        {
            List<KPIErrorEmployeeFileModel> files = new List<KPIErrorEmployeeFileModel>();
            int[] rowSelecteds = grvDataFile.GetSelectedRows();
            if (rowSelecteds.Length > 0)
            {
                foreach (int rowIndex in rowSelecteds)
                {
                    int fileID = TextUtils.ToInt(grvDataFile.GetRowCellValue(rowIndex, colFileID));
                    if (fileID != 0)
                    {
                        KPIErrorEmployeeFileModel file = SQLHelper<KPIErrorEmployeeFileModel>.FindByID(fileID);
                        files.Add(file);
                    }
                }
            }
            else
            {
                MessageBox.Show("Chọn file ảnh cần xem!", "Thông báo");
                return;
            }

            frmKPIErrorEmployeeDetailImages frm = new frmKPIErrorEmployeeDetailImages();
            frm.files = files;
            frm.Text = $"DANH SÁCH ẢNH CÁC LỖI VI PHẠM KPI - THÁNG {txtMonth.Value} NĂM {txtYear.Value}";
            frm.Show();
            //if (frm.ShowDialog() == DialogResult.OK)
            //{
            //    LoadData_TH();
            //    LoadDataFile();
            //}
        }
        //void LoadImage()
        //{
        //    try
        //    {
        //        int ID = TextUtils.ToInt(grvDataFile.GetFocusedRowCellValue(colFileID));
        //        if (ID == 0)
        //        {
        //            pictureBox.Image = null;
        //            return;
        //        }
        //        KPIErrorEmployeeFileModel model = SQLHelper<KPIErrorEmployeeFileModel>.FindByID(ID);
        //        //string url = $"http://14.232.152.154:8083/api/kpi/{item.ServerPath}/{item.FileName}";
        //        string url = $"{model.OriginPath}\\{model.FileName}";
        //        var request = WebRequest.Create(url);
        //        var response = request.GetResponse();
        //        var stream = response.GetResponseStream();

        //        pictureBox.Image = Image.FromStream(stream);
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show(ex.Message, "Thông báo");
        //    }
        //}

        void LoadImage()
        {
            try
            {
                int ID = TextUtils.ToInt(grvDataFile.GetFocusedRowCellValue(colFileID));
                if (ID == 0)
                {
                    pictureBox.Image = null;
                    return;
                }
                KPIErrorEmployeeFileModel model = SQLHelper<KPIErrorEmployeeFileModel>.FindByID(ID);
                DateTime? errorDate = TextUtils.ToDate4(grvDataFile.GetFocusedRowCellValue(colErrorDate));
                if (!errorDate.HasValue) return;

                string fileName = TextUtils.ToString(grvDataFile.GetFocusedRowCellValue(colFileName));


                //string dateFolder = !errorDate.HasValue ? "" : $"{errorDate:dd.MM.yyyy}";
                //string pathPatern = $@"/AnhViPham/{dateFolder}";
                string pathPattern = $@"{errorDate.Value.Year}\T{errorDate.Value.Month}\N{errorDate.Value.ToString("dd.MM.yyyy")}"; //LinhTN update 04/11/2024
                string url = $"http://14.232.152.154:8083/api/kpi/{pathPattern}/{fileName}";
                //string url = $"{model.OriginPath}\\{model.FileName}";
                var request = WebRequest.Create(url);
                var response = request.GetResponse();
                var stream = response.GetResponseStream();

                pictureBox.Image = Image.FromStream(stream);
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message, "Thông báo");
                pictureBox.Image = null;
            }
        }
        private void grvDataFile_FocusedRowChanged(object sender, DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventArgs e)
        {
            LoadImage();
        }

        private void txtKeyword_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                LoadData_TH();
                LoadDataFile();
            }
        }
        private void btnExportExcel_Click(object sender, EventArgs e)
        {

            //FolderBrowserDialog f = new FolderBrowserDialog();
            SaveFileDialog f = new SaveFileDialog();
            f.Filter = "Excel Files|*.xlsx";
            f.FileName = $"DanhSachTongHopLoiCuaNhanVien_Thang{txtMonth.Value}Nam{txtYear.Value}.xlsx";
            if (f.ShowDialog() == DialogResult.OK)
            {
                //string filepath = Path.Combine(f.SelectedPath, $"DanhSachTongHopLoiCuaNhanVien_Thang{txtMonth.Value}Nam{txtYear.Value}.xlsx");
                string filepath = f.FileName;

                XlsxExportOptionsEx optionsEx = new XlsxExportOptionsEx();
                grvData.OptionsPrint.AutoWidth = false;
                grvData.OptionsPrint.ExpandAllDetails = false;
                grvData.OptionsPrint.PrintDetails = true;
                grvData.OptionsPrint.UsePrintStyles = true;
                optionsEx.ApplyFormattingToEntireColumn = DevExpress.Utils.DefaultBoolean.False;

                PrintingSystem printingSystem = new PrintingSystem();

                PrintableComponentLink printableComponentLink1 = new PrintableComponentLink(printingSystem);
                printableComponentLink1.Component = grdData;

                try
                {
                    CompositeLink compositeLink = new CompositeLink(printingSystem);
                    compositeLink.Links.Add(printableComponentLink1);

                    compositeLink.CreatePageForEachLink();
                    optionsEx.ExportMode = XlsxExportMode.SingleFilePageByPage;

                    compositeLink.PrintingSystem.SaveDocument(filepath);
                    compositeLink.ExportToXlsx(filepath, optionsEx);
                    Process.Start(filepath);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
        private void grvData_CustomDrawCell(object sender, DevExpress.XtraGrid.Views.Base.RowCellCustomDrawEventArgs e)
        {
            if (e.Column == colErrorNumber)
            {
                int errorNumber = TextUtils.ToInt(grvData.GetRowCellValue(e.RowHandle, colErrorNumber));
                if (errorNumber >= 2)
                {
                    e.Appearance.BackColor = Color.FromArgb(255, 255, 74);
                    e.Appearance.ForeColor = Color.Black;
                }
            }
            if (e.Column == colCoefficient)
            {
                int coefficient = TextUtils.ToInt(grvData.GetRowCellValue(e.RowHandle, colCoefficient));
                if (coefficient >= 2)
                {
                    e.Appearance.BackColor = Color.FromArgb(255, 165, 0);
                    e.Appearance.ForeColor = Color.White;
                }
            }
        }
        #endregion
        #region THỐNG KÊ LỖI VI PHẠM
        void LoadData_TK()
        {
            int month = (int)txtMonth.Value;
            int year = (int)txtYear.Value;

            DataTable dt = TextUtils.LoadDataFromSP("spGetSummaryKPIError", "A", new string[] { "@Month", "@Year", "@Keyword" }, new object[] { month, year, txtKeyword_TK.Text.Trim() });
            grdData_TK.DataSource = dt;
            colWeek1.Caption = $"Tuần 1 {dt.Rows[0]["WeekText1"]}";
            colWeek2.Caption = $"Tuần 2 {dt.Rows[0]["WeekText2"]}";
            colWeek3.Caption = $"Tuần 3 {dt.Rows[0]["WeekText3"]}";
            colWeek4.Caption = $"Tuần 4 {dt.Rows[0]["WeekText4"]}";
            colWeek5.Caption = $"Tuần 5 {dt.Rows[0]["WeekText5"]}";
            colWeek6.Caption = $"Tuần 6 {dt.Rows[0]["WeekText6"]}";
        }


        private void btnFind_TK_Click(object sender, EventArgs e)
        {
            LoadData_TK();
        }

        private void txtKeyword_TK_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter) LoadData_TK();
        }
        private void grvData_TK_CustomDrawCell(object sender, DevExpress.XtraGrid.Views.Base.RowCellCustomDrawEventArgs e)
        {
            GridColumn[] weekColumns = { colWeek1, colWeek2, colWeek3, colWeek4, colWeek5, colWeek6, colMonth };

            if (!weekColumns.Contains(e.Column))
            {
                return;
            }
            int cellValue = TextUtils.ToInt(grvData_TK.GetRowCellValue(e.RowHandle, e.Column));

            if (cellValue >= 10)
            {
                e.Appearance.BackColor = Color.FromArgb(239, 31, 62);
                e.Appearance.ForeColor = Color.White;
            }
            else if (cellValue >= 5)
            {
                e.Appearance.BackColor = Color.FromArgb(255, 255, 74);
                e.Appearance.ForeColor = Color.Black;
            }
        }
        #endregion
        #region BIỂU ĐỒ THỐNG KÊ
        void LoadData_BD()
        {
            int month = (int)txtMonthChart.Value;
            int year = (int)txtYearChart.Value;

            DataTable dt = TextUtils.LoadDataFromSP("spGetSummaryKPIError", "A",
                                                    new string[] { "@Month", "@Year", "@Keyword" },
                                                    new object[] { month, year, "" });
            chartKPIErrorInMonth.DataSource = dt;

            chartKPIErrorInMonth.Titles.Clear();
            chartKPIErrorInMonth.Titles.Add(new ChartTitle
            {
                Text = $"THỐNG KÊ LỖI VI PHẠM THÁNG {txtMonth.Value} NĂM {txtYear.Value}",
                Font = new Font("Tahoma", 14, FontStyle.Bold),
                TextColor = Color.Orange
            });
        }
        private void chartKPIErrorInMonth_MouseClick(object sender, MouseEventArgs e)
        {
            int kpiErrorID = 0;
            int weekIndex = 0;
            ChartHitInfo hit = chartKPIErrorInMonth.CalcHitInfo(e.X, e.Y);

            SeriesPoint seriesPoint = hit.SeriesPoint;
            if (seriesPoint != null)
            {

                DataRowView dataRowView = (DataRowView)seriesPoint.Tag;
                DataRow dataRow = dataRowView.Row;
                kpiErrorID = TextUtils.ToInt(dataRow["ID"]);
            }

            Series series = (Series)hit.Series;
            if (series != null)
            {
                weekIndex = TextUtils.ToInt(series.Tag);
            }

            DataTable dt = TextUtils.LoadDataFromSP("spGetSummaryEmployeeKPIError", "A",
                                                new string[] { "@Month", "@Year", "@KPIErrorID", "@WeekIndex" },
                                                new object[] { txtMonthChart.Value, txtYearChart.Value, kpiErrorID, weekIndex });
            grdDataEmployee.DataSource = dt;
        }
        private void grvDataEmployee_CustomDrawCell(object sender, DevExpress.XtraGrid.Views.Base.RowCellCustomDrawEventArgs e)
        {
            if (e.Column != colErrorNumberEmployee) return;
            int errorNumber = TextUtils.ToInt(grvDataEmployee.GetRowCellValue(e.RowHandle, colErrorNumberEmployee));
            if (errorNumber >= 5)
            {
                e.Appearance.BackColor = Color.FromArgb(239, 31, 62);
                e.Appearance.ForeColor = Color.White;
            }
            else if (errorNumber >= 2)
            {
                e.Appearance.BackColor = Color.FromArgb(255, 255, 74);
                e.Appearance.ForeColor = Color.Black;
            }
        }
        private void btnExportExcel_TK_Click(object sender, EventArgs e)
        {
            //FolderBrowserDialog f = new FolderBrowserDialog();
            SaveFileDialog f = new SaveFileDialog();
            f.Filter = "Excel Files|*.xlsx";
            f.FileName = $"DanhSachThongKeLoiViPham_Thang{txtMonth.Value}Nam{txtYear.Value}.xlsx";
            if (f.ShowDialog() == DialogResult.OK)
            {
                //string filepath = Path.Combine(f.SelectedPath, $"DanhSachThongKeLoiViPham_Thang{txtMonth.Value}Nam{txtYear.Value}.xlsx");
                string filepath = f.FileName;

                XlsxExportOptionsEx optionsEx = new XlsxExportOptionsEx();
                grvData_TK.OptionsPrint.AutoWidth = false;
                grvData_TK.OptionsPrint.ExpandAllDetails = false;
                grvData_TK.OptionsPrint.PrintDetails = true;
                grvData_TK.OptionsPrint.UsePrintStyles = true;
                optionsEx.ApplyFormattingToEntireColumn = DevExpress.Utils.DefaultBoolean.False;

                PrintingSystem printingSystem = new PrintingSystem();

                PrintableComponentLink printableComponentLink1 = new PrintableComponentLink(printingSystem);
                printableComponentLink1.Component = grdData_TK;

                try
                {
                    CompositeLink compositeLink = new CompositeLink(printingSystem);
                    compositeLink.Links.Add(printableComponentLink1);

                    compositeLink.CreatePageForEachLink();
                    optionsEx.ExportMode = XlsxExportMode.SingleFilePageByPage;

                    compositeLink.PrintingSystem.SaveDocument(filepath);
                    compositeLink.ExportToXlsx(filepath, optionsEx);
                    Process.Start(filepath);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
        #endregion

        private void btnFindChart_Click(object sender, EventArgs e)
        {
            LoadData_BD();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void btnExcel_Click(object sender, EventArgs e)
        {
            //FolderBrowserDialog f = new FolderBrowserDialog();
            SaveFileDialog f = new SaveFileDialog();
            f.Filter = "Excel Files|*.xlsx";
            f.FileName = $"TongHopViPhamLoi_{DateTime.Now.ToString("ddMMyyyy")}.xlsx";
            if (f.ShowDialog() == DialogResult.OK)
            {
                //string filepath = Path.Combine(f.SelectedPath, $"TongHopViPhamLoi_{DateTime.Now.ToString("ddMMyyyy")}.xlsx");
                string filepath = f.FileName;
                //string filepath = @"C:\Users\Admin\Desktop\Bảng công Công ty RTC - APR - MVI - YONKO FINAL Tháng 8.2023 FINAL.xlsx";

                XlsxExportOptionsEx optionsEx = new XlsxExportOptionsEx();
                PrintingSystem printingSystem = new PrintingSystem();

                PrintableComponentLink printableComponentLink1 = new PrintableComponentLink(printingSystem);
                printableComponentLink1.Component = grdData;

                PrintableComponentLink printableComponentLink2 = new PrintableComponentLink(printingSystem);
                printableComponentLink2.Component = grdData_TK;

                //PrintableComponentLink printableComponentLink3 = new PrintableComponentLink(printingSystem);
                //printableComponentLink3.Component = grdData_TK;

                try
                {
                    using (WaitDialogForm fWait = new WaitDialogForm("Vui lòng chờ trong giây lát...", "Đang tạo phiếu..."))
                    {
                        CompositeLink compositeLink = new CompositeLink(printingSystem);
                        compositeLink.Links.Add(printableComponentLink1);
                        compositeLink.Links.Add(printableComponentLink2);
                        //compositeLink.Links.Add(printableComponentLink3);

                        compositeLink.PrintingSystem.XlSheetCreated += PrintingSystem_XlSheetCreated;

                        compositeLink.CreatePageForEachLink();
                        optionsEx.ExportMode = XlsxExportMode.SingleFilePageByPage;

                        compositeLink.PrintingSystem.SaveDocument(filepath);
                        compositeLink.ExportToXlsx(filepath, optionsEx);
                        Process.Start(filepath);
                    }


                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void PrintingSystem_XlSheetCreated(object sender, XlSheetCreatedEventArgs e)
        {
            e.SheetName = e.Index == 0 ? $"Công tác" : (e.Index == 1 ? $"Đi làm sớm" : $"");

            if (e.Index == 0)
            {
                e.SheetName = $"TỔNG HỢP LỖI CỦA NHÂN VIÊN_{txtMonthError.Value}_{txtYearError.Value}";
            }
            else if (e.Index == 1)
            {
                e.SheetName = $"THỐNG KÊ LỖI VI PHẠM_T{txtMonth.Value}_{txtYear.Value}";
            }
        }

        private void txtMonthError_ValueChanged(object sender, EventArgs e)
        {
            LoadData_TH();
        }

        private void grvData_FocusedRowChanged(object sender, DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventArgs e)
        {
            //LoadDataFile();
        }
    }
}