﻿
namespace BMS
{
    partial class frmPaymentOrder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summaryrepositoryItemMemoEdit5
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPaymentOrder));
            DevExpress.XtraEditors.Controls.EditorButtonImageOptions editorButtonImageOptions1 = new DevExpress.XtraEditors.Controls.EditorButtonImageOptions();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject1 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject2 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject3 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject4 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.XtraEditors.Controls.EditorButtonImageOptions editorButtonImageOptions2 = new DevExpress.XtraEditors.Controls.EditorButtonImageOptions();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject5 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject6 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject7 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject8 = new DevExpress.Utils.SerializableAppearanceObject();
            this.repositoryItemMemoEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit();
            this.mnuMenu = new System.Windows.Forms.ToolStrip();
            this.btnAdd = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator12 = new System.Windows.Forms.ToolStripSeparator();
            this.btnEdit = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator11 = new System.Windows.Forms.ToolStripSeparator();
            this.btnDelete = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator10 = new System.Windows.Forms.ToolStripSeparator();
            this.btnCopy = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator13 = new System.Windows.Forms.ToolStripSeparator();
            this.btnTBP = new System.Windows.Forms.ToolStripDropDownButton();
            this.btnApproveTBP = new System.Windows.Forms.ToolStripMenuItem();
            this.btnUnApproveTBP = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.btnHR = new System.Windows.Forms.ToolStripDropDownButton();
            this.btnApproveDocumentHR = new System.Windows.Forms.ToolStripMenuItem();
            this.btnUnApproveDocumentHR = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator16 = new System.Windows.Forms.ToolStripSeparator();
            this.btnHRUpdateDocument = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            this.btnApproveHR = new System.Windows.Forms.ToolStripMenuItem();
            this.btnUnApproveHR = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.btnKTTT = new System.Windows.Forms.ToolStripDropDownButton();
            this.btnApproveDocument = new System.Windows.Forms.ToolStripMenuItem();
            this.btnUpdateDocument = new System.Windows.Forms.ToolStripMenuItem();
            this.btnUnApproveDocument = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.btnReceiveDocument = new System.Windows.Forms.ToolStripMenuItem();
            this.btnUnReceiveDocument = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.btnIsPayment = new System.Windows.Forms.ToolStripMenuItem();
            this.btnUnPayment = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.btnKTT = new System.Windows.Forms.ToolStripDropDownButton();
            this.btnApproveKT = new System.Windows.Forms.ToolStripMenuItem();
            this.btnUnApproveKT = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.btnBGĐ = new System.Windows.Forms.ToolStripDropDownButton();
            this.btnApproveBGĐ = new System.Windows.Forms.ToolStripMenuItem();
            this.btnUnApproveBGĐ = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.btnTreeFolder = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.btnExcel = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator15 = new System.Windows.Forms.ToolStripSeparator();
            this.btnApproveTBP_New = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator14 = new System.Windows.Forms.ToolStripSeparator();
            this.btnUnApproveTBP_New = new System.Windows.Forms.ToolStripButton();
            this.grdData = new DevExpress.XtraGrid.GridControl();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.btnTreeFolderContext = new System.Windows.Forms.ToolStripMenuItem();
            this.btnLogPaymentOrder = new System.Windows.Forms.ToolStripMenuItem();
            this.btnCopyPaymentOrder = new System.Windows.Forms.ToolStripMenuItem();
            this.btnExportExcels = new System.Windows.Forms.ToolStripMenuItem();
            this.grvData = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.ReasonOrder = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colRowNum = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colDateOrder = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colCode = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colFullName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colDepartmentName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colTypeOrderText = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colTypeName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colStepName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colContentLog = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colReasonCancel = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colNote = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colID = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colPaymentOrderTypeID = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colStep = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colIsApproved = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colTotalMoneyPayment = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colTypeBankTransferText = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colContentBankTransfer = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colUnitPayment = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colAccountingNote = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colIsUrgent = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colDeadlinePayment = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemMemoEdit7 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit();
            this.colSuplierName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colPOCode = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colTotalPayment = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colIsIgnoreHR = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemCheckEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.colProjectFullName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colStepNew = new DevExpress.XtraGrid.Columns.GridColumn();
            this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
            this.label12 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.cboEmployee = new DevExpress.XtraEditors.SearchLookUpEdit();
            this.gridView3 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn7 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn8 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn9 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemMemoEdit4 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit();
            this.stackPanel1 = new DevExpress.Utils.Layout.StackPanel();
            this.btnFirst = new DevExpress.XtraEditors.SimpleButton();
            this.btnPrev = new DevExpress.XtraEditors.SimpleButton();
            this.txtPageNumber = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtTotalPage = new System.Windows.Forms.TextBox();
            this.btnNext = new DevExpress.XtraEditors.SimpleButton();
            this.btnLast = new DevExpress.XtraEditors.SimpleButton();
            this.txtPageSize = new System.Windows.Forms.NumericUpDown();
            this.btnFind = new System.Windows.Forms.Button();
            this.txtKeyword = new System.Windows.Forms.TextBox();
            this.cboPaymentOrderType = new DevExpress.XtraEditors.SearchLookUpEdit();
            this.gridView2 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn4 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemMemoEdit3 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit();
            this.cboDepartment = new DevExpress.XtraEditors.SearchLookUpEdit();
            this.searchLookUpEdit1View = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemMemoEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit();
            this.cboIsApproved = new System.Windows.Forms.ComboBox();
            this.cboTypeOrder = new System.Windows.Forms.ComboBox();
            this.dtpDateEnd = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dtpDateStart = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.xtraTabControl1 = new DevExpress.XtraTab.XtraTabControl();
            this.xtraTabPage1 = new DevExpress.XtraTab.XtraTabPage();
            this.splitContainerControl1 = new DevExpress.XtraEditors.SplitContainerControl();
            this.splitContainerControl2 = new DevExpress.XtraEditors.SplitContainerControl();
            this.tlDetail = new DevExpress.XtraTreeList.TreeList();
            this.treeListColumn1 = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.colContentPayment = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.repositoryItemMemoEdit5 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit();
            this.colUnit = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.colQuantity = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.colUnitPrice = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.colTotalMoney = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.treeListColumn7 = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.colPaymentPercentage = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.colTotalPaymentAmount = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.grdDataFile = new DevExpress.XtraGrid.GridControl();
            this.grvDataFile = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colFileName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemMemoEdit6 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit();
            this.colServerPath = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn5 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.btnDownloadFile = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.xtraTabPage2 = new DevExpress.XtraTab.XtraTabPage();
            this.splitContainerControl3 = new DevExpress.XtraEditors.SplitContainerControl();
            this.grdPaymentSpe = new DevExpress.XtraGrid.GridControl();
            this.grvPaymentSpe = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colPaymentSpeStt = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colSpeIsUrgent = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colPaymentSpeDateOrder = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colPaymentSpeCode = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colSpeFullName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colSpeDeadlinePayment = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colPaymentSpeDepartmentName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colPaymentSpeTypeOrderText = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colPaymentOrderTypeName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colSpeTotalMoney = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colSpeUnit = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colSpeStepName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colSpeContentLog = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colSpeCustomerName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colSpeReasonCancel = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colSpeNote = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colPaymentSpeId = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colSpePaymentOrderTypeID = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colSpeStep = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colSpeIsApproved = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colTypeDocumentText = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colSpeNumberDocument = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemCheckEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.repositoryItemMemoEdit8 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit();
            this.splitContainerControl4 = new DevExpress.XtraEditors.SplitContainerControl();
            this.grdSpeDetails = new DevExpress.XtraGrid.GridControl();
            this.grvSpeDetails = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colSpeDetailsSTT = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colSpeDetailsContentPayment = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemMemoEdit10 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit();
            this.colSpeDetailsTotalMoney = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colSpeDetailsPaymentMethods = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colSpeDetailsPaymentInfor = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colSpeDetailsEmployeeName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colSpeDetailsNote = new DevExpress.XtraGrid.Columns.GridColumn();
            this.grdSpeFile = new DevExpress.XtraGrid.GridControl();
            this.grvSpeFile = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn6 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemMemoEdit9 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit();
            this.gridColumn13 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn24 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemButtonEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.gridView7 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.btnViewAttachFile = new System.Windows.Forms.ToolStripMenuItem();
            this.btnDownloadAttachFile = new System.Windows.Forms.ToolStripMenuItem();
            this.colTotalPaymentActual = new DevExpress.XtraGrid.Columns.GridColumn();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit1)).BeginInit();
            this.mnuMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdData)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grvData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
            this.panelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cboEmployee.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stackPanel1)).BeginInit();
            this.stackPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtPageSize)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboPaymentOrderType.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboDepartment.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.searchLookUpEdit1View)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl1)).BeginInit();
            this.xtraTabControl1.SuspendLayout();
            this.xtraTabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1.Panel1)).BeginInit();
            this.splitContainerControl1.Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1.Panel2)).BeginInit();
            this.splitContainerControl1.Panel2.SuspendLayout();
            this.splitContainerControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl2.Panel1)).BeginInit();
            this.splitContainerControl2.Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl2.Panel2)).BeginInit();
            this.splitContainerControl2.Panel2.SuspendLayout();
            this.splitContainerControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tlDetail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdDataFile)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvDataFile)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDownloadFile)).BeginInit();
            this.xtraTabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl3.Panel1)).BeginInit();
            this.splitContainerControl3.Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl3.Panel2)).BeginInit();
            this.splitContainerControl3.Panel2.SuspendLayout();
            this.splitContainerControl3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdPaymentSpe)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvPaymentSpe)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl4.Panel1)).BeginInit();
            this.splitContainerControl4.Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl4.Panel2)).BeginInit();
            this.splitContainerControl4.Panel2.SuspendLayout();
            this.splitContainerControl4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdSpeDetails)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvSpeDetails)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdSpeFile)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvSpeFile)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView7)).BeginInit();
            this.contextMenuStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // repositoryItemMemoEdit1
            // 
            this.repositoryItemMemoEdit1.Name = "repositoryItemMemoEdit1";
            // 
            // mnuMenu
            // 
            this.mnuMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(234)))), ((int)(((byte)(234)))));
            this.mnuMenu.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mnuMenu.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.mnuMenu.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.mnuMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnAdd,
            this.toolStripSeparator12,
            this.btnEdit,
            this.toolStripSeparator11,
            this.btnDelete,
            this.toolStripSeparator10,
            this.btnCopy,
            this.toolStripSeparator13,
            this.btnTBP,
            this.toolStripSeparator3,
            this.btnHR,
            this.toolStripSeparator8,
            this.btnKTTT,
            this.toolStripSeparator7,
            this.btnKTT,
            this.toolStripSeparator6,
            this.btnBGĐ,
            this.toolStripSeparator4,
            this.btnTreeFolder,
            this.toolStripSeparator5,
            this.btnExcel,
            this.toolStripSeparator15,
            this.btnApproveTBP_New,
            this.toolStripSeparator14,
            this.btnUnApproveTBP_New});
            this.mnuMenu.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Flow;
            this.mnuMenu.Location = new System.Drawing.Point(0, 0);
            this.mnuMenu.Name = "mnuMenu";
            this.mnuMenu.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.mnuMenu.Size = new System.Drawing.Size(1393, 55);
            this.mnuMenu.TabIndex = 51;
            this.mnuMenu.Text = "toolStrip2";
            // 
            // btnAdd
            // 
            this.btnAdd.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.Image = global::Forms.Properties.Resources.AddFile_32x32;
            this.btnAdd.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnAdd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(46, 52);
            this.btnAdd.Tag = "frmPaymentOrder_Add";
            this.btnAdd.Text = "Thêm";
            this.btnAdd.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // toolStripSeparator12
            // 
            this.toolStripSeparator12.AutoSize = false;
            this.toolStripSeparator12.Name = "toolStripSeparator12";
            this.toolStripSeparator12.Size = new System.Drawing.Size(6, 50);
            // 
            // btnEdit
            // 
            this.btnEdit.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEdit.Image = global::Forms.Properties.Resources.Edit_32x321;
            this.btnEdit.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnEdit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(37, 52);
            this.btnEdit.Tag = "frmPaymentOrder_Edit";
            this.btnEdit.Text = "Sửa";
            this.btnEdit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // toolStripSeparator11
            // 
            this.toolStripSeparator11.AutoSize = false;
            this.toolStripSeparator11.Name = "toolStripSeparator11";
            this.toolStripSeparator11.Size = new System.Drawing.Size(6, 50);
            // 
            // btnDelete
            // 
            this.btnDelete.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.Image = global::Forms.Properties.Resources.DeleteList2_32x32;
            this.btnDelete.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnDelete.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(37, 52);
            this.btnDelete.Tag = "frmPaymentOrder_Delete";
            this.btnDelete.Text = "Xóa";
            this.btnDelete.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // toolStripSeparator10
            // 
            this.toolStripSeparator10.AutoSize = false;
            this.toolStripSeparator10.Name = "toolStripSeparator10";
            this.toolStripSeparator10.Size = new System.Drawing.Size(6, 50);
            // 
            // btnCopy
            // 
            this.btnCopy.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCopy.Image = global::Forms.PrintRibbonControllerResources.RibbonPrintPreview_PageOrientationLarge;
            this.btnCopy.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnCopy.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnCopy.Name = "btnCopy";
            this.btnCopy.Size = new System.Drawing.Size(44, 52);
            this.btnCopy.Text = "Copy";
            this.btnCopy.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnCopy.Click += new System.EventHandler(this.btnCopy_Click);
            // 
            // toolStripSeparator13
            // 
            this.toolStripSeparator13.AutoSize = false;
            this.toolStripSeparator13.Name = "toolStripSeparator13";
            this.toolStripSeparator13.Size = new System.Drawing.Size(6, 50);
            // 
            // btnTBP
            // 
            this.btnTBP.AutoSize = false;
            this.btnTBP.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.btnTBP.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnApproveTBP,
            this.btnUnApproveTBP});
            this.btnTBP.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTBP.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnTBP.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnTBP.Name = "btnTBP";
            this.btnTBP.Size = new System.Drawing.Size(132, 52);
            this.btnTBP.Text = "TRƯỞNG BỘ PHẬN";
            this.btnTBP.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnTBP.Click += new System.EventHandler(this.btnTBP_Click);
            // 
            // btnApproveTBP
            // 
            this.btnApproveTBP.Image = global::Forms.Properties.Resources.Apply_16x16;
            this.btnApproveTBP.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnApproveTBP.Name = "btnApproveTBP";
            this.btnApproveTBP.Size = new System.Drawing.Size(143, 22);
            this.btnApproveTBP.Tag = "frmPaymentOrder_ApproveTBP";
            this.btnApproveTBP.Text = "Duyệt";
            this.btnApproveTBP.Click += new System.EventHandler(this.btnApproveTBP_Click);
            // 
            // btnUnApproveTBP
            // 
            this.btnUnApproveTBP.Image = global::Forms.Properties.Resources.icons8_close_16;
            this.btnUnApproveTBP.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnUnApproveTBP.Name = "btnUnApproveTBP";
            this.btnUnApproveTBP.Size = new System.Drawing.Size(143, 22);
            this.btnUnApproveTBP.Tag = "frmPaymentOrder_UnApproveTBP";
            this.btnUnApproveTBP.Text = "Huỷ duyệt";
            this.btnUnApproveTBP.Click += new System.EventHandler(this.btnUnApproveTBP_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.AutoSize = false;
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 50);
            // 
            // btnHR
            // 
            this.btnHR.AutoSize = false;
            this.btnHR.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.btnHR.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnApproveDocumentHR,
            this.btnUnApproveDocumentHR,
            this.toolStripSeparator16,
            this.btnHRUpdateDocument,
            this.toolStripSeparator9,
            this.btnApproveHR,
            this.btnUnApproveHR});
            this.btnHR.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHR.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnHR.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnHR.Name = "btnHR";
            this.btnHR.Size = new System.Drawing.Size(77, 52);
            this.btnHR.Text = "NHÂN SỰ";
            this.btnHR.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnHR.Click += new System.EventHandler(this.btnHR_Click);
            // 
            // btnApproveDocumentHR
            // 
            this.btnApproveDocumentHR.Image = global::Forms.Properties.Resources.InsertTableOfCaptions_16x16;
            this.btnApproveDocumentHR.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnApproveDocumentHR.Name = "btnApproveDocumentHR";
            this.btnApproveDocumentHR.Size = new System.Drawing.Size(218, 22);
            this.btnApproveDocumentHR.Tag = "frmPaymentOrder_ApproveDocumentHR";
            this.btnApproveDocumentHR.Text = "Duyệt hồ sơ";
            this.btnApproveDocumentHR.Click += new System.EventHandler(this.btnApproveDocumentHR_Click);
            // 
            // btnUnApproveDocumentHR
            // 
            this.btnUnApproveDocumentHR.Image = global::Forms.Properties.Resources.RemoveFooter_16x16;
            this.btnUnApproveDocumentHR.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnUnApproveDocumentHR.Name = "btnUnApproveDocumentHR";
            this.btnUnApproveDocumentHR.Size = new System.Drawing.Size(218, 22);
            this.btnUnApproveDocumentHR.Tag = "frmPaymentOrder_UnApproveDocumentHR";
            this.btnUnApproveDocumentHR.Text = "Huỷ duyệt hồ sơ";
            this.btnUnApproveDocumentHR.Click += new System.EventHandler(this.btnUnApproveDocumentHR_Click);
            // 
            // toolStripSeparator16
            // 
            this.toolStripSeparator16.Name = "toolStripSeparator16";
            this.toolStripSeparator16.Size = new System.Drawing.Size(215, 6);
            // 
            // btnHRUpdateDocument
            // 
            this.btnHRUpdateDocument.Image = global::Forms.Properties.Resources.Insert_16x16;
            this.btnHRUpdateDocument.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnHRUpdateDocument.Name = "btnHRUpdateDocument";
            this.btnHRUpdateDocument.Size = new System.Drawing.Size(218, 22);
            this.btnHRUpdateDocument.Tag = "frmPaymentOrder_btnHRUpdateDocument";
            this.btnHRUpdateDocument.Text = "Y/c bổ sung chứng từ";
            this.btnHRUpdateDocument.Click += new System.EventHandler(this.btnHRUpdateDocument_Click);
            // 
            // toolStripSeparator9
            // 
            this.toolStripSeparator9.Name = "toolStripSeparator9";
            this.toolStripSeparator9.Size = new System.Drawing.Size(215, 6);
            // 
            // btnApproveHR
            // 
            this.btnApproveHR.Image = global::Forms.Properties.Resources.Apply_16x16;
            this.btnApproveHR.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnApproveHR.Name = "btnApproveHR";
            this.btnApproveHR.Size = new System.Drawing.Size(218, 22);
            this.btnApproveHR.Tag = "frmPaymentOrder_ApproveHR";
            this.btnApproveHR.Text = "TBP duyệt";
            this.btnApproveHR.Click += new System.EventHandler(this.btnApproveHR_Click);
            // 
            // btnUnApproveHR
            // 
            this.btnUnApproveHR.Image = global::Forms.Properties.Resources.icons8_close_16;
            this.btnUnApproveHR.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnUnApproveHR.Name = "btnUnApproveHR";
            this.btnUnApproveHR.Size = new System.Drawing.Size(218, 22);
            this.btnUnApproveHR.Tag = "frmPaymentOrder_UnApproveHR";
            this.btnUnApproveHR.Text = "TBP huỷ duyệt";
            this.btnUnApproveHR.Click += new System.EventHandler(this.btnUnApproveHR_Click);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.AutoSize = false;
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(6, 50);
            // 
            // btnKTTT
            // 
            this.btnKTTT.AutoSize = false;
            this.btnKTTT.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.btnKTTT.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnApproveDocument,
            this.btnUpdateDocument,
            this.btnUnApproveDocument,
            this.toolStripSeparator1,
            this.btnReceiveDocument,
            this.btnUnReceiveDocument,
            this.toolStripSeparator2,
            this.btnIsPayment,
            this.btnUnPayment});
            this.btnKTTT.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKTTT.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnKTTT.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnKTTT.Name = "btnKTTT";
            this.btnKTTT.Size = new System.Drawing.Size(159, 52);
            this.btnKTTT.Text = "KẾ TOÁN THANH TOÁN";
            this.btnKTTT.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // btnApproveDocument
            // 
            this.btnApproveDocument.Image = global::Forms.Properties.Resources.Apply_16x16;
            this.btnApproveDocument.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnApproveDocument.Name = "btnApproveDocument";
            this.btnApproveDocument.Size = new System.Drawing.Size(200, 22);
            this.btnApproveDocument.Tag = "frmPaymentOrder_ApproveDocument";
            this.btnApproveDocument.Text = "Duyệt hồ sơ";
            this.btnApproveDocument.Click += new System.EventHandler(this.btnApproveDocument_Click);
            // 
            // btnUpdateDocument
            // 
            this.btnUpdateDocument.Image = global::Forms.Properties.Resources.Insert_16x16;
            this.btnUpdateDocument.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnUpdateDocument.Name = "btnUpdateDocument";
            this.btnUpdateDocument.Size = new System.Drawing.Size(200, 22);
            this.btnUpdateDocument.Text = "Bổ sung chứng từ";
            this.btnUpdateDocument.Click += new System.EventHandler(this.btnUpdateDocument_Click);
            // 
            // btnUnApproveDocument
            // 
            this.btnUnApproveDocument.Image = global::Forms.Properties.Resources.icons8_close_16;
            this.btnUnApproveDocument.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnUnApproveDocument.Name = "btnUnApproveDocument";
            this.btnUnApproveDocument.Size = new System.Drawing.Size(200, 22);
            this.btnUnApproveDocument.Tag = "frmPaymentOrder_UnApproveDocument";
            this.btnUnApproveDocument.Text = "Huỷ duyệt hồ sơ";
            this.btnUnApproveDocument.Click += new System.EventHandler(this.btnUnApproveDocument_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(197, 6);
            // 
            // btnReceiveDocument
            // 
            this.btnReceiveDocument.Image = global::Forms.Properties.Resources.InsertTableOfCaptions_16x16;
            this.btnReceiveDocument.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnReceiveDocument.Name = "btnReceiveDocument";
            this.btnReceiveDocument.Size = new System.Drawing.Size(200, 22);
            this.btnReceiveDocument.Tag = "frmPaymentOrder_ReceiveDocument";
            this.btnReceiveDocument.Text = "Nhận chứng từ";
            this.btnReceiveDocument.Click += new System.EventHandler(this.btnReceiveDocument_Click);
            // 
            // btnUnReceiveDocument
            // 
            this.btnUnReceiveDocument.Image = global::Forms.Properties.Resources.RemoveFooter_16x16;
            this.btnUnReceiveDocument.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnUnReceiveDocument.Name = "btnUnReceiveDocument";
            this.btnUnReceiveDocument.Size = new System.Drawing.Size(200, 22);
            this.btnUnReceiveDocument.Tag = "frmPaymentOrder_UnReceiveDocument";
            this.btnUnReceiveDocument.Text = "Huỷ nhận chứng từ";
            this.btnUnReceiveDocument.Click += new System.EventHandler(this.btnUnReceiveDocument_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(197, 6);
            // 
            // btnIsPayment
            // 
            this.btnIsPayment.Image = global::Forms.Properties.Resources.BO_Sale;
            this.btnIsPayment.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnIsPayment.Name = "btnIsPayment";
            this.btnIsPayment.Size = new System.Drawing.Size(200, 22);
            this.btnIsPayment.Tag = "frmPaymentOrder_IsPayment";
            this.btnIsPayment.Text = "Đã thanh toán";
            this.btnIsPayment.Click += new System.EventHandler(this.btnIsPayment_Click);
            // 
            // btnUnPayment
            // 
            this.btnUnPayment.Image = global::Forms.Properties.Resources.BO_Rules;
            this.btnUnPayment.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnUnPayment.Name = "btnUnPayment";
            this.btnUnPayment.Size = new System.Drawing.Size(200, 22);
            this.btnUnPayment.Tag = "frmPaymentOrder_UnPayment";
            this.btnUnPayment.Text = "Huỷ thanh toán";
            this.btnUnPayment.Click += new System.EventHandler(this.btnUnPayment_Click);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.AutoSize = false;
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(6, 50);
            // 
            // btnKTT
            // 
            this.btnKTT.AutoSize = false;
            this.btnKTT.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.btnKTT.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnApproveKT,
            this.btnUnApproveKT});
            this.btnKTT.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKTT.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnKTT.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnKTT.Name = "btnKTT";
            this.btnKTT.Size = new System.Drawing.Size(129, 52);
            this.btnKTT.Text = "KẾ TOÁN TRƯỞNG";
            this.btnKTT.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // btnApproveKT
            // 
            this.btnApproveKT.Image = global::Forms.Properties.Resources.Apply_16x16;
            this.btnApproveKT.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnApproveKT.Name = "btnApproveKT";
            this.btnApproveKT.Size = new System.Drawing.Size(143, 22);
            this.btnApproveKT.Tag = "frmPaymentOrder_ApproveKTT";
            this.btnApproveKT.Text = "Duyệt";
            this.btnApproveKT.Click += new System.EventHandler(this.toolStripMenuItem5_Click);
            // 
            // btnUnApproveKT
            // 
            this.btnUnApproveKT.Image = global::Forms.Properties.Resources.icons8_close_16;
            this.btnUnApproveKT.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnUnApproveKT.Name = "btnUnApproveKT";
            this.btnUnApproveKT.Size = new System.Drawing.Size(143, 22);
            this.btnUnApproveKT.Tag = "frmPaymentOrder_UnApproveKT";
            this.btnUnApproveKT.Text = "Huỷ duyệt";
            this.btnUnApproveKT.Click += new System.EventHandler(this.btnUnApproveKT_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.AutoSize = false;
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(6, 50);
            // 
            // btnBGĐ
            // 
            this.btnBGĐ.AutoSize = false;
            this.btnBGĐ.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.btnBGĐ.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnApproveBGĐ,
            this.btnUnApproveBGĐ});
            this.btnBGĐ.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBGĐ.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnBGĐ.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnBGĐ.Name = "btnBGĐ";
            this.btnBGĐ.Size = new System.Drawing.Size(116, 52);
            this.btnBGĐ.Text = "BAN GIÁM ĐỐC";
            this.btnBGĐ.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // btnApproveBGĐ
            // 
            this.btnApproveBGĐ.Image = global::Forms.Properties.Resources.Apply_16x16;
            this.btnApproveBGĐ.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnApproveBGĐ.Name = "btnApproveBGĐ";
            this.btnApproveBGĐ.Size = new System.Drawing.Size(143, 22);
            this.btnApproveBGĐ.Tag = "frmPaymentOrder_ApproveBGĐ";
            this.btnApproveBGĐ.Text = "Duyệt";
            this.btnApproveBGĐ.Click += new System.EventHandler(this.btnApproveBGĐ_Click);
            // 
            // btnUnApproveBGĐ
            // 
            this.btnUnApproveBGĐ.Image = global::Forms.Properties.Resources.icons8_close_16;
            this.btnUnApproveBGĐ.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnUnApproveBGĐ.Name = "btnUnApproveBGĐ";
            this.btnUnApproveBGĐ.Size = new System.Drawing.Size(143, 22);
            this.btnUnApproveBGĐ.Tag = "frmPaymentOrder_UnApproveBGĐ";
            this.btnUnApproveBGĐ.Text = "Huỷ duyệt";
            this.btnUnApproveBGĐ.Click += new System.EventHandler(this.btnUnApproveBGĐ_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.AutoSize = false;
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 50);
            // 
            // btnTreeFolder
            // 
            this.btnTreeFolder.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTreeFolder.Image = global::Forms.PrintRibbonControllerResources.RibbonPrintPreview_OpenLarge;
            this.btnTreeFolder.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnTreeFolder.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnTreeFolder.Name = "btnTreeFolder";
            this.btnTreeFolder.Size = new System.Drawing.Size(93, 52);
            this.btnTreeFolder.Tag = "frmPaymentOrder_TreeFolder";
            this.btnTreeFolder.Text = "Cây thư mục";
            this.btnTreeFolder.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnTreeFolder.Click += new System.EventHandler(this.btnTreeFolder_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.AutoSize = false;
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 50);
            // 
            // btnExcel
            // 
            this.btnExcel.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExcel.Image = global::Forms.Properties.Resources.ExportToXLS_32x32;
            this.btnExcel.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnExcel.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnExcel.Name = "btnExcel";
            this.btnExcel.Size = new System.Drawing.Size(79, 52);
            this.btnExcel.Tag = "";
            this.btnExcel.Text = "Xuất Excel";
            this.btnExcel.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnExcel.Click += new System.EventHandler(this.btnExcel_Click);
            // 
            // toolStripSeparator15
            // 
            this.toolStripSeparator15.AutoSize = false;
            this.toolStripSeparator15.Name = "toolStripSeparator15";
            this.toolStripSeparator15.Size = new System.Drawing.Size(6, 50);
            // 
            // btnApproveTBP_New
            // 
            this.btnApproveTBP_New.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnApproveTBP_New.Image = global::Forms.Properties.Resources.Apply_32x32;
            this.btnApproveTBP_New.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnApproveTBP_New.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnApproveTBP_New.Name = "btnApproveTBP_New";
            this.btnApproveTBP_New.Size = new System.Drawing.Size(84, 52);
            this.btnApproveTBP_New.Text = "TBP duyệt";
            this.btnApproveTBP_New.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnApproveTBP_New.Click += new System.EventHandler(this.btnApproveTBP_New_Click);
            // 
            // toolStripSeparator14
            // 
            this.toolStripSeparator14.AutoSize = false;
            this.toolStripSeparator14.Name = "toolStripSeparator14";
            this.toolStripSeparator14.Size = new System.Drawing.Size(6, 50);
            // 
            // btnUnApproveTBP_New
            // 
            this.btnUnApproveTBP_New.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUnApproveTBP_New.Image = global::Forms.Properties.Resources.cancel_32x321;
            this.btnUnApproveTBP_New.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.btnUnApproveTBP_New.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnUnApproveTBP_New.Name = "btnUnApproveTBP_New";
            this.btnUnApproveTBP_New.Size = new System.Drawing.Size(105, 52);
            this.btnUnApproveTBP_New.Text = "TBP huỷ duyệt";
            this.btnUnApproveTBP_New.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnUnApproveTBP_New.Click += new System.EventHandler(this.btnUnApproveTBP_New_Click);
            // 
            // grdData
            // 
            this.grdData.ContextMenuStrip = this.contextMenuStrip1;
            this.grdData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdData.Location = new System.Drawing.Point(0, 0);
            this.grdData.MainView = this.grvData;
            this.grdData.Name = "grdData";
            this.grdData.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemCheckEdit1,
            this.repositoryItemMemoEdit7});
            this.grdData.Size = new System.Drawing.Size(1369, 356);
            this.grdData.TabIndex = 52;
            this.grdData.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.grvData});
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnTreeFolderContext,
            this.btnLogPaymentOrder,
            this.btnCopyPaymentOrder,
            this.btnExportExcels});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(223, 92);
            // 
            // btnTreeFolderContext
            // 
            this.btnTreeFolderContext.Name = "btnTreeFolderContext";
            this.btnTreeFolderContext.Size = new System.Drawing.Size(222, 22);
            this.btnTreeFolderContext.Text = "Cây thư mục";
            this.btnTreeFolderContext.Click += new System.EventHandler(this.btnTreeFolderContext_Click);
            // 
            // btnLogPaymentOrder
            // 
            this.btnLogPaymentOrder.Name = "btnLogPaymentOrder";
            this.btnLogPaymentOrder.Size = new System.Drawing.Size(222, 22);
            this.btnLogPaymentOrder.Text = "Lịch sử duyệt / không duyệt";
            this.btnLogPaymentOrder.Click += new System.EventHandler(this.btnLogPaymentOrder_Click);
            // 
            // btnCopyPaymentOrder
            // 
            this.btnCopyPaymentOrder.Name = "btnCopyPaymentOrder";
            this.btnCopyPaymentOrder.Size = new System.Drawing.Size(222, 22);
            this.btnCopyPaymentOrder.Tag = "";
            this.btnCopyPaymentOrder.Text = "Copy ĐNTT";
            this.btnCopyPaymentOrder.Click += new System.EventHandler(this.btnCopyPaymentOrder_Click);
            // 
            // btnExportExcels
            // 
            this.btnExportExcels.Name = "btnExportExcels";
            this.btnExportExcels.Size = new System.Drawing.Size(222, 22);
            this.btnExportExcels.Text = "In đề nghị";
            this.btnExportExcels.Click += new System.EventHandler(this.btnExportExcels_Click);
            // 
            // grvData
            // 
            this.grvData.Appearance.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.grvData.Appearance.HeaderPanel.Options.UseFont = true;
            this.grvData.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.grvData.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.grvData.Appearance.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.grvData.Appearance.HeaderPanel.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.grvData.Appearance.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.grvData.Appearance.Row.Font = new System.Drawing.Font("Tahoma", 9.75F);
            this.grvData.Appearance.Row.Options.UseFont = true;
            this.grvData.Appearance.Row.Options.UseTextOptions = true;
            this.grvData.Appearance.Row.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.grvData.Appearance.Row.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.grvData.AppearancePrint.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.grvData.AppearancePrint.HeaderPanel.Options.UseFont = true;
            this.grvData.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.grvData.AppearancePrint.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.grvData.AppearancePrint.HeaderPanel.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.grvData.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.grvData.AppearancePrint.Row.Font = new System.Drawing.Font("Tahoma", 9.75F);
            this.grvData.AppearancePrint.Row.Options.UseFont = true;
            this.grvData.AppearancePrint.Row.Options.UseTextOptions = true;
            this.grvData.AppearancePrint.Row.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.grvData.AppearancePrint.Row.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.grvData.AutoFillColumn = this.ReasonOrder;
            this.grvData.ColumnPanelRowHeight = 50;
            this.grvData.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colRowNum,
            this.colDateOrder,
            this.colCode,
            this.colFullName,
            this.colDepartmentName,
            this.colTypeOrderText,
            this.colTypeName,
            this.colStepName,
            this.colContentLog,
            this.colReasonCancel,
            this.colNote,
            this.colID,
            this.colPaymentOrderTypeID,
            this.colStep,
            this.colIsApproved,
            this.ReasonOrder,
            this.colTotalMoneyPayment,
            this.colTypeBankTransferText,
            this.colContentBankTransfer,
            this.colUnitPayment,
            this.colAccountingNote,
            this.colIsUrgent,
            this.colDeadlinePayment,
            this.colSuplierName,
            this.colPOCode,
            this.colTotalPayment,
            this.colIsIgnoreHR,
            this.colProjectFullName,
            this.colStepNew,
            this.colTotalPaymentActual});
            this.grvData.GridControl = this.grdData;
            this.grvData.Name = "grvData";
            this.grvData.OptionsBehavior.Editable = false;
            this.grvData.OptionsBehavior.ReadOnly = true;
            this.grvData.OptionsClipboard.CopyColumnHeaders = DevExpress.Utils.DefaultBoolean.False;
            this.grvData.OptionsPrint.AutoWidth = false;
            this.grvData.OptionsSelection.CheckBoxSelectorColumnWidth = 30;
            this.grvData.OptionsSelection.MultiSelect = true;
            this.grvData.OptionsSelection.MultiSelectMode = DevExpress.XtraGrid.Views.Grid.GridMultiSelectMode.CheckBoxRowSelect;
            this.grvData.OptionsView.ColumnAutoWidth = false;
            this.grvData.OptionsView.RowAutoHeight = true;
            this.grvData.OptionsView.ShowAutoFilterRow = true;
            this.grvData.OptionsView.ShowFooter = true;
            this.grvData.OptionsView.ShowGroupPanel = false;
            this.grvData.CustomDrawCell += new DevExpress.XtraGrid.Views.Base.RowCellCustomDrawEventHandler(this.grvData_CustomDrawCell);
            this.grvData.RowCellStyle += new DevExpress.XtraGrid.Views.Grid.RowCellStyleEventHandler(this.grvData_RowCellStyle);
            this.grvData.RowStyle += new DevExpress.XtraGrid.Views.Grid.RowStyleEventHandler(this.grvData_RowStyle);
            this.grvData.FocusedRowChanged += new DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventHandler(this.grvData_FocusedRowChanged);
            this.grvData.CustomColumnDisplayText += new DevExpress.XtraGrid.Views.Base.CustomColumnDisplayTextEventHandler(this.grvData_CustomColumnDisplayText);
            this.grvData.KeyDown += new System.Windows.Forms.KeyEventHandler(this.grvData_KeyDown);
            this.grvData.DoubleClick += new System.EventHandler(this.grvData_DoubleClick);
            // 
            // ReasonOrder
            // 
            this.ReasonOrder.Caption = "Lý do thanh toán";
            this.ReasonOrder.FieldName = "ReasonOrder";
            this.ReasonOrder.Name = "ReasonOrder";
            this.ReasonOrder.Visible = true;
            this.ReasonOrder.VisibleIndex = 10;
            this.ReasonOrder.Width = 229;
            // 
            // colRowNum
            // 
            this.colRowNum.AppearanceCell.Options.UseTextOptions = true;
            this.colRowNum.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colRowNum.Caption = "STT";
            this.colRowNum.FieldName = "RowNum";
            this.colRowNum.Name = "colRowNum";
            this.colRowNum.Visible = true;
            this.colRowNum.VisibleIndex = 1;
            this.colRowNum.Width = 58;
            // 
            // colDateOrder
            // 
            this.colDateOrder.AppearanceCell.Options.UseTextOptions = true;
            this.colDateOrder.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colDateOrder.Caption = "Ngày đề nghị";
            this.colDateOrder.DisplayFormat.FormatString = "dd/MM/yyyy";
            this.colDateOrder.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.colDateOrder.FieldName = "DateOrder";
            this.colDateOrder.Name = "colDateOrder";
            this.colDateOrder.Visible = true;
            this.colDateOrder.VisibleIndex = 3;
            this.colDateOrder.Width = 106;
            // 
            // colCode
            // 
            this.colCode.Caption = "Số đề nghị";
            this.colCode.FieldName = "Code";
            this.colCode.Name = "colCode";
            this.colCode.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Count, "Code", "{0}")});
            this.colCode.Visible = true;
            this.colCode.VisibleIndex = 5;
            this.colCode.Width = 149;
            // 
            // colFullName
            // 
            this.colFullName.Caption = "Người đề nghị";
            this.colFullName.FieldName = "FullName";
            this.colFullName.Name = "colFullName";
            this.colFullName.Visible = true;
            this.colFullName.VisibleIndex = 6;
            this.colFullName.Width = 128;
            // 
            // colDepartmentName
            // 
            this.colDepartmentName.Caption = "Bộ phận ";
            this.colDepartmentName.FieldName = "DepartmentName";
            this.colDepartmentName.Name = "colDepartmentName";
            this.colDepartmentName.Visible = true;
            this.colDepartmentName.VisibleIndex = 7;
            this.colDepartmentName.Width = 128;
            // 
            // colTypeOrderText
            // 
            this.colTypeOrderText.Caption = "Phân loại chính";
            this.colTypeOrderText.FieldName = "TypeOrderText";
            this.colTypeOrderText.Name = "colTypeOrderText";
            this.colTypeOrderText.Visible = true;
            this.colTypeOrderText.VisibleIndex = 8;
            this.colTypeOrderText.Width = 128;
            // 
            // colTypeName
            // 
            this.colTypeName.Caption = "Nội dung chính của đề nghị";
            this.colTypeName.FieldName = "TypeName";
            this.colTypeName.Name = "colTypeName";
            this.colTypeName.Visible = true;
            this.colTypeName.VisibleIndex = 9;
            this.colTypeName.Width = 212;
            // 
            // colStepName
            // 
            this.colStepName.Caption = "Tình trạng phiếu";
            this.colStepName.FieldName = "StepName";
            this.colStepName.Name = "colStepName";
            this.colStepName.Visible = true;
            this.colStepName.VisibleIndex = 18;
            this.colStepName.Width = 137;
            // 
            // colContentLog
            // 
            this.colContentLog.Caption = "Lịch sử duyệt / ko duyệt ";
            this.colContentLog.FieldName = "ContentLog";
            this.colContentLog.Name = "colContentLog";
            this.colContentLog.Visible = true;
            this.colContentLog.VisibleIndex = 19;
            this.colContentLog.Width = 111;
            // 
            // colReasonCancel
            // 
            this.colReasonCancel.Caption = "Lý do huỷ duyệt";
            this.colReasonCancel.FieldName = "ReasonCancel";
            this.colReasonCancel.Name = "colReasonCancel";
            this.colReasonCancel.Visible = true;
            this.colReasonCancel.VisibleIndex = 20;
            this.colReasonCancel.Width = 109;
            // 
            // colNote
            // 
            this.colNote.Caption = "Ghi chú / Chứng từ kèm theo";
            this.colNote.FieldName = "Note";
            this.colNote.Name = "colNote";
            this.colNote.Visible = true;
            this.colNote.VisibleIndex = 21;
            this.colNote.Width = 168;
            // 
            // colID
            // 
            this.colID.FieldName = "ID";
            this.colID.Name = "colID";
            // 
            // colPaymentOrderTypeID
            // 
            this.colPaymentOrderTypeID.FieldName = "PaymentOrderTypeID";
            this.colPaymentOrderTypeID.Name = "colPaymentOrderTypeID";
            this.colPaymentOrderTypeID.Width = 76;
            // 
            // colStep
            // 
            this.colStep.FieldName = "Step";
            this.colStep.Name = "colStep";
            // 
            // colIsApproved
            // 
            this.colIsApproved.FieldName = "IsApproved";
            this.colIsApproved.Name = "colIsApproved";
            // 
            // colTotalMoneyPayment
            // 
            this.colTotalMoneyPayment.AppearanceCell.Options.UseTextOptions = true;
            this.colTotalMoneyPayment.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.colTotalMoneyPayment.Caption = "Số tiền";
            this.colTotalMoneyPayment.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.colTotalMoneyPayment.FieldName = "TotalMoney";
            this.colTotalMoneyPayment.Name = "colTotalMoneyPayment";
            this.colTotalMoneyPayment.Visible = true;
            this.colTotalMoneyPayment.VisibleIndex = 11;
            this.colTotalMoneyPayment.Width = 114;
            // 
            // colTypeBankTransferText
            // 
            this.colTypeBankTransferText.Caption = "Hình thức thanh toán";
            this.colTypeBankTransferText.FieldName = "TypeBankTransferText";
            this.colTypeBankTransferText.Name = "colTypeBankTransferText";
            this.colTypeBankTransferText.Visible = true;
            this.colTypeBankTransferText.VisibleIndex = 15;
            this.colTypeBankTransferText.Width = 111;
            // 
            // colContentBankTransfer
            // 
            this.colContentBankTransfer.Caption = "Nội dung chuyển khoản";
            this.colContentBankTransfer.FieldName = "ContentBankTransfer";
            this.colContentBankTransfer.Name = "colContentBankTransfer";
            this.colContentBankTransfer.Visible = true;
            this.colContentBankTransfer.VisibleIndex = 16;
            this.colContentBankTransfer.Width = 189;
            // 
            // colUnitPayment
            // 
            this.colUnitPayment.Caption = "ĐVT";
            this.colUnitPayment.FieldName = "Unit";
            this.colUnitPayment.Name = "colUnitPayment";
            this.colUnitPayment.Visible = true;
            this.colUnitPayment.VisibleIndex = 14;
            this.colUnitPayment.Width = 45;
            // 
            // colAccountingNote
            // 
            this.colAccountingNote.Caption = "Ghi chú kế toán";
            this.colAccountingNote.FieldName = "AccountingNote";
            this.colAccountingNote.Name = "colAccountingNote";
            this.colAccountingNote.Visible = true;
            this.colAccountingNote.VisibleIndex = 22;
            this.colAccountingNote.Width = 143;
            // 
            // colIsUrgent
            // 
            this.colIsUrgent.Caption = "Thanh toán gấp";
            this.colIsUrgent.FieldName = "IsUrgent";
            this.colIsUrgent.Name = "colIsUrgent";
            this.colIsUrgent.Visible = true;
            this.colIsUrgent.VisibleIndex = 2;
            this.colIsUrgent.Width = 84;
            // 
            // colDeadlinePayment
            // 
            this.colDeadlinePayment.AppearanceCell.Options.UseTextOptions = true;
            this.colDeadlinePayment.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colDeadlinePayment.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colDeadlinePayment.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.colDeadlinePayment.Caption = "Deadline";
            this.colDeadlinePayment.ColumnEdit = this.repositoryItemMemoEdit7;
            this.colDeadlinePayment.DisplayFormat.FormatString = "dd/MM/yyyy HH:mm";
            this.colDeadlinePayment.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.colDeadlinePayment.FieldName = "DeadlinePayment";
            this.colDeadlinePayment.Name = "colDeadlinePayment";
            this.colDeadlinePayment.Visible = true;
            this.colDeadlinePayment.VisibleIndex = 4;
            this.colDeadlinePayment.Width = 98;
            // 
            // repositoryItemMemoEdit7
            // 
            this.repositoryItemMemoEdit7.Name = "repositoryItemMemoEdit7";
            // 
            // colSuplierName
            // 
            this.colSuplierName.Caption = "Nhà cung cấp";
            this.colSuplierName.FieldName = "SuplierName";
            this.colSuplierName.Name = "colSuplierName";
            this.colSuplierName.Visible = true;
            this.colSuplierName.VisibleIndex = 23;
            this.colSuplierName.Width = 208;
            // 
            // colPOCode
            // 
            this.colPOCode.Caption = "Số PO";
            this.colPOCode.FieldName = "POCode";
            this.colPOCode.Name = "colPOCode";
            this.colPOCode.Visible = true;
            this.colPOCode.VisibleIndex = 24;
            this.colPOCode.Width = 166;
            // 
            // colTotalPayment
            // 
            this.colTotalPayment.Caption = "Số tiền thanh toán";
            this.colTotalPayment.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.colTotalPayment.FieldName = "TotalPayment";
            this.colTotalPayment.Name = "colTotalPayment";
            this.colTotalPayment.Visible = true;
            this.colTotalPayment.VisibleIndex = 12;
            this.colTotalPayment.Width = 114;
            // 
            // colIsIgnoreHR
            // 
            this.colIsIgnoreHR.Caption = "Bỏ qua HR";
            this.colIsIgnoreHR.ColumnEdit = this.repositoryItemCheckEdit1;
            this.colIsIgnoreHR.FieldName = "IsIgnoreHR";
            this.colIsIgnoreHR.Name = "colIsIgnoreHR";
            this.colIsIgnoreHR.Visible = true;
            this.colIsIgnoreHR.VisibleIndex = 25;
            this.colIsIgnoreHR.Width = 82;
            // 
            // repositoryItemCheckEdit1
            // 
            this.repositoryItemCheckEdit1.AutoHeight = false;
            this.repositoryItemCheckEdit1.DisplayValueChecked = "x";
            this.repositoryItemCheckEdit1.DisplayValueUnchecked = " ";
            this.repositoryItemCheckEdit1.ExportMode = DevExpress.XtraEditors.Repository.ExportMode.DisplayText;
            this.repositoryItemCheckEdit1.Name = "repositoryItemCheckEdit1";
            this.repositoryItemCheckEdit1.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            // 
            // colProjectFullName
            // 
            this.colProjectFullName.Caption = "Dự án";
            this.colProjectFullName.FieldName = "ProjectFullName";
            this.colProjectFullName.Name = "colProjectFullName";
            this.colProjectFullName.Visible = true;
            this.colProjectFullName.VisibleIndex = 17;
            this.colProjectFullName.Width = 172;
            // 
            // colStepNew
            // 
            this.colStepNew.FieldName = "StepNew";
            this.colStepNew.Name = "colStepNew";
            // 
            // panelControl1
            // 
            this.panelControl1.AutoSize = true;
            this.panelControl1.Controls.Add(this.label12);
            this.panelControl1.Controls.Add(this.label8);
            this.panelControl1.Controls.Add(this.label6);
            this.panelControl1.Controls.Add(this.label11);
            this.panelControl1.Controls.Add(this.label10);
            this.panelControl1.Controls.Add(this.cboEmployee);
            this.panelControl1.Controls.Add(this.stackPanel1);
            this.panelControl1.Controls.Add(this.btnFind);
            this.panelControl1.Controls.Add(this.txtKeyword);
            this.panelControl1.Controls.Add(this.cboPaymentOrderType);
            this.panelControl1.Controls.Add(this.cboDepartment);
            this.panelControl1.Controls.Add(this.cboIsApproved);
            this.panelControl1.Controls.Add(this.cboTypeOrder);
            this.panelControl1.Controls.Add(this.dtpDateEnd);
            this.panelControl1.Controls.Add(this.label4);
            this.panelControl1.Controls.Add(this.label13);
            this.panelControl1.Controls.Add(this.label7);
            this.panelControl1.Controls.Add(this.label5);
            this.panelControl1.Controls.Add(this.label3);
            this.panelControl1.Controls.Add(this.label2);
            this.panelControl1.Controls.Add(this.dtpDateStart);
            this.panelControl1.Controls.Add(this.label1);
            this.panelControl1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelControl1.Location = new System.Drawing.Point(0, 55);
            this.panelControl1.Name = "panelControl1";
            this.panelControl1.Size = new System.Drawing.Size(1393, 66);
            this.panelControl1.TabIndex = 53;
            // 
            // label12
            // 
            this.label12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label12.BackColor = System.Drawing.Color.Orange;
            this.label12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label12.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(1108, 44);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(50, 15);
            this.label12.TabIndex = 2;
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label8.BackColor = System.Drawing.Color.Red;
            this.label8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label8.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(1268, 44);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(50, 15);
            this.label8.TabIndex = 2;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(603, 38);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(55, 16);
            this.label6.TabIndex = 2;
            this.label6.Text = "Từ khoá";
            // 
            // label11
            // 
            this.label11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(1164, 43);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(98, 16);
            this.label11.TabIndex = 2;
            this.label11.Text = "Thanh toán gấp";
            // 
            // label10
            // 
            this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(1324, 43);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(64, 16);
            this.label10.TabIndex = 2;
            this.label10.Text = "Huỷ duyệt";
            // 
            // cboEmployee
            // 
            this.cboEmployee.Location = new System.Drawing.Point(673, 8);
            this.cboEmployee.Name = "cboEmployee";
            this.cboEmployee.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboEmployee.Properties.Appearance.Options.UseFont = true;
            this.cboEmployee.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboEmployee.Properties.NullText = "";
            this.cboEmployee.Properties.PopupView = this.gridView3;
            this.cboEmployee.Properties.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemMemoEdit4});
            this.cboEmployee.Size = new System.Drawing.Size(193, 22);
            this.cboEmployee.TabIndex = 8;
            this.cboEmployee.EditValueChanged += new System.EventHandler(this.cboEmployee_EditValueChanged);
            // 
            // gridView3
            // 
            this.gridView3.Appearance.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.gridView3.Appearance.HeaderPanel.Options.UseFont = true;
            this.gridView3.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridView3.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.gridView3.Appearance.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridView3.Appearance.HeaderPanel.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridView3.Appearance.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridView3.Appearance.Row.Font = new System.Drawing.Font("Tahoma", 9.75F);
            this.gridView3.Appearance.Row.Options.UseFont = true;
            this.gridView3.Appearance.Row.Options.UseTextOptions = true;
            this.gridView3.Appearance.Row.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridView3.Appearance.Row.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridView3.ColumnPanelRowHeight = 40;
            this.gridView3.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn7,
            this.gridColumn8,
            this.gridColumn9});
            this.gridView3.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.gridView3.GroupCount = 1;
            this.gridView3.Name = "gridView3";
            this.gridView3.OptionsBehavior.AutoExpandAllGroups = true;
            this.gridView3.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridView3.OptionsView.RowAutoHeight = true;
            this.gridView3.OptionsView.ShowGroupPanel = false;
            this.gridView3.SortInfo.AddRange(new DevExpress.XtraGrid.Columns.GridColumnSortInfo[] {
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.gridColumn9, DevExpress.Data.ColumnSortOrder.Ascending)});
            // 
            // gridColumn7
            // 
            this.gridColumn7.Caption = "Mã nhân viên";
            this.gridColumn7.FieldName = "Code";
            this.gridColumn7.Name = "gridColumn7";
            this.gridColumn7.Visible = true;
            this.gridColumn7.VisibleIndex = 0;
            this.gridColumn7.Width = 379;
            // 
            // gridColumn8
            // 
            this.gridColumn8.Caption = "Tên nhân viên";
            this.gridColumn8.FieldName = "FullName";
            this.gridColumn8.Name = "gridColumn8";
            this.gridColumn8.Visible = true;
            this.gridColumn8.VisibleIndex = 1;
            this.gridColumn8.Width = 659;
            // 
            // gridColumn9
            // 
            this.gridColumn9.Caption = "Phòng ban";
            this.gridColumn9.FieldName = "DepartmentName";
            this.gridColumn9.FieldNameSortGroup = "DepartmentSTT";
            this.gridColumn9.Name = "gridColumn9";
            this.gridColumn9.Visible = true;
            this.gridColumn9.VisibleIndex = 2;
            // 
            // repositoryItemMemoEdit4
            // 
            this.repositoryItemMemoEdit4.Name = "repositoryItemMemoEdit4";
            // 
            // stackPanel1
            // 
            this.stackPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.stackPanel1.AutoSize = true;
            this.stackPanel1.Controls.Add(this.btnFirst);
            this.stackPanel1.Controls.Add(this.btnPrev);
            this.stackPanel1.Controls.Add(this.txtPageNumber);
            this.stackPanel1.Controls.Add(this.label9);
            this.stackPanel1.Controls.Add(this.txtTotalPage);
            this.stackPanel1.Controls.Add(this.btnNext);
            this.stackPanel1.Controls.Add(this.btnLast);
            this.stackPanel1.Controls.Add(this.txtPageSize);
            this.stackPanel1.Location = new System.Drawing.Point(1094, 5);
            this.stackPanel1.Name = "stackPanel1";
            this.stackPanel1.Size = new System.Drawing.Size(287, 33);
            this.stackPanel1.TabIndex = 1;
            // 
            // btnFirst
            // 
            this.btnFirst.Appearance.BackColor = System.Drawing.SystemColors.Control;
            this.btnFirst.Appearance.ForeColor = System.Drawing.Color.Transparent;
            this.btnFirst.Appearance.Options.UseBackColor = true;
            this.btnFirst.Appearance.Options.UseForeColor = true;
            this.btnFirst.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnFirst.ImageOptions.Image")));
            this.btnFirst.Location = new System.Drawing.Point(3, 5);
            this.btnFirst.Name = "btnFirst";
            this.btnFirst.PaintStyle = DevExpress.XtraEditors.Controls.PaintStyles.Light;
            this.btnFirst.Size = new System.Drawing.Size(23, 23);
            this.btnFirst.TabIndex = 143;
            this.btnFirst.Text = "Trang trước";
            this.btnFirst.Click += new System.EventHandler(this.btnFirst_Click);
            // 
            // btnPrev
            // 
            this.btnPrev.Appearance.BackColor = System.Drawing.SystemColors.Control;
            this.btnPrev.Appearance.Options.UseBackColor = true;
            this.btnPrev.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnPrev.ImageOptions.Image")));
            this.btnPrev.Location = new System.Drawing.Point(32, 5);
            this.btnPrev.Name = "btnPrev";
            this.btnPrev.PaintStyle = DevExpress.XtraEditors.Controls.PaintStyles.Light;
            this.btnPrev.Size = new System.Drawing.Size(23, 23);
            this.btnPrev.TabIndex = 141;
            this.btnPrev.Click += new System.EventHandler(this.btnPrev_Click);
            // 
            // txtPageNumber
            // 
            this.txtPageNumber.Location = new System.Drawing.Point(61, 6);
            this.txtPageNumber.Name = "txtPageNumber";
            this.txtPageNumber.ReadOnly = true;
            this.txtPageNumber.Size = new System.Drawing.Size(25, 21);
            this.txtPageNumber.TabIndex = 152;
            this.txtPageNumber.Text = "1";
            this.txtPageNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(92, 6);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(16, 20);
            this.label9.TabIndex = 151;
            this.label9.Text = "/";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtTotalPage
            // 
            this.txtTotalPage.Location = new System.Drawing.Point(114, 6);
            this.txtTotalPage.Name = "txtTotalPage";
            this.txtTotalPage.ReadOnly = true;
            this.txtTotalPage.Size = new System.Drawing.Size(25, 21);
            this.txtTotalPage.TabIndex = 12;
            this.txtTotalPage.Text = "1";
            this.txtTotalPage.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnNext
            // 
            this.btnNext.Appearance.BackColor = System.Drawing.SystemColors.Control;
            this.btnNext.Appearance.Options.UseBackColor = true;
            this.btnNext.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnNext.ImageOptions.Image")));
            this.btnNext.Location = new System.Drawing.Point(145, 5);
            this.btnNext.Name = "btnNext";
            this.btnNext.PaintStyle = DevExpress.XtraEditors.Controls.PaintStyles.Light;
            this.btnNext.Size = new System.Drawing.Size(23, 23);
            this.btnNext.TabIndex = 142;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnLast
            // 
            this.btnLast.Appearance.BackColor = System.Drawing.SystemColors.Control;
            this.btnLast.Appearance.Options.UseBackColor = true;
            this.btnLast.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnLast.ImageOptions.Image")));
            this.btnLast.Location = new System.Drawing.Point(174, 5);
            this.btnLast.Name = "btnLast";
            this.btnLast.PaintStyle = DevExpress.XtraEditors.Controls.PaintStyles.Light;
            this.btnLast.Size = new System.Drawing.Size(23, 23);
            this.btnLast.TabIndex = 144;
            this.btnLast.Text = "`";
            this.btnLast.Click += new System.EventHandler(this.btnLast_Click);
            // 
            // txtPageSize
            // 
            this.txtPageSize.BackColor = System.Drawing.SystemColors.Control;
            this.txtPageSize.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPageSize.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.txtPageSize.Location = new System.Drawing.Point(203, 5);
            this.txtPageSize.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
            this.txtPageSize.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.txtPageSize.Name = "txtPageSize";
            this.txtPageSize.Size = new System.Drawing.Size(81, 23);
            this.txtPageSize.TabIndex = 12;
            this.txtPageSize.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtPageSize.Value = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            // 
            // btnFind
            // 
            this.btnFind.AutoSize = true;
            this.btnFind.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFind.Location = new System.Drawing.Point(997, 33);
            this.btnFind.Name = "btnFind";
            this.btnFind.Size = new System.Drawing.Size(75, 26);
            this.btnFind.TabIndex = 7;
            this.btnFind.Text = "Tìm kiếm";
            this.btnFind.UseVisualStyleBackColor = true;
            this.btnFind.Click += new System.EventHandler(this.btnFind_Click);
            // 
            // txtKeyword
            // 
            this.txtKeyword.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtKeyword.Location = new System.Drawing.Point(673, 35);
            this.txtKeyword.Name = "txtKeyword";
            this.txtKeyword.Size = new System.Drawing.Size(318, 23);
            this.txtKeyword.TabIndex = 6;
            // 
            // cboPaymentOrderType
            // 
            this.cboPaymentOrderType.Location = new System.Drawing.Point(342, 35);
            this.cboPaymentOrderType.Name = "cboPaymentOrderType";
            this.cboPaymentOrderType.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboPaymentOrderType.Properties.Appearance.Options.UseFont = true;
            this.cboPaymentOrderType.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboPaymentOrderType.Properties.NullText = "";
            this.cboPaymentOrderType.Properties.PopupView = this.gridView2;
            this.cboPaymentOrderType.Properties.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemMemoEdit3});
            this.cboPaymentOrderType.Size = new System.Drawing.Size(255, 22);
            this.cboPaymentOrderType.TabIndex = 5;
            this.cboPaymentOrderType.EditValueChanged += new System.EventHandler(this.cboPaymentOrderType_EditValueChanged);
            // 
            // gridView2
            // 
            this.gridView2.Appearance.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.gridView2.Appearance.HeaderPanel.Options.UseFont = true;
            this.gridView2.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridView2.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.gridView2.Appearance.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridView2.Appearance.HeaderPanel.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridView2.Appearance.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridView2.Appearance.Row.Font = new System.Drawing.Font("Tahoma", 9.75F);
            this.gridView2.Appearance.Row.Options.UseFont = true;
            this.gridView2.Appearance.Row.Options.UseTextOptions = true;
            this.gridView2.Appearance.Row.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridView2.Appearance.Row.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridView2.ColumnPanelRowHeight = 40;
            this.gridView2.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn3,
            this.gridColumn4});
            this.gridView2.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.gridView2.Name = "gridView2";
            this.gridView2.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridView2.OptionsView.RowAutoHeight = true;
            this.gridView2.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumn3
            // 
            this.gridColumn3.Caption = "Mã loại";
            this.gridColumn3.FieldName = "TypeCode";
            this.gridColumn3.Name = "gridColumn3";
            this.gridColumn3.Visible = true;
            this.gridColumn3.VisibleIndex = 0;
            this.gridColumn3.Width = 379;
            // 
            // gridColumn4
            // 
            this.gridColumn4.Caption = "Tên loại";
            this.gridColumn4.ColumnEdit = this.repositoryItemMemoEdit3;
            this.gridColumn4.FieldName = "TypeName";
            this.gridColumn4.Name = "gridColumn4";
            this.gridColumn4.Visible = true;
            this.gridColumn4.VisibleIndex = 1;
            this.gridColumn4.Width = 659;
            // 
            // repositoryItemMemoEdit3
            // 
            this.repositoryItemMemoEdit3.Name = "repositoryItemMemoEdit3";
            // 
            // cboDepartment
            // 
            this.cboDepartment.Location = new System.Drawing.Point(438, 8);
            this.cboDepartment.Name = "cboDepartment";
            this.cboDepartment.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboDepartment.Properties.Appearance.Options.UseFont = true;
            this.cboDepartment.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cboDepartment.Properties.NullText = "";
            this.cboDepartment.Properties.PopupView = this.searchLookUpEdit1View;
            this.cboDepartment.Properties.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemMemoEdit2});
            this.cboDepartment.Size = new System.Drawing.Size(159, 22);
            this.cboDepartment.TabIndex = 5;
            this.cboDepartment.EditValueChanged += new System.EventHandler(this.cboDepartment_EditValueChanged);
            // 
            // searchLookUpEdit1View
            // 
            this.searchLookUpEdit1View.Appearance.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.searchLookUpEdit1View.Appearance.HeaderPanel.Options.UseFont = true;
            this.searchLookUpEdit1View.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.searchLookUpEdit1View.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.searchLookUpEdit1View.Appearance.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.searchLookUpEdit1View.Appearance.HeaderPanel.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.searchLookUpEdit1View.Appearance.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.searchLookUpEdit1View.Appearance.Row.Font = new System.Drawing.Font("Tahoma", 9.75F);
            this.searchLookUpEdit1View.Appearance.Row.Options.UseFont = true;
            this.searchLookUpEdit1View.Appearance.Row.Options.UseTextOptions = true;
            this.searchLookUpEdit1View.Appearance.Row.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.searchLookUpEdit1View.Appearance.Row.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.searchLookUpEdit1View.ColumnPanelRowHeight = 40;
            this.searchLookUpEdit1View.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn1,
            this.gridColumn2});
            this.searchLookUpEdit1View.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.searchLookUpEdit1View.Name = "searchLookUpEdit1View";
            this.searchLookUpEdit1View.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.searchLookUpEdit1View.OptionsView.RowAutoHeight = true;
            this.searchLookUpEdit1View.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumn1
            // 
            this.gridColumn1.Caption = "Mã phòng ban";
            this.gridColumn1.FieldName = "Code";
            this.gridColumn1.Name = "gridColumn1";
            this.gridColumn1.Visible = true;
            this.gridColumn1.VisibleIndex = 0;
            this.gridColumn1.Width = 373;
            // 
            // gridColumn2
            // 
            this.gridColumn2.Caption = "Tên phòng ban";
            this.gridColumn2.ColumnEdit = this.repositoryItemMemoEdit2;
            this.gridColumn2.FieldName = "Name";
            this.gridColumn2.Name = "gridColumn2";
            this.gridColumn2.Visible = true;
            this.gridColumn2.VisibleIndex = 1;
            this.gridColumn2.Width = 665;
            // 
            // repositoryItemMemoEdit2
            // 
            this.repositoryItemMemoEdit2.Name = "repositoryItemMemoEdit2";
            // 
            // cboIsApproved
            // 
            this.cboIsApproved.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboIsApproved.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboIsApproved.FormattingEnabled = true;
            this.cboIsApproved.Items.AddRange(new object[] {
            "--Tất cả--",
            "Chờ duyệt",
            "Đã duyệt",
            "Huỷ duyệt",
            "Bổ sung chứng từ"});
            this.cboIsApproved.Location = new System.Drawing.Point(945, 7);
            this.cboIsApproved.Name = "cboIsApproved";
            this.cboIsApproved.Size = new System.Drawing.Size(127, 24);
            this.cboIsApproved.TabIndex = 4;
            this.cboIsApproved.SelectedIndexChanged += new System.EventHandler(this.cboIsApproved_SelectedIndexChanged);
            // 
            // cboTypeOrder
            // 
            this.cboTypeOrder.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTypeOrder.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboTypeOrder.FormattingEnabled = true;
            this.cboTypeOrder.Items.AddRange(new object[] {
            "--Tất cả--",
            "Đề nghị tạm ứng",
            "Đề nghị thanh toán"});
            this.cboTypeOrder.Location = new System.Drawing.Point(88, 34);
            this.cboTypeOrder.Name = "cboTypeOrder";
            this.cboTypeOrder.Size = new System.Drawing.Size(161, 24);
            this.cboTypeOrder.TabIndex = 4;
            this.cboTypeOrder.SelectedIndexChanged += new System.EventHandler(this.cboIsComingExpired_SelectedIndexChanged);
            // 
            // dtpDateEnd
            // 
            this.dtpDateEnd.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpDateEnd.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDateEnd.Location = new System.Drawing.Point(255, 8);
            this.dtpDateEnd.Name = "dtpDateEnd";
            this.dtpDateEnd.Size = new System.Drawing.Size(103, 23);
            this.dtpDateEnd.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(252, 38);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 16);
            this.label4.TabIndex = 2;
            this.label4.Text = "Loại nội dung";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(872, 11);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(67, 16);
            this.label13.TabIndex = 2;
            this.label13.Text = "Tình trạng";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(5, 38);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(77, 16);
            this.label7.TabIndex = 2;
            this.label7.Text = "Loại đề nghị";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(603, 11);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(64, 16);
            this.label5.TabIndex = 2;
            this.label5.Text = "Nhân viên";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(364, 11);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Phòng ban";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(187, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "Đến ngày";
            // 
            // dtpDateStart
            // 
            this.dtpDateStart.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpDateStart.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDateStart.Location = new System.Drawing.Point(88, 5);
            this.dtpDateStart.Name = "dtpDateStart";
            this.dtpDateStart.Size = new System.Drawing.Size(93, 23);
            this.dtpDateStart.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(5, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = "Từ ngày";
            // 
            // xtraTabControl1
            // 
            this.xtraTabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.xtraTabControl1.AppearancePage.HeaderActive.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.xtraTabControl1.AppearancePage.HeaderActive.Font = new System.Drawing.Font("Tahoma", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xtraTabControl1.AppearancePage.HeaderActive.ForeColor = DevExpress.LookAndFeel.DXSkinColors.ForeColors.ControlText;
            this.xtraTabControl1.AppearancePage.HeaderActive.Options.UseBackColor = true;
            this.xtraTabControl1.AppearancePage.HeaderActive.Options.UseFont = true;
            this.xtraTabControl1.AppearancePage.HeaderActive.Options.UseForeColor = true;
            this.xtraTabControl1.Location = new System.Drawing.Point(11, 126);
            this.xtraTabControl1.Margin = new System.Windows.Forms.Padding(2);
            this.xtraTabControl1.Name = "xtraTabControl1";
            this.xtraTabControl1.SelectedTabPage = this.xtraTabPage1;
            this.xtraTabControl1.Size = new System.Drawing.Size(1371, 568);
            this.xtraTabControl1.TabIndex = 55;
            this.xtraTabControl1.TabPages.AddRange(new DevExpress.XtraTab.XtraTabPage[] {
            this.xtraTabPage1,
            this.xtraTabPage2});
            this.xtraTabControl1.SelectedPageChanged += new DevExpress.XtraTab.TabPageChangedEventHandler(this.xtraTabControl1_SelectedPageChanged);
            // 
            // xtraTabPage1
            // 
            this.xtraTabPage1.Controls.Add(this.splitContainerControl1);
            this.xtraTabPage1.Margin = new System.Windows.Forms.Padding(2);
            this.xtraTabPage1.Name = "xtraTabPage1";
            this.xtraTabPage1.Size = new System.Drawing.Size(1369, 543);
            this.xtraTabPage1.Text = "Đề nghị thanh toán";
            // 
            // splitContainerControl1
            // 
            this.splitContainerControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainerControl1.FixedPanel = DevExpress.XtraEditors.SplitFixedPanel.None;
            this.splitContainerControl1.Horizontal = false;
            this.splitContainerControl1.Location = new System.Drawing.Point(0, 0);
            this.splitContainerControl1.Name = "splitContainerControl1";
            // 
            // splitContainerControl1.Panel1
            // 
            this.splitContainerControl1.Panel1.Controls.Add(this.grdData);
            this.splitContainerControl1.Panel1.Text = "Panel1";
            // 
            // splitContainerControl1.Panel2
            // 
            this.splitContainerControl1.Panel2.Controls.Add(this.splitContainerControl2);
            this.splitContainerControl1.Panel2.Text = "Panel2";
            this.splitContainerControl1.Size = new System.Drawing.Size(1369, 543);
            this.splitContainerControl1.SplitterPosition = 356;
            this.splitContainerControl1.TabIndex = 54;
            // 
            // splitContainerControl2
            // 
            this.splitContainerControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainerControl2.FixedPanel = DevExpress.XtraEditors.SplitFixedPanel.None;
            this.splitContainerControl2.Location = new System.Drawing.Point(0, 0);
            this.splitContainerControl2.Name = "splitContainerControl2";
            // 
            // splitContainerControl2.Panel1
            // 
            this.splitContainerControl2.Panel1.Controls.Add(this.tlDetail);
            this.splitContainerControl2.Panel1.Text = "Panel1";
            // 
            // splitContainerControl2.Panel2
            // 
            this.splitContainerControl2.Panel2.Controls.Add(this.grdDataFile);
            this.splitContainerControl2.Panel2.Text = "Panel2";
            this.splitContainerControl2.Size = new System.Drawing.Size(1369, 177);
            this.splitContainerControl2.SplitterPosition = 942;
            this.splitContainerControl2.TabIndex = 55;
            // 
            // tlDetail
            // 
            this.tlDetail.Appearance.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tlDetail.Appearance.HeaderPanel.Options.UseFont = true;
            this.tlDetail.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.tlDetail.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.tlDetail.Appearance.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.tlDetail.Appearance.HeaderPanel.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.tlDetail.Appearance.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.tlDetail.Appearance.Row.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tlDetail.Appearance.Row.Options.UseFont = true;
            this.tlDetail.Appearance.Row.Options.UseTextOptions = true;
            this.tlDetail.Appearance.Row.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.tlDetail.Appearance.Row.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.tlDetail.ColumnPanelRowHeight = 50;
            this.tlDetail.Columns.AddRange(new DevExpress.XtraTreeList.Columns.TreeListColumn[] {
            this.treeListColumn1,
            this.colContentPayment,
            this.colUnit,
            this.colQuantity,
            this.colUnitPrice,
            this.colTotalMoney,
            this.treeListColumn7,
            this.colPaymentPercentage,
            this.colTotalPaymentAmount});
            this.tlDetail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlDetail.Location = new System.Drawing.Point(0, 0);
            this.tlDetail.Name = "tlDetail";
            this.tlDetail.OptionsBehavior.Editable = false;
            this.tlDetail.OptionsBehavior.ReadOnly = true;
            this.tlDetail.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemMemoEdit5});
            this.tlDetail.Size = new System.Drawing.Size(942, 177);
            this.tlDetail.TabIndex = 54;
            this.tlDetail.NodeCellStyle += new DevExpress.XtraTreeList.GetCustomNodeCellStyleEventHandler(this.tlDetail_NodeCellStyle);
            // 
            // treeListColumn1
            // 
            this.treeListColumn1.Caption = "STT";
            this.treeListColumn1.FieldName = "Stt";
            this.treeListColumn1.Name = "treeListColumn1";
            this.treeListColumn1.Visible = true;
            this.treeListColumn1.VisibleIndex = 0;
            this.treeListColumn1.Width = 35;
            // 
            // colContentPayment
            // 
            this.colContentPayment.Caption = "Nội dung thanh toán";
            this.colContentPayment.ColumnEdit = this.repositoryItemMemoEdit5;
            this.colContentPayment.FieldName = "ContentPayment";
            this.colContentPayment.Name = "colContentPayment";
            this.colContentPayment.Visible = true;
            this.colContentPayment.VisibleIndex = 1;
            this.colContentPayment.Width = 226;
            // 
            // repositoryItemMemoEdit5
            // 
            this.repositoryItemMemoEdit5.Name = "repositoryItemMemoEdit5";
            // 
            // colUnit
            // 
            this.colUnit.Caption = "Đơn vị tính";
            this.colUnit.FieldName = "Unit";
            this.colUnit.Name = "colUnit";
            this.colUnit.Visible = true;
            this.colUnit.VisibleIndex = 2;
            this.colUnit.Width = 79;
            // 
            // colQuantity
            // 
            this.colQuantity.AppearanceCell.Options.UseTextOptions = true;
            this.colQuantity.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.colQuantity.Caption = "Số lượng";
            this.colQuantity.FieldName = "Quantity";
            this.colQuantity.Format.FormatString = "n2";
            this.colQuantity.Format.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.colQuantity.Name = "colQuantity";
            this.colQuantity.Visible = true;
            this.colQuantity.VisibleIndex = 3;
            this.colQuantity.Width = 72;
            // 
            // colUnitPrice
            // 
            this.colUnitPrice.AppearanceCell.Options.UseTextOptions = true;
            this.colUnitPrice.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.colUnitPrice.Caption = "Đơn giá";
            this.colUnitPrice.FieldName = "UnitPrice";
            this.colUnitPrice.Format.FormatString = "n2";
            this.colUnitPrice.Format.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.colUnitPrice.Name = "colUnitPrice";
            this.colUnitPrice.Visible = true;
            this.colUnitPrice.VisibleIndex = 4;
            this.colUnitPrice.Width = 79;
            // 
            // colTotalMoney
            // 
            this.colTotalMoney.AppearanceCell.Options.UseTextOptions = true;
            this.colTotalMoney.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.colTotalMoney.Caption = "Thành tiền";
            this.colTotalMoney.FieldName = "TotalMoney";
            this.colTotalMoney.Format.FormatString = "n2";
            this.colTotalMoney.Format.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.colTotalMoney.Name = "colTotalMoney";
            this.colTotalMoney.Visible = true;
            this.colTotalMoney.VisibleIndex = 5;
            this.colTotalMoney.Width = 95;
            // 
            // treeListColumn7
            // 
            this.treeListColumn7.Caption = "Ghi chú / Chứng từ kèm theo";
            this.treeListColumn7.ColumnEdit = this.repositoryItemMemoEdit5;
            this.treeListColumn7.FieldName = "Note";
            this.treeListColumn7.Name = "treeListColumn7";
            this.treeListColumn7.Visible = true;
            this.treeListColumn7.VisibleIndex = 8;
            this.treeListColumn7.Width = 171;
            // 
            // colPaymentPercentage
            // 
            this.colPaymentPercentage.AppearanceCell.Options.UseTextOptions = true;
            this.colPaymentPercentage.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.colPaymentPercentage.Caption = "% Thanh toán";
            this.colPaymentPercentage.FieldName = "PaymentPercentage";
            this.colPaymentPercentage.Format.FormatString = "n2";
            this.colPaymentPercentage.Format.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.colPaymentPercentage.Name = "colPaymentPercentage";
            this.colPaymentPercentage.Visible = true;
            this.colPaymentPercentage.VisibleIndex = 6;
            this.colPaymentPercentage.Width = 70;
            // 
            // colTotalPaymentAmount
            // 
            this.colTotalPaymentAmount.AppearanceCell.Options.UseTextOptions = true;
            this.colTotalPaymentAmount.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.colTotalPaymentAmount.Caption = "Tổng tiền thanh toán";
            this.colTotalPaymentAmount.FieldName = "TotalPaymentAmount";
            this.colTotalPaymentAmount.Format.FormatString = "n2";
            this.colTotalPaymentAmount.Format.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.colTotalPaymentAmount.Name = "colTotalPaymentAmount";
            this.colTotalPaymentAmount.Visible = true;
            this.colTotalPaymentAmount.VisibleIndex = 7;
            this.colTotalPaymentAmount.Width = 90;
            // 
            // grdDataFile
            // 
            this.grdDataFile.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdDataFile.Location = new System.Drawing.Point(0, 0);
            this.grdDataFile.MainView = this.grvDataFile;
            this.grdDataFile.Name = "grdDataFile";
            this.grdDataFile.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemMemoEdit6,
            this.btnDownloadFile});
            this.grdDataFile.Size = new System.Drawing.Size(417, 177);
            this.grdDataFile.TabIndex = 0;
            this.grdDataFile.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.grvDataFile});
            // 
            // grvDataFile
            // 
            this.grvDataFile.Appearance.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grvDataFile.Appearance.HeaderPanel.Options.UseFont = true;
            this.grvDataFile.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.grvDataFile.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.grvDataFile.Appearance.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.grvDataFile.Appearance.HeaderPanel.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.grvDataFile.Appearance.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.grvDataFile.Appearance.Row.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grvDataFile.Appearance.Row.Options.UseFont = true;
            this.grvDataFile.Appearance.Row.Options.UseTextOptions = true;
            this.grvDataFile.Appearance.Row.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.grvDataFile.Appearance.Row.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.grvDataFile.ColumnPanelRowHeight = 50;
            this.grvDataFile.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colFileName,
            this.colServerPath,
            this.gridColumn5});
            this.grvDataFile.GridControl = this.grdDataFile;
            this.grvDataFile.Name = "grvDataFile";
            this.grvDataFile.OptionsClipboard.CopyColumnHeaders = DevExpress.Utils.DefaultBoolean.False;
            this.grvDataFile.OptionsSelection.MultiSelect = true;
            this.grvDataFile.OptionsSelection.MultiSelectMode = DevExpress.XtraGrid.Views.Grid.GridMultiSelectMode.CellSelect;
            this.grvDataFile.OptionsView.RowAutoHeight = true;
            this.grvDataFile.OptionsView.ShowGroupPanel = false;
            this.grvDataFile.DoubleClick += new System.EventHandler(this.grvDataFile_DoubleClick);
            // 
            // colFileName
            // 
            this.colFileName.Caption = "File đính kèm";
            this.colFileName.ColumnEdit = this.repositoryItemMemoEdit6;
            this.colFileName.FieldName = "FileName";
            this.colFileName.Name = "colFileName";
            this.colFileName.OptionsColumn.AllowEdit = false;
            this.colFileName.OptionsColumn.ReadOnly = true;
            this.colFileName.Visible = true;
            this.colFileName.VisibleIndex = 0;
            this.colFileName.Width = 381;
            // 
            // repositoryItemMemoEdit6
            // 
            this.repositoryItemMemoEdit6.Name = "repositoryItemMemoEdit6";
            // 
            // colServerPath
            // 
            this.colServerPath.FieldName = "ServerPath";
            this.colServerPath.Name = "colServerPath";
            // 
            // gridColumn5
            // 
            this.gridColumn5.ColumnEdit = this.btnDownloadFile;
            this.gridColumn5.Name = "gridColumn5";
            this.gridColumn5.Width = 37;
            // 
            // btnDownloadFile
            // 
            this.btnDownloadFile.AutoHeight = false;
            editorButtonImageOptions1.Image = global::Forms.Properties.Resources.download_16x16;
            this.btnDownloadFile.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Glyph, "", -1, true, true, false, editorButtonImageOptions1, new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject1, serializableAppearanceObject2, serializableAppearanceObject3, serializableAppearanceObject4, "", null, null, DevExpress.Utils.ToolTipAnchor.Default)});
            this.btnDownloadFile.Name = "btnDownloadFile";
            this.btnDownloadFile.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            this.btnDownloadFile.Click += new System.EventHandler(this.btnDownloadFile_Click);
            // 
            // xtraTabPage2
            // 
            this.xtraTabPage2.Controls.Add(this.splitContainerControl3);
            this.xtraTabPage2.Margin = new System.Windows.Forms.Padding(2);
            this.xtraTabPage2.Name = "xtraTabPage2";
            this.xtraTabPage2.Size = new System.Drawing.Size(1369, 543);
            this.xtraTabPage2.Text = "Đề nghị thanh toán đặc biệt";
            // 
            // splitContainerControl3
            // 
            this.splitContainerControl3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainerControl3.FixedPanel = DevExpress.XtraEditors.SplitFixedPanel.None;
            this.splitContainerControl3.Horizontal = false;
            this.splitContainerControl3.Location = new System.Drawing.Point(0, 0);
            this.splitContainerControl3.Margin = new System.Windows.Forms.Padding(2);
            this.splitContainerControl3.Name = "splitContainerControl3";
            // 
            // splitContainerControl3.Panel1
            // 
            this.splitContainerControl3.Panel1.Controls.Add(this.grdPaymentSpe);
            this.splitContainerControl3.Panel1.Text = "Panel1";
            // 
            // splitContainerControl3.Panel2
            // 
            this.splitContainerControl3.Panel2.Controls.Add(this.splitContainerControl4);
            this.splitContainerControl3.Panel2.Text = "Panel2";
            this.splitContainerControl3.Size = new System.Drawing.Size(1369, 543);
            this.splitContainerControl3.SplitterPosition = 350;
            this.splitContainerControl3.TabIndex = 58;
            // 
            // grdPaymentSpe
            // 
            this.grdPaymentSpe.ContextMenuStrip = this.contextMenuStrip1;
            this.grdPaymentSpe.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdPaymentSpe.Location = new System.Drawing.Point(0, 0);
            this.grdPaymentSpe.MainView = this.grvPaymentSpe;
            this.grdPaymentSpe.Name = "grdPaymentSpe";
            this.grdPaymentSpe.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemCheckEdit2,
            this.repositoryItemMemoEdit8});
            this.grdPaymentSpe.Size = new System.Drawing.Size(1369, 350);
            this.grdPaymentSpe.TabIndex = 53;
            this.grdPaymentSpe.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.grvPaymentSpe});
            // 
            // grvPaymentSpe
            // 
            this.grvPaymentSpe.Appearance.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.grvPaymentSpe.Appearance.HeaderPanel.Options.UseFont = true;
            this.grvPaymentSpe.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.grvPaymentSpe.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.grvPaymentSpe.Appearance.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.grvPaymentSpe.Appearance.HeaderPanel.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.grvPaymentSpe.Appearance.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.grvPaymentSpe.Appearance.Row.Font = new System.Drawing.Font("Tahoma", 9.75F);
            this.grvPaymentSpe.Appearance.Row.Options.UseFont = true;
            this.grvPaymentSpe.Appearance.Row.Options.UseTextOptions = true;
            this.grvPaymentSpe.Appearance.Row.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.grvPaymentSpe.Appearance.Row.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.grvPaymentSpe.AppearancePrint.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.grvPaymentSpe.AppearancePrint.HeaderPanel.Options.UseFont = true;
            this.grvPaymentSpe.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.grvPaymentSpe.AppearancePrint.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.grvPaymentSpe.AppearancePrint.HeaderPanel.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.grvPaymentSpe.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.grvPaymentSpe.AppearancePrint.Row.Font = new System.Drawing.Font("Tahoma", 9.75F);
            this.grvPaymentSpe.AppearancePrint.Row.Options.UseFont = true;
            this.grvPaymentSpe.AppearancePrint.Row.Options.UseTextOptions = true;
            this.grvPaymentSpe.AppearancePrint.Row.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.grvPaymentSpe.AppearancePrint.Row.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.grvPaymentSpe.ColumnPanelRowHeight = 50;
            this.grvPaymentSpe.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colPaymentSpeStt,
            this.colSpeIsUrgent,
            this.colPaymentSpeDateOrder,
            this.colPaymentSpeCode,
            this.colSpeFullName,
            this.colSpeDeadlinePayment,
            this.colPaymentSpeDepartmentName,
            this.colPaymentSpeTypeOrderText,
            this.colPaymentOrderTypeName,
            this.colSpeTotalMoney,
            this.colSpeUnit,
            this.colSpeStepName,
            this.colSpeContentLog,
            this.colSpeCustomerName,
            this.colSpeReasonCancel,
            this.colSpeNote,
            this.colPaymentSpeId,
            this.colSpePaymentOrderTypeID,
            this.colSpeStep,
            this.colSpeIsApproved,
            this.colTypeDocumentText,
            this.colSpeNumberDocument});
            this.grvPaymentSpe.GridControl = this.grdPaymentSpe;
            this.grvPaymentSpe.Name = "grvPaymentSpe";
            this.grvPaymentSpe.OptionsBehavior.Editable = false;
            this.grvPaymentSpe.OptionsBehavior.ReadOnly = true;
            this.grvPaymentSpe.OptionsClipboard.CopyColumnHeaders = DevExpress.Utils.DefaultBoolean.False;
            this.grvPaymentSpe.OptionsPrint.AutoWidth = false;
            this.grvPaymentSpe.OptionsSelection.CheckBoxSelectorColumnWidth = 30;
            this.grvPaymentSpe.OptionsSelection.MultiSelectMode = DevExpress.XtraGrid.Views.Grid.GridMultiSelectMode.CheckBoxRowSelect;
            this.grvPaymentSpe.OptionsView.ColumnAutoWidth = false;
            this.grvPaymentSpe.OptionsView.RowAutoHeight = true;
            this.grvPaymentSpe.OptionsView.ShowFooter = true;
            this.grvPaymentSpe.OptionsView.ShowGroupPanel = false;
            this.grvPaymentSpe.FocusedRowChanged += new DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventHandler(this.grvPaymentSpe_FocusedRowChanged);
            this.grvPaymentSpe.CustomColumnDisplayText += new DevExpress.XtraGrid.Views.Base.CustomColumnDisplayTextEventHandler(this.grvPaymentSpe_CustomColumnDisplayText);
            this.grvPaymentSpe.KeyDown += new System.Windows.Forms.KeyEventHandler(this.grvPaymentSpe_KeyDown);
            this.grvPaymentSpe.DoubleClick += new System.EventHandler(this.grvPaymentSpe_DoubleClick);
            // 
            // colPaymentSpeStt
            // 
            this.colPaymentSpeStt.AppearanceCell.Options.UseTextOptions = true;
            this.colPaymentSpeStt.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colPaymentSpeStt.Caption = "STT";
            this.colPaymentSpeStt.FieldName = "RowNum";
            this.colPaymentSpeStt.Name = "colPaymentSpeStt";
            this.colPaymentSpeStt.Visible = true;
            this.colPaymentSpeStt.VisibleIndex = 0;
            this.colPaymentSpeStt.Width = 58;
            // 
            // colSpeIsUrgent
            // 
            this.colSpeIsUrgent.Caption = "Thanh toán gấp";
            this.colSpeIsUrgent.FieldName = "IsUrgent";
            this.colSpeIsUrgent.Name = "colSpeIsUrgent";
            this.colSpeIsUrgent.Visible = true;
            this.colSpeIsUrgent.VisibleIndex = 1;
            this.colSpeIsUrgent.Width = 68;
            // 
            // colPaymentSpeDateOrder
            // 
            this.colPaymentSpeDateOrder.AppearanceCell.Options.UseTextOptions = true;
            this.colPaymentSpeDateOrder.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colPaymentSpeDateOrder.Caption = "Ngày đề nghị";
            this.colPaymentSpeDateOrder.DisplayFormat.FormatString = "dd/MM/yyyy";
            this.colPaymentSpeDateOrder.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.colPaymentSpeDateOrder.FieldName = "DateOrder";
            this.colPaymentSpeDateOrder.Name = "colPaymentSpeDateOrder";
            this.colPaymentSpeDateOrder.Visible = true;
            this.colPaymentSpeDateOrder.VisibleIndex = 4;
            this.colPaymentSpeDateOrder.Width = 106;
            // 
            // colPaymentSpeCode
            // 
            this.colPaymentSpeCode.Caption = "Số đề nghị";
            this.colPaymentSpeCode.FieldName = "Code";
            this.colPaymentSpeCode.Name = "colPaymentSpeCode";
            this.colPaymentSpeCode.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Count, "Code", "{0}")});
            this.colPaymentSpeCode.Visible = true;
            this.colPaymentSpeCode.VisibleIndex = 5;
            this.colPaymentSpeCode.Width = 149;
            // 
            // colSpeFullName
            // 
            this.colSpeFullName.Caption = "Người đề nghị";
            this.colSpeFullName.FieldName = "FullName";
            this.colSpeFullName.MinWidth = 19;
            this.colSpeFullName.Name = "colSpeFullName";
            this.colSpeFullName.Visible = true;
            this.colSpeFullName.VisibleIndex = 3;
            this.colSpeFullName.Width = 100;
            // 
            // colSpeDeadlinePayment
            // 
            this.colSpeDeadlinePayment.Caption = "Deadline thanh toán";
            this.colSpeDeadlinePayment.FieldName = "DeadlinePayment";
            this.colSpeDeadlinePayment.MinWidth = 19;
            this.colSpeDeadlinePayment.Name = "colSpeDeadlinePayment";
            this.colSpeDeadlinePayment.Visible = true;
            this.colSpeDeadlinePayment.VisibleIndex = 2;
            this.colSpeDeadlinePayment.Width = 97;
            // 
            // colPaymentSpeDepartmentName
            // 
            this.colPaymentSpeDepartmentName.Caption = "Bộ phận ";
            this.colPaymentSpeDepartmentName.ColumnEdit = this.repositoryItemMemoEdit1;
            this.colPaymentSpeDepartmentName.FieldName = "DepartmentName";
            this.colPaymentSpeDepartmentName.Name = "colPaymentSpeDepartmentName";
            this.colPaymentSpeDepartmentName.Visible = true;
            this.colPaymentSpeDepartmentName.VisibleIndex = 6;
            this.colPaymentSpeDepartmentName.Width = 128;
            // 
            // colPaymentSpeTypeOrderText
            // 
            this.colPaymentSpeTypeOrderText.Caption = "Phân loại chính";
            this.colPaymentSpeTypeOrderText.ColumnEdit = this.repositoryItemMemoEdit1;
            this.colPaymentSpeTypeOrderText.FieldName = "TypeOrderText";
            this.colPaymentSpeTypeOrderText.Name = "colPaymentSpeTypeOrderText";
            this.colPaymentSpeTypeOrderText.Visible = true;
            this.colPaymentSpeTypeOrderText.VisibleIndex = 10;
            this.colPaymentSpeTypeOrderText.Width = 128;
            // 
            // colPaymentOrderTypeName
            // 
            this.colPaymentOrderTypeName.Caption = "Nội dung chính của đề nghị";
            this.colPaymentOrderTypeName.ColumnEdit = this.repositoryItemMemoEdit1;
            this.colPaymentOrderTypeName.FieldName = "PaymentOrderTypeName";
            this.colPaymentOrderTypeName.Name = "colPaymentOrderTypeName";
            this.colPaymentOrderTypeName.Visible = true;
            this.colPaymentOrderTypeName.VisibleIndex = 11;
            this.colPaymentOrderTypeName.Width = 212;
            // 
            // colSpeTotalMoney
            // 
            this.colSpeTotalMoney.Caption = "Số tiền";
            this.colSpeTotalMoney.FieldName = "TotalMoney";
            this.colSpeTotalMoney.MinWidth = 19;
            this.colSpeTotalMoney.Name = "colSpeTotalMoney";
            this.colSpeTotalMoney.Visible = true;
            this.colSpeTotalMoney.VisibleIndex = 12;
            this.colSpeTotalMoney.Width = 70;
            // 
            // colSpeUnit
            // 
            this.colSpeUnit.Caption = "ĐVT";
            this.colSpeUnit.FieldName = "Unit";
            this.colSpeUnit.MinWidth = 19;
            this.colSpeUnit.Name = "colSpeUnit";
            this.colSpeUnit.Visible = true;
            this.colSpeUnit.VisibleIndex = 13;
            this.colSpeUnit.Width = 70;
            // 
            // colSpeStepName
            // 
            this.colSpeStepName.Caption = "Tình trạng phiếu";
            this.colSpeStepName.ColumnEdit = this.repositoryItemMemoEdit1;
            this.colSpeStepName.FieldName = "StepName";
            this.colSpeStepName.Name = "colSpeStepName";
            this.colSpeStepName.Visible = true;
            this.colSpeStepName.VisibleIndex = 14;
            this.colSpeStepName.Width = 137;
            // 
            // colSpeContentLog
            // 
            this.colSpeContentLog.Caption = "Lịch sử duyệt / ko duyệt ";
            this.colSpeContentLog.ColumnEdit = this.repositoryItemMemoEdit1;
            this.colSpeContentLog.FieldName = "ContentLog";
            this.colSpeContentLog.Name = "colSpeContentLog";
            this.colSpeContentLog.Visible = true;
            this.colSpeContentLog.VisibleIndex = 15;
            this.colSpeContentLog.Width = 111;
            // 
            // colSpeCustomerName
            // 
            this.colSpeCustomerName.Caption = "Khách hàng";
            this.colSpeCustomerName.FieldName = "CustomerName";
            this.colSpeCustomerName.Name = "colSpeCustomerName";
            this.colSpeCustomerName.Visible = true;
            this.colSpeCustomerName.VisibleIndex = 7;
            this.colSpeCustomerName.Width = 244;
            // 
            // colSpeReasonCancel
            // 
            this.colSpeReasonCancel.Caption = "Lý do huỷ duyệt";
            this.colSpeReasonCancel.ColumnEdit = this.repositoryItemMemoEdit1;
            this.colSpeReasonCancel.FieldName = "ReasonCancel";
            this.colSpeReasonCancel.Name = "colSpeReasonCancel";
            this.colSpeReasonCancel.Visible = true;
            this.colSpeReasonCancel.VisibleIndex = 16;
            this.colSpeReasonCancel.Width = 109;
            // 
            // colSpeNote
            // 
            this.colSpeNote.Caption = "Ghi chú / Chứng từ kèm theo";
            this.colSpeNote.ColumnEdit = this.repositoryItemMemoEdit1;
            this.colSpeNote.FieldName = "Note";
            this.colSpeNote.Name = "colSpeNote";
            this.colSpeNote.Visible = true;
            this.colSpeNote.VisibleIndex = 17;
            this.colSpeNote.Width = 168;
            // 
            // colPaymentSpeId
            // 
            this.colPaymentSpeId.FieldName = "ID";
            this.colPaymentSpeId.Name = "colPaymentSpeId";
            // 
            // colSpePaymentOrderTypeID
            // 
            this.colSpePaymentOrderTypeID.FieldName = "PaymentOrderTypeID";
            this.colSpePaymentOrderTypeID.Name = "colSpePaymentOrderTypeID";
            this.colSpePaymentOrderTypeID.Width = 76;
            // 
            // colSpeStep
            // 
            this.colSpeStep.FieldName = "Step";
            this.colSpeStep.Name = "colSpeStep";
            // 
            // colSpeIsApproved
            // 
            this.colSpeIsApproved.Caption = "IsApproved";
            this.colSpeIsApproved.FieldName = "IsApproved";
            this.colSpeIsApproved.MinWidth = 19;
            this.colSpeIsApproved.Name = "colSpeIsApproved";
            this.colSpeIsApproved.Width = 70;
            // 
            // colTypeDocumentText
            // 
            this.colTypeDocumentText.Caption = "Loại chứng từ";
            this.colTypeDocumentText.FieldName = "TypeDocumentText";
            this.colTypeDocumentText.Name = "colTypeDocumentText";
            this.colTypeDocumentText.Visible = true;
            this.colTypeDocumentText.VisibleIndex = 8;
            this.colTypeDocumentText.Width = 107;
            // 
            // colSpeNumberDocument
            // 
            this.colSpeNumberDocument.Caption = "Số chứng từ";
            this.colSpeNumberDocument.FieldName = "NumberDocument";
            this.colSpeNumberDocument.Name = "colSpeNumberDocument";
            this.colSpeNumberDocument.Visible = true;
            this.colSpeNumberDocument.VisibleIndex = 9;
            this.colSpeNumberDocument.Width = 130;
            // 
            // repositoryItemCheckEdit2
            // 
            this.repositoryItemCheckEdit2.AutoHeight = false;
            this.repositoryItemCheckEdit2.DisplayValueChecked = "x";
            this.repositoryItemCheckEdit2.DisplayValueUnchecked = " ";
            this.repositoryItemCheckEdit2.ExportMode = DevExpress.XtraEditors.Repository.ExportMode.DisplayText;
            this.repositoryItemCheckEdit2.Name = "repositoryItemCheckEdit2";
            this.repositoryItemCheckEdit2.NullStyle = DevExpress.XtraEditors.Controls.StyleIndeterminate.Unchecked;
            // 
            // repositoryItemMemoEdit8
            // 
            this.repositoryItemMemoEdit8.Name = "repositoryItemMemoEdit8";
            // 
            // splitContainerControl4
            // 
            this.splitContainerControl4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainerControl4.FixedPanel = DevExpress.XtraEditors.SplitFixedPanel.None;
            this.splitContainerControl4.Location = new System.Drawing.Point(0, 0);
            this.splitContainerControl4.Margin = new System.Windows.Forms.Padding(2);
            this.splitContainerControl4.Name = "splitContainerControl4";
            // 
            // splitContainerControl4.Panel1
            // 
            this.splitContainerControl4.Panel1.Controls.Add(this.grdSpeDetails);
            this.splitContainerControl4.Panel1.Text = "Panel1";
            // 
            // splitContainerControl4.Panel2
            // 
            this.splitContainerControl4.Panel2.Controls.Add(this.grdSpeFile);
            this.splitContainerControl4.Panel2.Text = "Panel2";
            this.splitContainerControl4.Size = new System.Drawing.Size(1369, 183);
            this.splitContainerControl4.SplitterPosition = 1026;
            this.splitContainerControl4.TabIndex = 0;
            // 
            // grdSpeDetails
            // 
            this.grdSpeDetails.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdSpeDetails.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(2);
            this.grdSpeDetails.Location = new System.Drawing.Point(0, 0);
            this.grdSpeDetails.MainView = this.grvSpeDetails;
            this.grdSpeDetails.Margin = new System.Windows.Forms.Padding(2);
            this.grdSpeDetails.Name = "grdSpeDetails";
            this.grdSpeDetails.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemMemoEdit10});
            this.grdSpeDetails.Size = new System.Drawing.Size(1026, 183);
            this.grdSpeDetails.TabIndex = 0;
            this.grdSpeDetails.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.grvSpeDetails});
            // 
            // grvSpeDetails
            // 
            this.grvSpeDetails.Appearance.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grvSpeDetails.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.grvSpeDetails.Appearance.HeaderPanel.Options.UseFont = true;
            this.grvSpeDetails.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.grvSpeDetails.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.grvSpeDetails.Appearance.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.grvSpeDetails.Appearance.HeaderPanel.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.grvSpeDetails.Appearance.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.grvSpeDetails.Appearance.Row.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grvSpeDetails.Appearance.Row.Options.UseFont = true;
            this.grvSpeDetails.Appearance.Row.Options.UseTextOptions = true;
            this.grvSpeDetails.Appearance.Row.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.grvSpeDetails.Appearance.Row.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.grvSpeDetails.ColumnPanelRowHeight = 50;
            this.grvSpeDetails.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colSpeDetailsSTT,
            this.colSpeDetailsContentPayment,
            this.colSpeDetailsTotalMoney,
            this.colSpeDetailsPaymentMethods,
            this.colSpeDetailsPaymentInfor,
            this.colSpeDetailsEmployeeName,
            this.colSpeDetailsNote});
            this.grvSpeDetails.DetailHeight = 284;
            this.grvSpeDetails.GridControl = this.grdSpeDetails;
            this.grvSpeDetails.Name = "grvSpeDetails";
            this.grvSpeDetails.OptionsBehavior.Editable = false;
            this.grvSpeDetails.OptionsBehavior.ReadOnly = true;
            this.grvSpeDetails.OptionsView.RowAutoHeight = true;
            this.grvSpeDetails.OptionsView.ShowFooter = true;
            this.grvSpeDetails.OptionsView.ShowGroupPanel = false;
            // 
            // colSpeDetailsSTT
            // 
            this.colSpeDetailsSTT.AppearanceCell.Options.UseTextOptions = true;
            this.colSpeDetailsSTT.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colSpeDetailsSTT.Caption = "STT";
            this.colSpeDetailsSTT.FieldName = "Stt";
            this.colSpeDetailsSTT.MinWidth = 19;
            this.colSpeDetailsSTT.Name = "colSpeDetailsSTT";
            this.colSpeDetailsSTT.Visible = true;
            this.colSpeDetailsSTT.VisibleIndex = 0;
            this.colSpeDetailsSTT.Width = 58;
            // 
            // colSpeDetailsContentPayment
            // 
            this.colSpeDetailsContentPayment.Caption = "Đối tượng nhận COM";
            this.colSpeDetailsContentPayment.ColumnEdit = this.repositoryItemMemoEdit10;
            this.colSpeDetailsContentPayment.FieldName = "ContentPayment";
            this.colSpeDetailsContentPayment.MinWidth = 19;
            this.colSpeDetailsContentPayment.Name = "colSpeDetailsContentPayment";
            this.colSpeDetailsContentPayment.Visible = true;
            this.colSpeDetailsContentPayment.VisibleIndex = 1;
            this.colSpeDetailsContentPayment.Width = 166;
            // 
            // repositoryItemMemoEdit10
            // 
            this.repositoryItemMemoEdit10.Name = "repositoryItemMemoEdit10";
            // 
            // colSpeDetailsTotalMoney
            // 
            this.colSpeDetailsTotalMoney.AppearanceCell.Options.UseTextOptions = true;
            this.colSpeDetailsTotalMoney.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.colSpeDetailsTotalMoney.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.colSpeDetailsTotalMoney.Caption = "Số tiền";
            this.colSpeDetailsTotalMoney.DisplayFormat.FormatString = "n2";
            this.colSpeDetailsTotalMoney.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.colSpeDetailsTotalMoney.FieldName = "TotalMoney";
            this.colSpeDetailsTotalMoney.MinWidth = 19;
            this.colSpeDetailsTotalMoney.Name = "colSpeDetailsTotalMoney";
            this.colSpeDetailsTotalMoney.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "TotalMoney", "{0:0.##}")});
            this.colSpeDetailsTotalMoney.Visible = true;
            this.colSpeDetailsTotalMoney.VisibleIndex = 2;
            this.colSpeDetailsTotalMoney.Width = 116;
            // 
            // colSpeDetailsPaymentMethods
            // 
            this.colSpeDetailsPaymentMethods.Caption = "Hình thức thanh toán";
            this.colSpeDetailsPaymentMethods.FieldName = "PaymentMethods";
            this.colSpeDetailsPaymentMethods.MinWidth = 19;
            this.colSpeDetailsPaymentMethods.Name = "colSpeDetailsPaymentMethods";
            this.colSpeDetailsPaymentMethods.Visible = true;
            this.colSpeDetailsPaymentMethods.VisibleIndex = 3;
            this.colSpeDetailsPaymentMethods.Width = 165;
            // 
            // colSpeDetailsPaymentInfor
            // 
            this.colSpeDetailsPaymentInfor.Caption = "Thông tin thanh toán";
            this.colSpeDetailsPaymentInfor.ColumnEdit = this.repositoryItemMemoEdit10;
            this.colSpeDetailsPaymentInfor.FieldName = "PaymentInfor";
            this.colSpeDetailsPaymentInfor.MinWidth = 19;
            this.colSpeDetailsPaymentInfor.Name = "colSpeDetailsPaymentInfor";
            this.colSpeDetailsPaymentInfor.Visible = true;
            this.colSpeDetailsPaymentInfor.VisibleIndex = 4;
            this.colSpeDetailsPaymentInfor.Width = 162;
            // 
            // colSpeDetailsEmployeeName
            // 
            this.colSpeDetailsEmployeeName.Caption = "Team kinh doanh";
            this.colSpeDetailsEmployeeName.ColumnEdit = this.repositoryItemMemoEdit10;
            this.colSpeDetailsEmployeeName.FieldName = "UserTeamName";
            this.colSpeDetailsEmployeeName.MinWidth = 19;
            this.colSpeDetailsEmployeeName.Name = "colSpeDetailsEmployeeName";
            this.colSpeDetailsEmployeeName.Visible = true;
            this.colSpeDetailsEmployeeName.VisibleIndex = 5;
            this.colSpeDetailsEmployeeName.Width = 169;
            // 
            // colSpeDetailsNote
            // 
            this.colSpeDetailsNote.Caption = "Ghi chú / Chứng từ kèm theo";
            this.colSpeDetailsNote.ColumnEdit = this.repositoryItemMemoEdit10;
            this.colSpeDetailsNote.FieldName = "Note";
            this.colSpeDetailsNote.MinWidth = 19;
            this.colSpeDetailsNote.Name = "colSpeDetailsNote";
            this.colSpeDetailsNote.Visible = true;
            this.colSpeDetailsNote.VisibleIndex = 6;
            this.colSpeDetailsNote.Width = 181;
            // 
            // grdSpeFile
            // 
            this.grdSpeFile.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdSpeFile.Location = new System.Drawing.Point(0, 0);
            this.grdSpeFile.MainView = this.grvSpeFile;
            this.grdSpeFile.Name = "grdSpeFile";
            this.grdSpeFile.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemMemoEdit9,
            this.repositoryItemButtonEdit1});
            this.grdSpeFile.Size = new System.Drawing.Size(333, 183);
            this.grdSpeFile.TabIndex = 1;
            this.grdSpeFile.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.grvSpeFile,
            this.gridView7});
            // 
            // grvSpeFile
            // 
            this.grvSpeFile.Appearance.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grvSpeFile.Appearance.HeaderPanel.Options.UseFont = true;
            this.grvSpeFile.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.grvSpeFile.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.grvSpeFile.Appearance.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.grvSpeFile.Appearance.HeaderPanel.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.grvSpeFile.Appearance.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.grvSpeFile.Appearance.Row.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grvSpeFile.Appearance.Row.Options.UseFont = true;
            this.grvSpeFile.Appearance.Row.Options.UseTextOptions = true;
            this.grvSpeFile.Appearance.Row.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.grvSpeFile.Appearance.Row.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.grvSpeFile.ColumnPanelRowHeight = 50;
            this.grvSpeFile.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn6,
            this.gridColumn13,
            this.gridColumn24});
            this.grvSpeFile.GridControl = this.grdSpeFile;
            this.grvSpeFile.Name = "grvSpeFile";
            this.grvSpeFile.OptionsClipboard.CopyColumnHeaders = DevExpress.Utils.DefaultBoolean.False;
            this.grvSpeFile.OptionsSelection.MultiSelect = true;
            this.grvSpeFile.OptionsSelection.MultiSelectMode = DevExpress.XtraGrid.Views.Grid.GridMultiSelectMode.CellSelect;
            this.grvSpeFile.OptionsView.RowAutoHeight = true;
            this.grvSpeFile.OptionsView.ShowGroupPanel = false;
            this.grvSpeFile.DoubleClick += new System.EventHandler(this.grvSpeFile_DoubleClick);
            // 
            // gridColumn6
            // 
            this.gridColumn6.Caption = "File đính kèm";
            this.gridColumn6.ColumnEdit = this.repositoryItemMemoEdit9;
            this.gridColumn6.FieldName = "FileName";
            this.gridColumn6.Name = "gridColumn6";
            this.gridColumn6.OptionsColumn.AllowEdit = false;
            this.gridColumn6.OptionsColumn.ReadOnly = true;
            this.gridColumn6.Visible = true;
            this.gridColumn6.VisibleIndex = 0;
            this.gridColumn6.Width = 381;
            // 
            // repositoryItemMemoEdit9
            // 
            this.repositoryItemMemoEdit9.Name = "repositoryItemMemoEdit9";
            // 
            // gridColumn13
            // 
            this.gridColumn13.FieldName = "ServerPath";
            this.gridColumn13.Name = "gridColumn13";
            // 
            // gridColumn24
            // 
            this.gridColumn24.ColumnEdit = this.repositoryItemButtonEdit1;
            this.gridColumn24.Name = "gridColumn24";
            this.gridColumn24.Width = 37;
            // 
            // repositoryItemButtonEdit1
            // 
            this.repositoryItemButtonEdit1.AutoHeight = false;
            editorButtonImageOptions2.Image = global::Forms.Properties.Resources.download_16x16;
            this.repositoryItemButtonEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Glyph, "", -1, true, true, false, editorButtonImageOptions2, new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject5, serializableAppearanceObject6, serializableAppearanceObject7, serializableAppearanceObject8, "", null, null, DevExpress.Utils.ToolTipAnchor.Default)});
            this.repositoryItemButtonEdit1.Name = "repositoryItemButtonEdit1";
            this.repositoryItemButtonEdit1.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            // 
            // gridView7
            // 
            this.gridView7.DetailHeight = 284;
            this.gridView7.GridControl = this.grdSpeFile;
            this.gridView7.Name = "gridView7";
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnViewAttachFile,
            this.btnDownloadAttachFile});
            this.contextMenuStrip2.Name = "contextMenuStrip2";
            this.contextMenuStrip2.Size = new System.Drawing.Size(118, 48);
            // 
            // btnViewAttachFile
            // 
            this.btnViewAttachFile.Name = "btnViewAttachFile";
            this.btnViewAttachFile.Size = new System.Drawing.Size(117, 22);
            this.btnViewAttachFile.Text = "Xem file";
            this.btnViewAttachFile.Click += new System.EventHandler(this.btnViewAttachFile_Click);
            // 
            // btnDownloadAttachFile
            // 
            this.btnDownloadAttachFile.Name = "btnDownloadAttachFile";
            this.btnDownloadAttachFile.Size = new System.Drawing.Size(117, 22);
            this.btnDownloadAttachFile.Text = "Tải file";
            this.btnDownloadAttachFile.Click += new System.EventHandler(this.btnDownloadAttachFile_Click);
            // 
            // colTotalPaymentActual
            // 
            this.colTotalPaymentActual.AppearanceCell.Options.UseTextOptions = true;
            this.colTotalPaymentActual.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.colTotalPaymentActual.Caption = "Số tiền thành toán thực tế";
            this.colTotalPaymentActual.DisplayFormat.FormatString = "n2";
            this.colTotalPaymentActual.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.colTotalPaymentActual.FieldName = "TotalPaymentActual";
            this.colTotalPaymentActual.Name = "colTotalPaymentActual";
            this.colTotalPaymentActual.Visible = true;
            this.colTotalPaymentActual.VisibleIndex = 13;
            this.colTotalPaymentActual.Width = 115;
            // 
            // frmPaymentOrder
            // 
            this.AcceptButton = this.btnFind;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1393, 705);
            this.Controls.Add(this.xtraTabControl1);
            this.Controls.Add(this.panelControl1);
            this.Controls.Add(this.mnuMenu);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmPaymentOrder";
            this.Text = "ĐỀ NGHỊ THANH TOÁN";
            this.Load += new System.EventHandler(this.frmPaymentOrder_Load);
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit1)).EndInit();
            this.mnuMenu.ResumeLayout(false);
            this.mnuMenu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdData)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grvData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
            this.panelControl1.ResumeLayout(false);
            this.panelControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cboEmployee.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stackPanel1)).EndInit();
            this.stackPanel1.ResumeLayout(false);
            this.stackPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtPageSize)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboPaymentOrderType.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cboDepartment.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.searchLookUpEdit1View)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl1)).EndInit();
            this.xtraTabControl1.ResumeLayout(false);
            this.xtraTabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1.Panel1)).EndInit();
            this.splitContainerControl1.Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1.Panel2)).EndInit();
            this.splitContainerControl1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1)).EndInit();
            this.splitContainerControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl2.Panel1)).EndInit();
            this.splitContainerControl2.Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl2.Panel2)).EndInit();
            this.splitContainerControl2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl2)).EndInit();
            this.splitContainerControl2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.tlDetail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdDataFile)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvDataFile)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDownloadFile)).EndInit();
            this.xtraTabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl3.Panel1)).EndInit();
            this.splitContainerControl3.Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl3.Panel2)).EndInit();
            this.splitContainerControl3.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl3)).EndInit();
            this.splitContainerControl3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdPaymentSpe)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvPaymentSpe)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl4.Panel1)).EndInit();
            this.splitContainerControl4.Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl4.Panel2)).EndInit();
            this.splitContainerControl4.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl4)).EndInit();
            this.splitContainerControl4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdSpeDetails)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvSpeDetails)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdSpeFile)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grvSpeFile)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView7)).EndInit();
            this.contextMenuStrip2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip mnuMenu;
        private System.Windows.Forms.ToolStripButton btnExcel;
        private DevExpress.XtraGrid.GridControl grdData;
        private DevExpress.XtraGrid.Views.Grid.GridView grvData;
        private DevExpress.XtraEditors.PanelControl panelControl1;
        private DevExpress.Utils.Layout.StackPanel stackPanel1;
        private DevExpress.XtraEditors.SimpleButton btnFirst;
        private DevExpress.XtraEditors.SimpleButton btnPrev;
        private System.Windows.Forms.TextBox txtPageNumber;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtTotalPage;
        private DevExpress.XtraEditors.SimpleButton btnNext;
        private DevExpress.XtraEditors.SimpleButton btnLast;
        private System.Windows.Forms.NumericUpDown txtPageSize;
        private System.Windows.Forms.Button btnFind;
        private System.Windows.Forms.TextBox txtKeyword;
        private DevExpress.XtraEditors.SearchLookUpEdit cboPaymentOrderType;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn3;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn4;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit repositoryItemMemoEdit3;
        private DevExpress.XtraEditors.SearchLookUpEdit cboDepartment;
        private DevExpress.XtraGrid.Views.Grid.GridView searchLookUpEdit1View;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit repositoryItemMemoEdit2;
        private System.Windows.Forms.ComboBox cboTypeOrder;
        private System.Windows.Forms.DateTimePicker dtpDateEnd;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dtpDateStart;
        private System.Windows.Forms.Label label1;
        private DevExpress.XtraGrid.Columns.GridColumn colRowNum;
        private DevExpress.XtraGrid.Columns.GridColumn colDateOrder;
        private DevExpress.XtraGrid.Columns.GridColumn colCode;
        private DevExpress.XtraGrid.Columns.GridColumn colFullName;
        private DevExpress.XtraGrid.Columns.GridColumn colDepartmentName;
        private DevExpress.XtraGrid.Columns.GridColumn colTypeOrderText;
        private DevExpress.XtraGrid.Columns.GridColumn colTypeName;
        private DevExpress.XtraGrid.Columns.GridColumn colStepName;
        private DevExpress.XtraGrid.Columns.GridColumn colContentLog;
        private DevExpress.XtraGrid.Columns.GridColumn colReasonCancel;
        private DevExpress.XtraGrid.Columns.GridColumn colNote;
        private System.Windows.Forms.Label label5;
        private DevExpress.XtraEditors.SearchLookUpEdit cboEmployee;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView3;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn7;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn8;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn9;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit repositoryItemMemoEdit4;
        private DevExpress.XtraEditors.SplitContainerControl splitContainerControl1;
        private DevExpress.XtraGrid.Columns.GridColumn colID;
        private DevExpress.XtraTreeList.TreeList tlDetail;
        private DevExpress.XtraTreeList.Columns.TreeListColumn treeListColumn1;
        private DevExpress.XtraTreeList.Columns.TreeListColumn colContentPayment;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit repositoryItemMemoEdit5;
        private DevExpress.XtraTreeList.Columns.TreeListColumn colUnit;
        private DevExpress.XtraTreeList.Columns.TreeListColumn colQuantity;
        private DevExpress.XtraTreeList.Columns.TreeListColumn colUnitPrice;
        private DevExpress.XtraTreeList.Columns.TreeListColumn colTotalMoney;
        private DevExpress.XtraTreeList.Columns.TreeListColumn treeListColumn7;
        private System.Windows.Forms.ToolStripDropDownButton btnTBP;
        private System.Windows.Forms.ToolStripMenuItem btnApproveTBP;
        private System.Windows.Forms.ToolStripMenuItem btnUnApproveTBP;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripDropDownButton btnHR;
        private System.Windows.Forms.ToolStripMenuItem btnApproveHR;
        private System.Windows.Forms.ToolStripMenuItem btnUnApproveHR;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripDropDownButton btnKTTT;
        private System.Windows.Forms.ToolStripMenuItem btnApproveDocument;
        private System.Windows.Forms.ToolStripMenuItem btnUnApproveDocument;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem btnReceiveDocument;
        private System.Windows.Forms.ToolStripMenuItem btnUnReceiveDocument;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem btnIsPayment;
        private System.Windows.Forms.ToolStripMenuItem btnUnPayment;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripDropDownButton btnKTT;
        private System.Windows.Forms.ToolStripMenuItem btnApproveKT;
        private System.Windows.Forms.ToolStripMenuItem btnUnApproveKT;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripDropDownButton btnBGĐ;
        private System.Windows.Forms.ToolStripMenuItem btnApproveBGĐ;
        private System.Windows.Forms.ToolStripMenuItem btnUnApproveBGĐ;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private DevExpress.XtraGrid.Columns.GridColumn colPaymentOrderTypeID;
        private DevExpress.XtraGrid.Columns.GridColumn colStep;
        private DevExpress.XtraGrid.Columns.GridColumn colIsApproved;
        private System.Windows.Forms.ToolStripButton btnTreeFolder;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private DevExpress.XtraEditors.SplitContainerControl splitContainerControl2;
        private DevExpress.XtraGrid.GridControl grdDataFile;
        private DevExpress.XtraGrid.Views.Grid.GridView grvDataFile;
        private DevExpress.XtraGrid.Columns.GridColumn colFileName;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit repositoryItemMemoEdit6;
        private DevExpress.XtraGrid.Columns.GridColumn colServerPath;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem btnTreeFolderContext;
        private System.Windows.Forms.ToolStripMenuItem btnLogPaymentOrder;
        private DevExpress.XtraGrid.Columns.GridColumn ReasonOrder;
        private DevExpress.XtraGrid.Columns.GridColumn colTotalMoneyPayment;
        private DevExpress.XtraGrid.Columns.GridColumn colTypeBankTransferText;
        private DevExpress.XtraGrid.Columns.GridColumn colContentBankTransfer;
        private DevExpress.XtraGrid.Columns.GridColumn colUnitPayment;
        private DevExpress.XtraGrid.Columns.GridColumn colAccountingNote;
        private System.Windows.Forms.ToolStripMenuItem btnApproveDocumentHR;
        private System.Windows.Forms.ToolStripMenuItem btnUnApproveDocumentHR;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn5;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit btnDownloadFile;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private System.Windows.Forms.ToolStripMenuItem btnViewAttachFile;
        private System.Windows.Forms.ToolStripMenuItem btnDownloadAttachFile;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit repositoryItemMemoEdit1;
        private DevExpress.XtraGrid.Columns.GridColumn colIsUrgent;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit1;
        private DevExpress.XtraGrid.Columns.GridColumn colDeadlinePayment;
        private DevExpress.XtraGrid.Columns.GridColumn colSuplierName;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit repositoryItemMemoEdit7;
        private DevExpress.XtraGrid.Columns.GridColumn colPOCode;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ToolStripMenuItem btnUpdateDocument;
        private System.Windows.Forms.ComboBox cboIsApproved;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ToolStripMenuItem btnCopyPaymentOrder;
        private DevExpress.XtraGrid.Columns.GridColumn colTotalPayment;
        private DevExpress.XtraTab.XtraTabControl xtraTabControl1;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage2;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage1;
        private DevExpress.XtraEditors.SplitContainerControl splitContainerControl3;
        private DevExpress.XtraGrid.GridControl grdPaymentSpe;
        private DevExpress.XtraGrid.Views.Grid.GridView grvPaymentSpe;
        private DevExpress.XtraGrid.Columns.GridColumn colPaymentSpeStt;
        private DevExpress.XtraGrid.Columns.GridColumn colPaymentSpeDateOrder;
        private DevExpress.XtraGrid.Columns.GridColumn colPaymentSpeCode;
        private DevExpress.XtraGrid.Columns.GridColumn colSpeFullName;
        private DevExpress.XtraGrid.Columns.GridColumn colSpeDeadlinePayment;
        private DevExpress.XtraGrid.Columns.GridColumn colPaymentSpeDepartmentName;
        private DevExpress.XtraGrid.Columns.GridColumn colPaymentSpeTypeOrderText;
        private DevExpress.XtraGrid.Columns.GridColumn colPaymentOrderTypeName;
        private DevExpress.XtraGrid.Columns.GridColumn colSpeTotalMoney;
        private DevExpress.XtraGrid.Columns.GridColumn colSpeUnit;
        private DevExpress.XtraGrid.Columns.GridColumn colSpeStepName;
        private DevExpress.XtraGrid.Columns.GridColumn colSpeContentLog;
        private DevExpress.XtraGrid.Columns.GridColumn colSpeReasonCancel;
        private DevExpress.XtraGrid.Columns.GridColumn colSpeNote;
        private DevExpress.XtraGrid.Columns.GridColumn colPaymentSpeId;
        private DevExpress.XtraGrid.Columns.GridColumn colSpePaymentOrderTypeID;
        private DevExpress.XtraGrid.Columns.GridColumn colSpeStep;
        private DevExpress.XtraGrid.Columns.GridColumn colSpeIsApproved;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit2;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit repositoryItemMemoEdit8;
        private DevExpress.XtraEditors.SplitContainerControl splitContainerControl4;
        private DevExpress.XtraGrid.GridControl grdSpeDetails;
        private DevExpress.XtraGrid.Views.Grid.GridView grvSpeDetails;
        private DevExpress.XtraGrid.Columns.GridColumn colSpeDetailsSTT;
        private DevExpress.XtraGrid.Columns.GridColumn colSpeDetailsContentPayment;
        private DevExpress.XtraGrid.Columns.GridColumn colSpeDetailsTotalMoney;
        private DevExpress.XtraGrid.Columns.GridColumn colSpeDetailsPaymentMethods;
        private DevExpress.XtraGrid.Columns.GridColumn colSpeDetailsPaymentInfor;
        private DevExpress.XtraGrid.Columns.GridColumn colSpeDetailsEmployeeName;
        private DevExpress.XtraGrid.Columns.GridColumn colSpeDetailsNote;
        private DevExpress.XtraGrid.GridControl grdSpeFile;
        private DevExpress.XtraGrid.Views.Grid.GridView grvSpeFile;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn6;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit repositoryItemMemoEdit9;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn13;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn24;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemButtonEdit1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView7;
        private System.Windows.Forms.ToolStripButton btnAdd;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator12;
        private System.Windows.Forms.ToolStripButton btnEdit;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator11;
        private System.Windows.Forms.ToolStripButton btnDelete;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator10;
        private System.Windows.Forms.ToolStripButton btnCopy;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator13;
        private DevExpress.XtraGrid.Columns.GridColumn colSpeIsUrgent;
        private DevExpress.XtraGrid.Columns.GridColumn colSpeCustomerName;
        private DevExpress.XtraGrid.Columns.GridColumn colTypeDocumentText;
        private DevExpress.XtraGrid.Columns.GridColumn colSpeNumberDocument;
        private DevExpress.XtraGrid.Columns.GridColumn colIsIgnoreHR;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator15;
        private System.Windows.Forms.ToolStripButton btnApproveTBP_New;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator14;
        private System.Windows.Forms.ToolStripButton btnUnApproveTBP_New;
        private DevExpress.XtraGrid.Columns.GridColumn colProjectFullName;
        private DevExpress.XtraGrid.Columns.GridColumn colStepNew;
        private DevExpress.XtraTreeList.Columns.TreeListColumn colPaymentPercentage;
        private DevExpress.XtraTreeList.Columns.TreeListColumn colTotalPaymentAmount;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit repositoryItemMemoEdit10;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator16;
        private System.Windows.Forms.ToolStripMenuItem btnHRUpdateDocument;
        private System.Windows.Forms.ToolStripMenuItem btnExportExcels;
        private DevExpress.XtraGrid.Columns.GridColumn colTotalPaymentActual;
    }
}