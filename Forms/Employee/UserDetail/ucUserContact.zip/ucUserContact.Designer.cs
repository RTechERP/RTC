﻿
namespace Forms.Employee
{
    partial class ucUserContact
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtNoiCap = new System.Windows.Forms.TextBox();
            this.txtSoCMNDorCCCD = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtDcThuongTru = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtDcTamTru = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.gbThongTinLienHe = new DevExpress.XtraEditors.GroupControl();
            this.label12 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtSDTNguoiThan = new System.Windows.Forms.TextBox();
            this.txtMoiQuanHe = new System.Windows.Forms.TextBox();
            this.txtSDTCaNhan = new System.Windows.Forms.TextBox();
            this.txtEmailCaNhan = new System.Windows.Forms.TextBox();
            this.txtSDTCongTy = new System.Windows.Forms.TextBox();
            this.txtEmailCongTy = new System.Windows.Forms.TextBox();
            this.txtHoTenNguoiLienHe = new System.Windows.Forms.TextBox();
            this.gbCMNDorCCCD = new DevExpress.XtraEditors.GroupControl();
            this.dtpNgayCap = new DevExpress.XtraEditors.DateEdit();
            this.gbDiaChi = new DevExpress.XtraEditors.GroupControl();
            this.tablePanel1 = new DevExpress.Utils.Layout.TablePanel();
            ((System.ComponentModel.ISupportInitialize)(this.gbThongTinLienHe)).BeginInit();
            this.gbThongTinLienHe.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gbCMNDorCCCD)).BeginInit();
            this.gbCMNDorCCCD.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtpNgayCap.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtpNgayCap.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gbDiaChi)).BeginInit();
            this.gbDiaChi.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tablePanel1)).BeginInit();
            this.tablePanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtNoiCap
            // 
            this.txtNoiCap.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtNoiCap.Location = new System.Drawing.Point(131, 79);
            this.txtNoiCap.Name = "txtNoiCap";
            this.txtNoiCap.Size = new System.Drawing.Size(394, 21);
            this.txtNoiCap.TabIndex = 3;
            // 
            // txtSoCMNDorCCCD
            // 
            this.txtSoCMNDorCCCD.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtSoCMNDorCCCD.Location = new System.Drawing.Point(131, 26);
            this.txtSoCMNDorCCCD.Name = "txtSoCMNDorCCCD";
            this.txtSoCMNDorCCCD.Size = new System.Drawing.Size(394, 21);
            this.txtSoCMNDorCCCD.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 83);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Nơi cấp";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Ngày cấp";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(19, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Số";
            // 
            // txtDcThuongTru
            // 
            this.txtDcThuongTru.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtDcThuongTru.Location = new System.Drawing.Point(131, 26);
            this.txtDcThuongTru.Multiline = true;
            this.txtDcThuongTru.Name = "txtDcThuongTru";
            this.txtDcThuongTru.Size = new System.Drawing.Size(394, 40);
            this.txtDcThuongTru.TabIndex = 4;
            this.txtDcThuongTru.TextChanged += new System.EventHandler(this.txtDcThuongTru_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(7, 73);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(64, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Đ/c Tạm trú";
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(7, 31);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(81, 30);
            this.label6.TabIndex = 0;
            this.label6.Text = "Đ/c Thường trú (Theo Sổ HK)";
            // 
            // txtDcTamTru
            // 
            this.txtDcTamTru.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtDcTamTru.Location = new System.Drawing.Point(131, 73);
            this.txtDcTamTru.Multiline = true;
            this.txtDcTamTru.Name = "txtDcTamTru";
            this.txtDcTamTru.Size = new System.Drawing.Size(394, 40);
            this.txtDcTamTru.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 86);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(118, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "(Đ/c hiện tại sinh sống)";
            // 
            // gbThongTinLienHe
            // 
            this.tablePanel1.SetColumn(this.gbThongTinLienHe, 1);
            this.gbThongTinLienHe.Controls.Add(this.label12);
            this.gbThongTinLienHe.Controls.Add(this.label14);
            this.gbThongTinLienHe.Controls.Add(this.label13);
            this.gbThongTinLienHe.Controls.Add(this.label11);
            this.gbThongTinLienHe.Controls.Add(this.label10);
            this.gbThongTinLienHe.Controls.Add(this.label9);
            this.gbThongTinLienHe.Controls.Add(this.label8);
            this.gbThongTinLienHe.Controls.Add(this.txtSDTNguoiThan);
            this.gbThongTinLienHe.Controls.Add(this.txtMoiQuanHe);
            this.gbThongTinLienHe.Controls.Add(this.txtSDTCaNhan);
            this.gbThongTinLienHe.Controls.Add(this.txtEmailCaNhan);
            this.gbThongTinLienHe.Controls.Add(this.txtSDTCongTy);
            this.gbThongTinLienHe.Controls.Add(this.txtEmailCongTy);
            this.gbThongTinLienHe.Controls.Add(this.txtHoTenNguoiLienHe);
            this.gbThongTinLienHe.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gbThongTinLienHe.Location = new System.Drawing.Point(539, 3);
            this.gbThongTinLienHe.Name = "gbThongTinLienHe";
            this.tablePanel1.SetRow(this.gbThongTinLienHe, 0);
            this.tablePanel1.SetRowSpan(this.gbThongTinLienHe, 2);
            this.gbThongTinLienHe.Size = new System.Drawing.Size(530, 308);
            this.gbThongTinLienHe.TabIndex = 1;
            this.gbThongTinLienHe.Text = "THÔNG TIN LIÊN HỆ";
            // 
            // label12
            // 
            this.label12.Location = new System.Drawing.Point(5, 128);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(106, 32);
            this.label12.TabIndex = 0;
            this.label12.Text = "Họ và tên người thân liên hệ khi cần";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(5, 192);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(102, 13);
            this.label14.TabIndex = 0;
            this.label14.Text = "SĐT của người thân";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(5, 165);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(65, 13);
            this.label13.TabIndex = 0;
            this.label13.Text = "Mối quan hệ";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(5, 111);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(92, 13);
            this.label11.TabIndex = 0;
            this.label11.Text = "Email Công ty cấp";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(5, 84);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(88, 13);
            this.label10.TabIndex = 0;
            this.label10.Text = "SĐT Công ty cấp";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(5, 57);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(72, 13);
            this.label9.TabIndex = 0;
            this.label9.Text = "Email cá nhân";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(5, 30);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(68, 13);
            this.label8.TabIndex = 0;
            this.label8.Text = "SĐT cá nhân";
            // 
            // txtSDTNguoiThan
            // 
            this.txtSDTNguoiThan.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtSDTNguoiThan.Location = new System.Drawing.Point(117, 188);
            this.txtSDTNguoiThan.Name = "txtSDTNguoiThan";
            this.txtSDTNguoiThan.Size = new System.Drawing.Size(408, 21);
            this.txtSDTNguoiThan.TabIndex = 12;
            // 
            // txtMoiQuanHe
            // 
            this.txtMoiQuanHe.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtMoiQuanHe.Location = new System.Drawing.Point(117, 161);
            this.txtMoiQuanHe.Name = "txtMoiQuanHe";
            this.txtMoiQuanHe.Size = new System.Drawing.Size(408, 21);
            this.txtMoiQuanHe.TabIndex = 11;
            // 
            // txtSDTCaNhan
            // 
            this.txtSDTCaNhan.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtSDTCaNhan.Location = new System.Drawing.Point(117, 26);
            this.txtSDTCaNhan.Name = "txtSDTCaNhan";
            this.txtSDTCaNhan.Size = new System.Drawing.Size(408, 21);
            this.txtSDTCaNhan.TabIndex = 6;
            this.txtSDTCaNhan.TextChanged += new System.EventHandler(this.txtSDTCongTy_TextChanged);
            // 
            // txtEmailCaNhan
            // 
            this.txtEmailCaNhan.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtEmailCaNhan.Location = new System.Drawing.Point(117, 53);
            this.txtEmailCaNhan.Name = "txtEmailCaNhan";
            this.txtEmailCaNhan.Size = new System.Drawing.Size(408, 21);
            this.txtEmailCaNhan.TabIndex = 7;
            this.txtEmailCaNhan.TextChanged += new System.EventHandler(this.txtSDTCongTy_TextChanged);
            // 
            // txtSDTCongTy
            // 
            this.txtSDTCongTy.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtSDTCongTy.Location = new System.Drawing.Point(117, 80);
            this.txtSDTCongTy.Name = "txtSDTCongTy";
            this.txtSDTCongTy.Size = new System.Drawing.Size(408, 21);
            this.txtSDTCongTy.TabIndex = 8;
            this.txtSDTCongTy.TextChanged += new System.EventHandler(this.txtSDTCongTy_TextChanged);
            // 
            // txtEmailCongTy
            // 
            this.txtEmailCongTy.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtEmailCongTy.Location = new System.Drawing.Point(117, 107);
            this.txtEmailCongTy.Name = "txtEmailCongTy";
            this.txtEmailCongTy.Size = new System.Drawing.Size(408, 21);
            this.txtEmailCongTy.TabIndex = 9;
            // 
            // txtHoTenNguoiLienHe
            // 
            this.txtHoTenNguoiLienHe.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtHoTenNguoiLienHe.Location = new System.Drawing.Point(117, 134);
            this.txtHoTenNguoiLienHe.Name = "txtHoTenNguoiLienHe";
            this.txtHoTenNguoiLienHe.Size = new System.Drawing.Size(408, 21);
            this.txtHoTenNguoiLienHe.TabIndex = 10;
            // 
            // gbCMNDorCCCD
            // 
            this.tablePanel1.SetColumn(this.gbCMNDorCCCD, 0);
            this.gbCMNDorCCCD.Controls.Add(this.dtpNgayCap);
            this.gbCMNDorCCCD.Controls.Add(this.txtSoCMNDorCCCD);
            this.gbCMNDorCCCD.Controls.Add(this.txtNoiCap);
            this.gbCMNDorCCCD.Controls.Add(this.label1);
            this.gbCMNDorCCCD.Controls.Add(this.label2);
            this.gbCMNDorCCCD.Controls.Add(this.label3);
            this.gbCMNDorCCCD.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gbCMNDorCCCD.Location = new System.Drawing.Point(3, 3);
            this.gbCMNDorCCCD.Name = "gbCMNDorCCCD";
            this.tablePanel1.SetRow(this.gbCMNDorCCCD, 0);
            this.gbCMNDorCCCD.Size = new System.Drawing.Size(530, 170);
            this.gbCMNDorCCCD.TabIndex = 3;
            this.gbCMNDorCCCD.Text = "CMND/CCCD";
            // 
            // dtpNgayCap
            // 
            this.dtpNgayCap.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dtpNgayCap.EditValue = null;
            this.dtpNgayCap.Location = new System.Drawing.Point(131, 53);
            this.dtpNgayCap.Name = "dtpNgayCap";
            this.dtpNgayCap.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dtpNgayCap.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dtpNgayCap.Size = new System.Drawing.Size(394, 20);
            this.dtpNgayCap.TabIndex = 2;
            // 
            // gbDiaChi
            // 
            this.tablePanel1.SetColumn(this.gbDiaChi, 0);
            this.gbDiaChi.Controls.Add(this.txtDcTamTru);
            this.gbDiaChi.Controls.Add(this.label4);
            this.gbDiaChi.Controls.Add(this.txtDcThuongTru);
            this.gbDiaChi.Controls.Add(this.label5);
            this.gbDiaChi.Controls.Add(this.label6);
            this.gbDiaChi.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gbDiaChi.Location = new System.Drawing.Point(3, 179);
            this.gbDiaChi.Name = "gbDiaChi";
            this.tablePanel1.SetRow(this.gbDiaChi, 1);
            this.gbDiaChi.Size = new System.Drawing.Size(530, 132);
            this.gbDiaChi.TabIndex = 4;
            this.gbDiaChi.Text = "ĐỊA CHỈ";
            // 
            // tablePanel1
            // 
            this.tablePanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tablePanel1.Columns.AddRange(new DevExpress.Utils.Layout.TablePanelColumn[] {
            new DevExpress.Utils.Layout.TablePanelColumn(DevExpress.Utils.Layout.TablePanelEntityStyle.Relative, 50F),
            new DevExpress.Utils.Layout.TablePanelColumn(DevExpress.Utils.Layout.TablePanelEntityStyle.Relative, 50F)});
            this.tablePanel1.Controls.Add(this.gbCMNDorCCCD);
            this.tablePanel1.Controls.Add(this.gbThongTinLienHe);
            this.tablePanel1.Controls.Add(this.gbDiaChi);
            this.tablePanel1.Location = new System.Drawing.Point(3, 3);
            this.tablePanel1.Name = "tablePanel1";
            this.tablePanel1.Rows.AddRange(new DevExpress.Utils.Layout.TablePanelRow[] {
            new DevExpress.Utils.Layout.TablePanelRow(DevExpress.Utils.Layout.TablePanelEntityStyle.Absolute, 176F),
            new DevExpress.Utils.Layout.TablePanelRow(DevExpress.Utils.Layout.TablePanelEntityStyle.Absolute, 26F)});
            this.tablePanel1.Size = new System.Drawing.Size(1071, 314);
            this.tablePanel1.TabIndex = 5;
            // 
            // ucUserContact
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.Controls.Add(this.tablePanel1);
            this.Name = "ucUserContact";
            this.Size = new System.Drawing.Size(1077, 320);
            this.Load += new System.EventHandler(this.ucUserContact_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gbThongTinLienHe)).EndInit();
            this.gbThongTinLienHe.ResumeLayout(false);
            this.gbThongTinLienHe.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gbCMNDorCCCD)).EndInit();
            this.gbCMNDorCCCD.ResumeLayout(false);
            this.gbCMNDorCCCD.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtpNgayCap.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtpNgayCap.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gbDiaChi)).EndInit();
            this.gbDiaChi.ResumeLayout(false);
            this.gbDiaChi.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tablePanel1)).EndInit();
            this.tablePanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private DevExpress.XtraEditors.DateEdit dtpNgayCap;
        private System.Windows.Forms.TextBox txtNoiCap;
        private System.Windows.Forms.TextBox txtSoCMNDorCCCD;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtDcThuongTru;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtDcTamTru;
        private System.Windows.Forms.Label label4;
        private DevExpress.XtraEditors.GroupControl gbThongTinLienHe;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtSDTNguoiThan;
        private System.Windows.Forms.TextBox txtMoiQuanHe;
        private System.Windows.Forms.TextBox txtSDTCongTy;
        private System.Windows.Forms.TextBox txtEmailCongTy;
        private System.Windows.Forms.TextBox txtHoTenNguoiLienHe;
        private System.Windows.Forms.TextBox txtSDTCaNhan;
        private System.Windows.Forms.TextBox txtEmailCaNhan;
        private DevExpress.XtraEditors.GroupControl gbCMNDorCCCD;
        private DevExpress.XtraEditors.GroupControl gbDiaChi;
        private DevExpress.Utils.Layout.TablePanel tablePanel1;
    }
}
