﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Forms.Employee
{
    public partial class ucUserContact : UserControl
    {
        public ucUserContact()
        {
            InitializeComponent();
        }

        private void ucUserContact_Load(object sender, EventArgs e)
        {

        }

        private void txtSDTCongTy_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtDcThuongTru_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
