﻿using BMS.Business;
using BMS.Model;
using ExcelDataReader;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace BMS
{
    public partial class frmFollowProjectBaseDetail : _Forms
    {
        public FollowProjectBaseModel followProjectBase = new FollowProjectBaseModel();
        public ProjectModel project = new ProjectModel();
        public frmFollowProjectBaseDetail()
        {
            InitializeComponent();
        }
        /// <summary>
        /// load dữ liệu lên khi load form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void frmFollowProjectBaseDetail_Load(object sender, EventArgs e)
        {
           // cbUser.EditValue = Global.UserID;

            // phân quyền admin
            //DataTable dt = TextUtils.Select($"Select * From [GroupSalesUser] WHERE UserID = {cbUser.EditValue} AND (SaleUserTypeID = 1 OR SaleUserTypeID = 6 OR SaleUserTypeID = 7 OR SaleUserTypeID = 8)");
            //if (dt.Rows.Count > 0) cbUser.Enabled = true;
            //else cbUser.Enabled = false;

            loadProject();
            loadCustomer();
            loadUser();
            loadProjectStatus();
            loadProjectTypeBase();
            loadFirmBase();
            LoadPM();
            loadFollowProjectBaseDetail();
        }

        #region Methods
        /// <summary>
        /// load dự án
        /// </summary>
        /// 
        private void loadProject()
        {
            DataTable dt = TextUtils.Select("SELECT *,ProjectCode +'_'+ProjectName as ProjectFullName FROM Project");
            cbProject.Properties.DisplayMember = "ProjectFullName";
            cbProject.Properties.ValueMember = "ID";
            cbProject.Properties.DataSource = dt;

            //cboEndUser.Properties.DisplayMember = "ProjectName";
            //cboEndUser.Properties.ValueMember = "ID";
            //cboEndUser.Properties.DataSource = dt;
        }


        void LoadPM()
        {
            DataTable dt = TextUtils.GetTable("spGetEmployeeForProject");
            cboPM.Properties.DataSource = dt;
            cboPM.Properties.DisplayMember = "FullName";
            cboPM.Properties.ValueMember = "EmployeeID";
        }

        /// <summary>
        /// load khách hàng
        /// </summary>
        private void loadCustomer()
        {
            DataTable dt = TextUtils.Select("SELECT * FROM Customer");
            cbCustomer.Properties.DisplayMember = cboEndUser.Properties.DisplayMember = "CustomerName";
            cbCustomer.Properties.ValueMember = cboEndUser.Properties.ValueMember = "ID";
            cbCustomer.Properties.DataSource = cboEndUser.Properties.DataSource = dt;
        }

        /// <summary>
        /// load sale phụ trách
        /// </summary>
        private void loadUser()
        {
            DataTable dt = TextUtils.Select("SELECT * FROM Users");
            cbUser.Properties.DisplayMember = "FullName";
            cbUser.Properties.ValueMember = "ID";
            cbUser.Properties.DataSource = dt;
        }

        /// <summary>
        /// load trạng thái 
        /// </summary>
        private void loadProjectStatus()
        {
            DataTable dt = TextUtils.Select("SELECT * FROM ProjectStatus");
            cbProjectStatus.Properties.DisplayMember = "StatusName";
            cbProjectStatus.Properties.ValueMember = "ID";
            cbProjectStatus.Properties.DataSource = dt;
        }

        /// <summary>
        /// load hãng
        /// </summary>
        private void loadFirmBase()
        {
            DataTable dt = TextUtils.Select("SELECT * FROM FirmBase");
            cbFirmBase.Properties.DisplayMember = "FirmName";
            cbFirmBase.Properties.ValueMember = "ID";
            cbFirmBase.Properties.DataSource = dt;
        }

        /// <summary>
        /// load trạng thái 
        /// </summary>
        private void loadProjectTypeBase()
        {
            DataTable dt = TextUtils.Select("SELECT * FROM ProjectTypeBase");
            cbProjectTypeBase.Properties.DisplayMember = "ProjectTypeName";
            cbProjectTypeBase.Properties.ValueMember = "ID";
            cbProjectTypeBase.Properties.DataSource = dt;
        }

        private void loadFollowProjectBaseDetail()
        {
            if (followProjectBase.ID > 0)
            {
                //follow
                cbProject.EditValue = followProjectBase.ProjectID;
               // cbUser.EditValue = project.UserID;
                cbProjectStatus.EditValue = followProjectBase.ProjectStatusBaseID;
                cbCustomer.EditValue = followProjectBase.CustomerBaseID;
                cbFirmBase.EditValue = followProjectBase.FirmBaseID;
                cbProjectTypeBase.EditValue = followProjectBase.ProjectTypeBaseID;
                cboEndUser.EditValue = followProjectBase.EndUserID;

                txtProjectStartDate.EditValue = TextUtils.ToDate4(followProjectBase.ProjectStartDate);
                txtImplementationDate.EditValue = TextUtils.ToDate4(followProjectBase.ImplementationDate);
                txtExpectedDate.EditValue = TextUtils.ToDate4(followProjectBase.ExpectedDate);
                txtWorkDone.Text = followProjectBase.WorkDone;
                txtWorkWillDo.Text = followProjectBase.WorkWillDo;
                txtPossibilityPO.Text = followProjectBase.PossibilityPO;
                // dự kiến
                txtExpectedPlanDate.EditValue = TextUtils.ToDate4(followProjectBase.ExpectedPlanDate);
                txtExpectedQuotationDate.EditValue = TextUtils.ToDate4(followProjectBase.ExpectedQuotationDate);
                txtExpectedPODate.EditValue = TextUtils.ToDate4(followProjectBase.ExpectedPODate);
                txtExpectedProjectEndDate.EditValue = TextUtils.ToDate4(followProjectBase.ExpectedProjectEndDate);
                // thực tế
                txtRealityPlanDate.EditValue = TextUtils.ToDate4(followProjectBase.RealityPlanDate);
                txtRealityQuotationDate.EditValue = TextUtils.ToDate4(followProjectBase.RealityQuotationDate);
                txtRealityPODate.EditValue = TextUtils.ToDate4(followProjectBase.RealityPODate);
                txtRealityProjectEndDate.EditValue = TextUtils.ToDate4(followProjectBase.RealityProjectEndDate);
                //follow 
                txtTotalWithoutVAT.Text = TextUtils.ToString(followProjectBase.TotalWithoutVAT);
                txtProjectContactName.Text = followProjectBase.ProjectContactName;
                txtNote.Text = followProjectBase.Note;

                //PM
                dtpDateDonePM.EditValue = followProjectBase.DateDonePM;
                dtpDateWillDoPM.EditValue = followProjectBase.DateWillDoPM;
                txtWorkDonePM.Text = followProjectBase.WorkDonePM;
                txtWorkWillDoPM.Text = followProjectBase.WorkWillDoPM;
            }
        }
        #endregion
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (saveData()) this.DialogResult = DialogResult.OK;
        }
        bool saveData()
        {
            
            if (!ValidateForm()) return false;
            try
            {
                followProjectBase.ProjectID = TextUtils.ToInt(cbProject.EditValue);
                followProjectBase.UserID = TextUtils.ToInt(cbUser.EditValue);
                followProjectBase.ProjectStatusBaseID = TextUtils.ToInt(cbProjectStatus.EditValue);

       
                //project.ProjectStatus = TextUtils.ToInt(cbProjectStatus.EditValue);

                followProjectBase.CustomerBaseID = TextUtils.ToInt(cbCustomer.EditValue);
                followProjectBase.FirmBaseID = TextUtils.ToInt(cbFirmBase.EditValue);
                followProjectBase.ProjectTypeBaseID = TextUtils.ToInt(cbProjectTypeBase.EditValue);
                followProjectBase.EndUserID = TextUtils.ToInt(cboEndUser.EditValue);
                followProjectBase.ProjectStartDate = TextUtils.ToDate4(txtProjectStartDate.EditValue);
               
                followProjectBase.ImplementationDate = TextUtils.ToDate4(txtImplementationDate.EditValue);
                followProjectBase.ExpectedDate = TextUtils.ToDate4(txtExpectedDate.EditValue);

                followProjectBase.WorkDone = txtWorkDone.Text.Trim();
                followProjectBase.WorkWillDo = txtWorkWillDo.Text.Trim();
                followProjectBase.PossibilityPO = txtPossibilityPO.Text.Trim();

                // dự kiến
                followProjectBase.ExpectedPlanDate = TextUtils.ToDate4(txtExpectedPlanDate.EditValue);
                followProjectBase.ExpectedQuotationDate = TextUtils.ToDate4(txtExpectedQuotationDate.EditValue);
                followProjectBase.ExpectedPODate = TextUtils.ToDate4(txtExpectedPODate.EditValue);
                followProjectBase.ExpectedProjectEndDate = TextUtils.ToDate4(txtExpectedProjectEndDate.EditValue);

                // thực tế
                followProjectBase.RealityPlanDate = TextUtils.ToDate4(txtRealityPlanDate.EditValue);
                followProjectBase.RealityQuotationDate = TextUtils.ToDate4(txtRealityQuotationDate.EditValue);
                followProjectBase.RealityPODate = TextUtils.ToDate4(txtRealityPODate.EditValue);
                followProjectBase.RealityProjectEndDate = TextUtils.ToDate4(txtRealityProjectEndDate.EditValue);

                //follow 
                followProjectBase.TotalWithoutVAT = TextUtils.ToDecimal(txtTotalWithoutVAT.Text.Trim());
                followProjectBase.ProjectContactName = txtProjectContactName.Text.Trim();
                followProjectBase.Note = txtNote.Text.Trim();

                //PM Báo cáo
                followProjectBase.DateDonePM = TextUtils.ToDate4(dtpDateDonePM.EditValue);
                followProjectBase.DateWillDoPM = TextUtils.ToDate4(dtpDateWillDoPM.EditValue);
                followProjectBase.WorkDonePM = txtWorkDonePM.Text.Trim();
                followProjectBase.WorkWillDoPM = txtWorkWillDoPM.Text.Trim();

                project.ID = TextUtils.ToInt(cbProject.EditValue);
                if (project.ID == followProjectBase.ProjectID)
                {
                    string updateQuery = $"UPDATE Project SET ProjectStatus = {followProjectBase.ProjectStatusBaseID} WHERE ID = {project.ID}";
                    TextUtils.ExcuteSQL(updateQuery);
                    project.ProjectStatus = followProjectBase.ProjectStatusBaseID;
                }
                if (followProjectBase.ID > 0)
                {
                  
                    ProjectTypeBaseBO.Instance.Update(followProjectBase);
         
                    MessageBox.Show("Cập nhật thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    ProjectTypeBaseBO.Instance.Insert(followProjectBase);
             
                    MessageBox.Show("Thêm mới thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Lỗi Update vị trí", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            return true;
        }

        private void btnSaveNew_Click(object sender, EventArgs e)
        {
            saveData();
            cbProject.Text = "";
            cbUser.Text = "";
            cbProjectStatus.Text = "";
            cbCustomer.Text = "";
            cbFirmBase.Text = "";
            cbProjectTypeBase.Text = "";
            txtProjectStartDate.Text = "";
            txtImplementationDate.Text = "";
            txtExpectedDate.Text = "";
            txtWorkDone.Clear();
            txtWorkWillDo.Clear();
            txtPossibilityPO.Clear();

            txtExpectedPlanDate.Text = "";
            txtExpectedQuotationDate.Text = "";
            txtExpectedPODate.Text = "";
            txtExpectedProjectEndDate.Text = "";

            txtRealityPlanDate.Text = "";
            txtRealityQuotationDate.Text = "";
            txtRealityPODate.Text = "";
            txtRealityProjectEndDate.Text = "";

            txtTotalWithoutVAT.Clear();
            txtProjectContactName.Clear();
            txtNote.Clear();
            followProjectBase = new FollowProjectBaseModel();
        }

        private void frmFirmDetail_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.DialogResult = DialogResult.OK;
        }

        /// <summary>
        /// check lỗi
        /// </summary>
        /// <returns></returns>
        /// 

        bool ValidateForm()
        {
            if (string.IsNullOrEmpty(cbProject.Text))
            {
                MessageBox.Show("Vui lòng chọn dự án!", TextUtils.Caption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }

            if (string.IsNullOrEmpty(cbUser.Text))
            {
                MessageBox.Show("Vui lòng chọn người dùng!", TextUtils.Caption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }

            if (string.IsNullOrEmpty(cbProjectStatus.Text))
            {
                MessageBox.Show("Vui lòng chọn trạng thái dự án!", TextUtils.Caption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }

            if (string.IsNullOrEmpty(cbCustomer.Text))
            {
                MessageBox.Show("Vui lòng chọn khách hàng!", TextUtils.Caption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }

            if (string.IsNullOrEmpty(cbFirmBase.Text))
            {
                MessageBox.Show("Vui lòng chọn hãng!", TextUtils.Caption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }

            if (string.IsNullOrEmpty(cbProjectTypeBase.Text))
            {
                MessageBox.Show("Vui lòng chọn loại dự án!", TextUtils.Caption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
            if (string.IsNullOrEmpty(txtImplementationDate.Text))
            {
                MessageBox.Show("Vui lòng chọn ngày thực hiện gần nhất!", TextUtils.Caption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
            if (string.IsNullOrEmpty(txtExpectedDate.Text))
            {
                MessageBox.Show("Vui lòng chọn ngày thực hiện!", TextUtils.Caption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }


            if (!TextUtils.ToDate4(dtpDateDonePM.EditValue).HasValue)
            {
                MessageBox.Show("Vui lòng nhập Ngày đã làm (PM báo cáo)!", TextUtils.Caption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }

            if (!TextUtils.ToDate4(dtpDateWillDoPM.EditValue).HasValue)
            {
                MessageBox.Show("Vui lòng nhập Ngày sẽ làm (PM báo cáo)!", TextUtils.Caption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }

            if (string.IsNullOrEmpty(txtWorkDonePM.Text.Trim()))
            {
                MessageBox.Show("Vui lòng nhập Việc đã làm (PM báo cáo)!", TextUtils.Caption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }

            if (string.IsNullOrEmpty(txtWorkWillDoPM.Text.Trim()))
            {
                MessageBox.Show("Vui lòng nhập Việc sẽ làm (PM báo cáo)!", TextUtils.Caption, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }

            //DataTable dt;
            //if (followProjectBase.ID > 0)
            //{
            //    dt = TextUtils.Select("select top 1 ProjectName from FollowProjectBase where ProjectName = '" + txtProjectName.Text.Trim() + "' and ID <> " + followProjectBase.ID);
            //}
            //else
            //{
            //    dt = TextUtils.Select("select top 1 ProjectName from FollowProjectBase where ProjectName = '" + txtProjectName.Text.Trim() + "'");
            //}
            //if (dt != null)
            //{
            //    if (dt.Rows.Count > 0)
            //    {
            //        MessageBox.Show("Mã đã tồn tại, vui lòng kiểm tra lại", TextUtils.Caption, MessageBoxButtons.OK, MessageBoxIcon.Information);
            //        return false;
            //    }
            //}

            return true;
        }

     
       
        

    private void txtTotalWithoutVAT_KeyPress(object sender, KeyPressEventArgs e)
    {
        if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
        {
            e.Handled = true;
        }
    }

    private void btnProjectStatusBase_Click(object sender, EventArgs e)
    {
        frmProjectStatusBaseDetail frm = new frmProjectStatusBaseDetail();
        if (frm.ShowDialog() == DialogResult.OK)
        {
                loadProjectStatus();
        }
    }

    private void btnFirmBase_Click(object sender, EventArgs e)
    {
        frmFirmBaseDetail frm = new frmFirmBaseDetail();
        if (frm.ShowDialog() == DialogResult.OK)
        {
            loadFirmBase();
        }
    }

    private void btnProjectTypeBase_Click(object sender, EventArgs e)
    {
        frmProjectTypeBaseDetail frm = new frmProjectTypeBaseDetail();
        if (frm.ShowDialog() == DialogResult.OK)
        {
            loadProjectTypeBase();
        }
    }

        private void cbProject_EditValueChanged(object sender, EventArgs e)
        {
            int selectedProjectID = TextUtils.ToInt(cbProject.EditValue);

            ProjectModel project = SQLHelper<ProjectModel>.FindByID(selectedProjectID);
            cbCustomer.EditValue = project.CustomerID;
            cboEndUser.EditValue = project.EndUser;
            cbProjectStatus.EditValue = project.ProjectStatus;
            txtProjectStartDate.EditValue = DateTime.Now;
            cbUser.EditValue = project.UserID;
            cboPM.EditValue = project.ProjectManager;


            //DataTable dtProject = TextUtils.Select($"SELECT * FROM Project WHERE ID = {selectedProjectID}");

            //if (dtProject != null && dtProject.Rows.Count > 0)
            //{
            //    int customerID = TextUtils.ToInt(dtProject.Rows[0]["CustomerID"]);
            //    int StatusID = TextUtils.ToInt(dtProject.Rows[0]["ProjectStatus"]);
            //    int EndUser = TextUtils.ToInt(dtProject.Rows[0]["EndUser"]);
            //    int UserID = TextUtils.ToInt(dtProject.Rows[0]["UserID"]);
            //    // Đổ dữ liệu cho cbCustomerBase


            //    cbCustomer.EditValue = customerID;

            //    // Set giá trị cho cboEndUser
              
            //    cboEndUser.EditValue = EndUser;


            //    // Set giá trị cho Status
             
            //    cbProjectStatus.EditValue = StatusID;

            //    // Set Thời gian bắt đầu
            //    txtProjectStartDate.EditValue = DateTime.Now;

               
            //    cbUser.EditValue = UserID;
            //}
        }

        private void frmFollowProjectBaseDetail_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                this.DialogResult = DialogResult.OK;
            }
        }
    }
}
