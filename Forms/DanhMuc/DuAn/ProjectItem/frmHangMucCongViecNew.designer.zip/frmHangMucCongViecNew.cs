﻿using BMS;
using BMS.Business;
using BMS.Model;
using DevExpress.DXCore.Controls.Utils;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraGrid.Views.BandedGrid;
using DevExpress.XtraGrid.Views.Grid;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;

namespace BMS
{
    public partial class frmHangMucCongViecNew : _Forms
    {
        DataSet dataSet = new DataSet();
        List<GridBand> listBand = new List<GridBand>();
        List<BandedGridColumn> listCol = new List<BandedGridColumn>();
        public DateTime createdDate = DateTime.Now;
        public frmHangMucCongViecNew()
        {
            InitializeComponent();
        }

        private void frmHangMucCongViecNew_Load(object sender, System.EventArgs e)
        {
            LoadEmployee();
            LoadDepartment();
            LoadTeam();
            LoadData();
        }
        private void LoadData()
        {
            DateTime dateStart = new DateTime(dtpDateStart.Value.Year, dtpDateStart.Value.Month, dtpDateStart.Value.Day, 0, 0, 0).AddMonths(-2);
            DateTime dateEnd = new DateTime(dtpDateEnd.Value.Year, dtpDateEnd.Value.Month, dtpDateEnd.Value.Day, 23, 59, 59);

            dtpDateStart.Value = dateStart;

            int departmentId = TextUtils.ToInt(cboDepartment.EditValue);
            int employeeId = TextUtils.ToInt(cboEmployee.EditValue);
            int teamId = TextUtils.ToInt(cbTeam.EditValue);
            int status = cboStatus.SelectedIndex;

            using (WaitDialogForm fWait = new WaitDialogForm("Vui lòng chờ trong giây lát...", "Đang tạo phiếu..."))
            {
                dataSet = TextUtils.LoadDataSetFromSP("sp_GetHangMucCongViec",
                                                   new string[] { "@DateStart", "@DateEnd", "@EmployeeID", "@TeamID", "@DepartmentID", "@Status" },
                                                   new object[] { dateStart, dateEnd, employeeId, teamId, departmentId, status });
                grdData.DataSource = dataSet.Tables[0];

                DataTable dt = dataSet.Tables[1];

                string dateS = "";
                string dateE = "";
                if (dt.Rows.Count >= 0)
                {
                    dateS = string.IsNullOrEmpty(TextUtils.ToString(dt.Rows[0]["AllDates"])) ? "" : TextUtils.ToString(dt.Rows[0]["AllDates"]).Substring(0, 5);
                    dateE = string.IsNullOrEmpty(TextUtils.ToString(dt.Rows[dt.Rows.Count - 1]["AllDates"])) ? "" : TextUtils.ToString(dt.Rows[dt.Rows.Count - 1]["AllDates"]).Substring(0, 5);
                }

                grvData.CellMerge += new CellMergeEventHandler(grvData_CellMerge_1);
                addConlumn();
                grvData.OptionsView.AllowCellMerge = true;

                grvData.OptionsBehavior.AutoExpandAllGroups = true;
            }
        }
        private void addConlumn()
        {
            GridBand bandMonth = new GridBand();
            DataTable dtMonth = dataSet.Tables[2];
            DataTable dtAllDate = dataSet.Tables[1];

            if (listBand.Count > 0)
            {
                foreach (GridBand item in listBand)
                {
                    bandNote.Children.Remove(item);
                }
                listBand.Clear();
            }

            if (listCol.Count > 0)
            {
                foreach (BandedGridColumn item in listCol)
                {
                    bandMonth.Columns.Remove(item);
                }
                listCol.Clear();
            }

            for (int i = 0; i < dtMonth.Rows.Count; i++)
            {

                // Thêm 1 band để hiển thị tháng năm 
                bandMonth = new GridBand();
                BandedGridColumn colLast = new BandedGridColumn();

                string month = TextUtils.ToString(dtMonth.Rows[i]["monthDate"]);
                string year = TextUtils.ToString(dtMonth.Rows[i]["yearDate"]);

                if (string.IsNullOrEmpty(month) || string.IsNullOrEmpty(year))
                {
                    break;
                }
                colLast.Visible = true;
                colLast.MinWidth = 30;
                colLast.Width = 30;
                colLast.OptionsColumn.FixedWidth = true;

                bandMonth.Caption = "Tháng " + month + "/" + year;
                bandMonth.Name = month;
                bandMonth.MinWidth = 120;
                bandMonth.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                bandMonth.AppearanceHeader.Options.UseForeColor = true;
                bandMonth.AppearanceHeader.Options.UseFont = true;
                bandNote.Children.Add(bandMonth);
                listBand.Add(bandMonth);

                // hiển thị từng ngày trong khoảng thời gian từ bắt đầu đến kết thúc 
                for (int j = 0; j < dtAllDate.Rows.Count; j++)
                {
                    if (!string.IsNullOrEmpty(TextUtils.ToString(dtAllDate.Rows[j]["AllDates"])))
                    {
                        DateTime date = DateTime.Parse(TextUtils.ToString(dtAllDate.Rows[j]["AllDates"]));
                        BandedGridColumn col = new BandedGridColumn();

                        col.Name = "col" + date.ToString("ddMMyy");
                        col.Caption = date.ToString("dd");
                        col.FieldName = date.ToString("dd/MM/yyyy");
                        col.Tag = date.ToString("dd/MM/yyyy");
                        col.Visible = true;
                        col.OptionsColumn.AllowMove = false;
                        col.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                        col.AppearanceHeader.Options.UseFont = true;
                        col.AppearanceHeader.Options.UseForeColor = true;
                        col.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
                        col.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
                        col.AppearanceHeader.Options.UseTextOptions = true;
                        col.MinWidth = 30;
                        col.Width = 30;
                        col.OptionsColumn.FixedWidth = true;
                        col.OptionsColumn.AllowSort = DevExpress.Utils.DefaultBoolean.False;
                        col.OptionsFilter.AllowFilter = false;
                        col.OptionsFilter.AllowAutoFilter = false;

                        grvData.Columns.Add(col);

                        if (bandMonth.Name == date.ToString("MM"))
                        {

                            bandMonth.Columns.Add(col);
                            col.BestFit();
                        }

                    }

                }
                if (i == dtMonth.Rows.Count - 1)
                {
                    bandMonth.Columns.Add(colLast);
                }
            }
        }

        #region Load Combo
        void LoadDepartment()
        {
            List<DepartmentModel> list = SQLHelper<DepartmentModel>.SqlToList("SELECT * FROM Department");

            cboDepartment.Properties.DataSource = list;
            cboDepartment.Properties.DisplayMember = "Name";
            cboDepartment.Properties.ValueMember = "ID";
            cboDepartment.EditValue = Global.DepartmentID;
        }


        void LoadTeam()
        {
            int departmentID = TextUtils.ToInt(cboDepartment.EditValue);
            List<UserTeamModel> list = SQLHelper<UserTeamModel>.SqlToList($"SELECT * FROM dbo.UserTeam WHERE DepartmentID = {departmentID}");

            cbTeam.Properties.DataSource = list;
            cbTeam.Properties.DisplayMember = "Name";
            cbTeam.Properties.ValueMember = "ID";
        }

        void LoadEmployee()
        {
                List<EmployeeModel> list =
                SQLHelper<EmployeeModel>.SqlToList("Select * from Employee");
                cboEmployee.Properties.DataSource = list;
                cboEmployee.Properties.DisplayMember = "FullName";
                cboEmployee.Properties.ValueMember = "ID";
        }
        #endregion
        private void button1_Click(object sender, EventArgs e)
        {
            int rowHandle = grvData.FocusedRowHandle;
            LoadData();
            grvData.FocusedRowHandle = rowHandle;

        }

        private void grvData_DoubleClick(object sender, EventArgs e)
        {
            var focusedRowHandle = grvData.FocusedRowHandle; // lấy ra dòng hiện tại đang focuse
            int ID = TextUtils.ToInt(grvData.GetFocusedRowCellValue(colEmployeeID));
            if (ID == 0) return;
            // get ra id của nhân viên trong hạng mục công việc
            EmployeeModel model = (EmployeeModel)EmployeeBO.Instance.FindByPK(ID);

            // gán sang form hạng mục công việc của nhân viên đó 

            //frmHangMucCongViecDetail frm = new frmHangMucCongViecDetail();
            //frm.employeeModel = model;
            //if (frm.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            //{
            //    LoadData();
            //    grvData.FocusedRowHandle = focusedRowHandle;
            //}
        }

        private void grvData_CellMerge_1(object sender, CellMergeEventArgs e)
        {
            if (e.Column == colFullName || e.Column == colProjectCode)
            {
                string value1 = TextUtils.ToString(grvData.GetRowCellValue(e.RowHandle1, e.Column));
                string value2 = TextUtils.ToString(grvData.GetRowCellValue(e.RowHandle2, e.Column));
                e.Merge = (value1 == value2);
                e.Handled = true;
                return;
            }
            else
            {
                e.Handled = true;
                return;
            }
        }

        private void grvData_RowCellStyle_1(object sender, RowCellStyleEventArgs e)
        {
            if (e.RowHandle >= 0)
            {
                decimal itemLate = TextUtils.ToDecimal(grvData.GetRowCellValue(e.RowHandle, colItemLate));
                if (e.Column == colType)
                {
                    if (TextUtils.ToString(e.CellValue) == "Plan")
                    {
                        e.Appearance.BackColor = Color.Aqua;
                    }
                    else
                    {
                        e.Appearance.BackColor = Color.Yellow;
                    }
                }
                if (e.Column == colCode)
                {
                    DataRow Row = grvData.GetDataRow(e.RowHandle); // lấy ra dòng 
                    if (Lib.ToInt(Row["ItemLate"]) != 0) // nếu dòng đó có ItemLate != 0 => tô màu 
                    {
                        e.Appearance.BackColor = Color.DarkRed;
                        e.Appearance.ForeColor = Color.White;
                    }
                }
                if (e.Column == colStartDate || e.Column == colTotalDays || e.Column == colEndDate || e.Column == colType)
                {
                    return;
                }

                string strDS = TextUtils.ToString(grvData.GetRowCellValue(e.RowHandle, colStartDate));
                string strDE = TextUtils.ToString(grvData.GetRowCellValue(e.RowHandle, colEndDate));

                DateTime? ds = null;
                DateTime? de = null;
                ds = string.IsNullOrEmpty(strDS) == true ? ds : DateTime.Parse(strDS);
                de = string.IsNullOrEmpty(strDE) == true ? de : DateTime.Parse(strDE);

                if (!DateTime.TryParse(e.Column.FieldName, out DateTime dateCol))
                {
                    return;
                }
                string dayOfWeek = dateCol.DayOfWeek.ToString();
                if (dayOfWeek == "Sunday")
                {
                    e.Appearance.BackColor = Color.FromArgb(224, 224, 224);
                }

                if (dateCol >= ds && dateCol <= de)
                {
                    if (dayOfWeek == "Sunday")
                    {
                        if (TextUtils.ToString(grvData.GetRowCellValue(e.RowHandle, colType)) == "Plan")
                        {
                            e.Appearance.BackColor = Color.FromArgb(224, 224, 224);
                            e.Appearance.BackColor2 = Color.Aqua;
                        }
                        else
                        {

                            e.Appearance.BackColor = Color.FromArgb(224, 224, 224);
                            e.Appearance.BackColor2 = Color.Yellow;
                        }
                    }
                    else
                    {
                        if (TextUtils.ToString(grvData.GetRowCellValue(e.RowHandle, colType)) == "Plan")
                        {
                            e.Appearance.BackColor = Color.Aqua;
                        }
                        else
                        {
                            if (e.Column == colProjectCode && itemLate != 0)
                            {
                                e.Appearance.BackColor = Color.FromArgb(224, 224, 224);
                                e.Appearance.BackColor2 = Color.DarkRed;
                            }
                            else
                            {
                                e.Appearance.BackColor = Color.Yellow;
                            }
                        }
                    }
                }
            }
        }

        #region Sự kiện combo 
        private void cboDepartment_EditValueChanged(object sender, EventArgs e)
        {
            LoadTeam();
        }
        private void cbTeam_EditValueChanged(object sender, EventArgs e)
        {

            int teamId = TextUtils.ToInt(cbTeam.EditValue);
            if (teamId == 0)
            {
                LoadEmployee();
            }
            else
            {
                DataTable dt =
                TextUtils.Select($"Select e.* from Employee As e Join Users As u on u.ID = e.UserID Join UserTeamLink as utl on utl.UserID = u.ID Join UserTeam as ut on ut.ID = utl.UserTeamID WHERE ut.ID = {teamId}");
                cboEmployee.Properties.DataSource = dt;
                cboEmployee.Properties.DisplayMember = "FullName";
                cboEmployee.Properties.ValueMember = "ID";
            }
        }

        private void btnFind_Click(object sender, EventArgs e)
        {
            LoadData();
        }
      
        #endregion

    }
}
